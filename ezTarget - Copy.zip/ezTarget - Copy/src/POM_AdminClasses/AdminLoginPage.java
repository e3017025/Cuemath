package POM_AdminClasses;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

import POM_Classes.BaseClass;

public class AdminLoginPage extends BaseClass
{
 
	private  By selectuser = By.xpath("//*[@id=\'userList\']");
	private  By submit = By.xpath("//*[@id=\'submit\']");
	public String username = "Target client with both DS and CS";
	
	public WebElement SelectUser,Submit;
	
		public AdminLoginPage() throws IOException 
		{
			try
			{
			SelectUser=driver.findElement(selectuser);
			Submit=driver.findElement(submit);
		
			test.pass("Navigating to Admin Login Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) 
			{
				test.fail("Failed on Navigateing to Admin Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
			}
		}
	
	
	
}
