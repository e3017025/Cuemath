package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class Statements extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By
			.cssSelector("body > div.main-container.shell-wrapper > div.page-wrapper > header > div > div > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");

	private By viewStatements = By.xpath("//*[@id='main']/div[2]/div/div/article/div[1]/span");
	
	private By statementTitle = By.xpath("//*[@id='Statements']");
	private By statementSummary = By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[1]/div[1]/div");
	private By previousBalanceLabel = By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div/span[1]/strong");
	private By previousBalanceAmount = By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div/span/span");
	private By newBalanceLabel = By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div[2]/span/strong");
	private By newBalanceAmount =By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div[2]/span/span");
	private By minimumpaymentdueLabel = By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div[3]/span/strong");
	private By minimumpaymentAmount =By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div[3]/span/span");
	private By paymentduedateLabel = By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div[4]/span/strong");
	private By paymentduedate =By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div[4]/span/span");
	private By viewTransactionDetails = By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div[5]/span[1]/a");
	private By makePayment = By.xpath("//*[@id='main']/div[2]/div/div/article/article/div[2]/div[5]/span[2]/a");
	
	public WebElement WelcomeHeader, WelcomeMessage,ViewStatements,StatmentTitle,StatementSummary,PreviousBalanceLabel,
	PreviousBalanceAmount,NewBalanceLabel,NewBalanceAmount,MinimumPaymentDueLabel,MinimumPaymentDueAmount,PaymentDueDateLabel,
	PaymentDueDate,ViewTransactionDetails,MakePayment;
	
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public Statements() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			WelcomeHeader = driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			ViewStatements = driver.findElement(viewStatements);
			StatmentTitle = driver.findElement(statementTitle);
			StatementSummary = driver.findElement(statementSummary);
			PreviousBalanceLabel = driver.findElement(previousBalanceLabel);
			PreviousBalanceAmount = driver.findElement(previousBalanceAmount);
			NewBalanceLabel = driver.findElement(newBalanceLabel);
			NewBalanceAmount = driver.findElement(newBalanceAmount);
			MinimumPaymentDueLabel=driver.findElement(minimumpaymentdueLabel);
			MinimumPaymentDueAmount = driver.findElement(minimumpaymentAmount);
			PaymentDueDateLabel = driver.findElement(paymentduedateLabel);
			PaymentDueDate=driver.findElement(paymentduedate);
			ViewTransactionDetails=driver.findElement(viewTransactionDetails);
			MakePayment=driver.findElement(makePayment);		
			test.pass("Navigated to View Statements Page", MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail("View Statements Page Error *************" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
}