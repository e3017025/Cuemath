package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class ChangeContactInformation extends BaseClass{
	
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#main > div.page-header");
		
		private By nicknameheader=By.cssSelector("#main > div.grid > div:nth-child(1) > div:nth-child(1) > div > h2");
		private By usernicknameheader =By.cssSelector("#main > div.grid > div:nth-child(1) > div:nth-child(1) > div > form > div > label");
		private By usernickname = By.cssSelector("#main > div.grid > div:nth-child(1) > div:nth-child(1) > div > form > div > div > div.col-c-70 > span");
		private By usernicknameTextBox=By.id("userNickname");
		private By edit=By.cssSelector("#main > div.grid > div:nth-child(1) > div:nth-child(1) > div > form > div > div > div.col-c-30.text-right > button");
		
		private By contactInformation=By.cssSelector("#main > div.grid > div:nth-child(1) > div:nth-child(2) > div > h2");
		private By phone=By.id("enrollPhone");
		private By businessPhone=By.id("enrollBusinessPhone");
		private By saveInformation=By.cssSelector("#main > div.grid > div:nth-child(1) > div:nth-child(2) > div > div > form > div > div.field.pull-right > button");
		private By saveusername=By.cssSelector("#main > div.grid > div:nth-child(1) > div:nth-child(1) > div > form > div > div > div.col-c-30.text-right > div > button.btn.btn-xs.btn-primary");
		private By cancelusername=By.cssSelector("#main > div.grid > div:nth-child(1) > div:nth-child(1) > div > form > div > div > div.col-c-30.text-right > div > button.btn.btn-xs.btn-muted");
		
		public String expectedsuccessMessage = "Your Username has been successfully changed";
		private By successMessage = By.cssSelector("#toast-container > div > div");
				
		public WebElement WelcomeHeader,WelcomeMessage,NickNameHeader,UserNickNameHeader,UserNickName,ContactInformation,Phone,BusinessPhone,SaveInformation,Edit,SaveUserName,CancelUserName,UserNameTextBox;
		
		public ChangeContactInformation() throws IOException {
			try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.presenceOfElementLocated(nicknameheader));
			wait.until(ExpectedConditions.presenceOfElementLocated(usernicknameheader));
			wait.until(ExpectedConditions.presenceOfElementLocated(usernickname));
			//wait.until(ExpectedConditions.presenceOfElementLocated(phone));
			//wait.until(ExpectedConditions.presenceOfElementLocated(businessPhone));
			WelcomeHeader=driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			NickNameHeader=driver.findElement(nicknameheader);
			UserNickNameHeader=driver.findElement(usernicknameheader);
			UserNickName=driver.findElement(usernickname);
			Edit=driver.findElement(edit);
			UserNameTextBox=driver.findElement(usernicknameTextBox);
			ContactInformation=driver.findElement(contactInformation);
			Phone=driver.findElement(phone);
			BusinessPhone=driver.findElement(businessPhone);
			SaveInformation=driver.findElement(saveInformation);
			test.pass("Navigating Change Contact Infoamtion Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) {
				test.fail("Failed on Navigating Change Contact Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
			}
			
		}	
		
		public void EditNickName(String nickName) throws InterruptedException {
			Edit.click();
			UserNameTextBox.clear();
			UserNameTextBox.sendKeys(nickName);			
			SaveUserName=driver.findElement(saveusername);
			SaveUserName.click();		
			Thread.sleep(5000);
		}
}