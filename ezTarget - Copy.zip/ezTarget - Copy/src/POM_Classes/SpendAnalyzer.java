package POM_Classes;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

import POM_Classes.Transactions.Categories;

public class SpendAnalyzer extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	
	private By welcomeMessage = By.cssSelector("#mainHeading");
	public static String expectedwelcomeMessage = "Spend Analyzer";
	
	
	// Saved Search
	public static By savedsearchExpanderButton = By.cssSelector(
			"#main > div.grid > article.col-40.analyzer-controls > div:nth-child(1) > div > div:nth-child(1) > h3 > span.navicon-button.plus.open > span");
	
	public By numberofSavedSearches = By.cssSelector("#main > div.grid > article.col-40.analyzer-controls > div:nth-child(1) > div > div:nth-child(1) > h3 > span:nth-child(2)");
	private By savedsearchTitle = By.xpath("//*[@id='main']/div[2]/article[1]/div[1]/div/div[1]/h3");
	
	private By savedSearchHelpIcon = By.cssSelector(
			"#main > div.grid > article.col-40.analyzer-controls > div:nth-child(1) > div > div:nth-child(1) > h3 > button > span.icon-info-circled");
	
	private By savedSearchName =By.xpath("//*[@id='collapsible-searches']/ul/li/div[1]/button");
	private By lockicon =By.xpath("//*[@id='collapsible-searches']/ul/li/div[2]/span/span[1]");
	private By lockText = By.xpath("//*[@id='collapsible-searches']/ul/li/div[2]/span/span[2]");
	
	private By filterExpanderButton = By.cssSelector(
			"#main > div.grid > article.col-40.analyzer-controls > div:nth-child(2) > form > div > div:nth-child(1) > h3 > span");
	private By filterTitle = By.xpath("//*[@id='main']/div[2]/article[1]/div[2]/form/div/div[1]/h3");
	
	private By filtersHelpIcon = By.cssSelector(
			"#main > div.grid > article.col-40.analyzer-controls > div:nth-child(2) > form > div > div:nth-child(1) > h3 > button > span.icon-info-circled");

	
	private By categoriesLabel = By.cssSelector("#collapsible-filters > div:nth-child(1) > label");
	private By categoriesOption = By.cssSelector("#buttonCategories");

	
	private By savethisSearch = By
			.cssSelector("#collapsible-filters > div:nth-child(2) > button");
	
	public By customsearchName = By.xpath("//*[@id='collapsible-searches']/ul/li[2]/div[1]/button");
	public By deleteCustomSearch =By.xpath("//*[@id='collapsible-searches']/ul/li[2]/div[2]/button");
	
	private By piechart = By.xpath("//*[@id='category-graph']");
	private By barchart = By.xpath("//*[@id='time-graph']");
	private By chartHelpIcon = By.cssSelector("#main > div.grid > article.col-60.analyzer-data > div > div.module.module-light.module-border > div > div.col-c-10.col-right.text-right > h3 > button > span.icon-info-circled");

	private By timePeriodButton = By.id("buttonOrder");
	
	private By topspendings = By.cssSelector("#main > div.grid > article.col-60.analyzer-data > div > div:nth-child(2) > div:nth-child(2) > div:nth-child(3) > h3 > strong");
	public By chartArea = By.xpath("//*[@id='main']/div[2]/article[2]/div/div[2]/div[2]/div[2]");
	public By transactionArea = By.xpath("//*[@id='main']/div[2]/article[2]/div/div[2]/section");
	
	private By errorMessage = By.xpath("//*[@id='main']/div[2]/article[2]/div/div[2]/div[2]/span");
	public String errorMessageOnNoCategoriesSelection = "Select a category from Filters to display the chart.";
	public String errorMessageOnNoRecords = "There are no results with your filters.";

	public WebElement WelcomeMessage, WelcomeHeader, SavedSearchExpanderButton,
			SavedSearchTitle, SavedSearchHelpIcon, FiltersExpanderButton, FiltersTitle, FiltersHelpIcon, LockIcon,LockText,
			 CategoriesLabel, CategoriesOption, SaveThisSearch, PieChart,BarChart,ChartHelpIcon,TimePeriodButton,SavedSearchName;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public SpendAnalyzer() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			// wait.until(ExpectedConditions.visibilityOfElementLocated(transactionDescription));
			wait.until(ExpectedConditions.visibilityOfElementLocated(savedsearchExpanderButton));
			wait.until(ExpectedConditions.visibilityOfElementLocated(savedsearchTitle));
			wait.until(ExpectedConditions.visibilityOfElementLocated(savedSearchHelpIcon));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filterExpanderButton));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filterTitle));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filtersHelpIcon));
			WelcomeHeader = driver.findElement(welcomeHeader);
			WelcomeMessage = driver.findElement(welcomeMessage);
			SavedSearchExpanderButton = driver.findElement(savedsearchExpanderButton);
			SavedSearchTitle = driver.findElement(savedsearchTitle);
			SavedSearchHelpIcon = driver.findElement(savedSearchHelpIcon);
			SavedSearchName=driver.findElement(savedSearchName);
			FiltersExpanderButton = driver.findElement(filterExpanderButton);
			FiltersTitle = driver.findElement(filterTitle);
			FiltersHelpIcon = driver.findElement(filtersHelpIcon);
			LockIcon=driver.findElement(lockicon);
			LockText=driver.findElement(lockText);
			CategoriesLabel = driver.findElement(categoriesLabel);
			CategoriesOption = driver.findElement(categoriesOption);		
			SaveThisSearch = driver.findElement(savethisSearch);	
			PieChart=driver.findElement(piechart);
			BarChart = driver.findElement(barchart);
			TimePeriodButton=driver.findElement(timePeriodButton);
			test.pass("Navigated to Spend Analyzer Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());

		} catch (Exception e) {
			test.fail("Transaction Page Error *********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	public String errorMessage() {
		String ErrorMessage = driver.findElement(errorMessage).getText();
		return ErrorMessage;		
	}
	public class TimePeriod {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		
		private By addTimeLabelSideRight = By.cssSelector("body > div.aside.right.am-slide-right");
		
		private By sinceLastStatement=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[1]");
		private By currentweek=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[2]");
		private By lastweek=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[3]");
		private By currentmonth=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[4]");
		private By currentquarter=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[5]");
		private By yeartodate=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[6]");
		private By last6month=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[7]");
		private By last12months=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[8]");
		private By lastyear=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[9]");
		private By fullhistory=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[10]");


		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-footer > button");
			
		public WebElement CloseIcon, AddTimeLabelSideRight, SinceLastStatement, CurrentWeek,LastWeek,CurrentMonth,
		CurrentQuarter,YearToDate,Last6Months,Last12Months,LastYear,FullHistory,Apply;

		public TimePeriod(	) throws IOException {
			try {
				WebDriverWait waitTime = new WebDriverWait(driver, 90);
				waitTime.until(ExpectedConditions.visibilityOfElementLocated(addTimeLabelSideRight));
				waitTime.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				AddTimeLabelSideRight = driver.findElement(addTimeLabelSideRight);
				SinceLastStatement=driver.findElement(sinceLastStatement);
				CurrentWeek=driver.findElement(currentweek);
				LastWeek=driver.findElement(lastweek);
				CurrentQuarter=driver.findElement(currentquarter);
				YearToDate=driver.findElement(yeartodate);
				Last6Months=driver.findElement(last6month);
				Last12Months=driver.findElement(last12months);
				LastYear=driver.findElement(lastyear);
				FullHistory=driver.findElement(fullhistory);
				Apply =driver.findElement(apply);
				test.pass("Navigated to Add Time Label Side Bar",
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());				
				
			} catch (Exception e) {
				test.fail(" Time  Period Label Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	public class Categories {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By categoriesSideRight = By.cssSelector("body > div.aside.right.am-slide-right");

		private By clearAll = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div.grid > button:nth-child(1)");

		private By selectAll = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div.grid > button:nth-child(2)");

		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-footer > button");

		public By selectcategory = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button[1]");

		public WebElement CloseIcon, CategoriesSideRight, Apply, SelectAll, ClearAll;

		public Categories() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(categoriesSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				CategoriesSideRight = driver.findElement(categoriesSideRight);
				Apply = driver.findElement(apply);
				SelectAll = driver.findElement(selectAll);
				ClearAll = driver.findElement(clearAll);
				test.pass("Navigated to Categories Side Bar",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Categories Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public ArrayList<LinkedHashMap> returnDatasToVerifyExportRecord()
			throws InterruptedException, IOException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;

		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);
		ArrayList<LinkedHashMap> userdata = new ArrayList<>();
		Robot robot = new Robot();	
		for (int j = 1; j <= numberofPages; j++) {
			ScrollToElement(driver.findElement(transactionArea));
			Thread.sleep(3000);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_DOWN);
			robot.keyPress(KeyEvent.VK_DOWN);
			int numberofgroups = driver.findElements(By.xpath("//*[@id='collapsible-txns']/div")).size();
			System.out.println(numberofgroups);			
			for (int c = 1; c < numberofgroups; c++) {
					int numberofrowsineachcategory = driver
						.findElements(By.xpath("//*[@id='collapsible-txns']/div[" + c + "]/div")).size();
				System.out.println("numberofrowsineachcategory: " + numberofrowsineachcategory);
				for (int i = 1; i <= numberofrowsineachcategory; i++) {
				WebElement expanderbutton = driver
						.findElement(By.xpath("//*[@id='collapsible-txns']/div["+c+"]/div[" + i + "]"));
				//ScrollToElement(expanderbutton);
				expanderbutton.click();
				robot.keyPress(KeyEvent.VK_DOWN);
				//robot.keyPress(KeyEvent.VK_DOWN);
				Thread.sleep(3000);
				int Numberofleftspans = driver
						.findElements(
								By.xpath("//*[@id='collapsible-txns']/div["+c+"]/div[" + i + "]/div[2]/div/div[1]/p/span"))
						.size();
				int Numberofrightspans = driver
						.findElements(
								By.xpath("//*[@id='collapsible-txns']/div["+c+"]/div[" + i + "]/div[2]/div/div[2]/p/span"))
						.size();
				if (Numberofrightspans > 4) {
					Numberofrightspans = 5;
				}
				LinkedHashMap<String, String> detailsofUI = new LinkedHashMap<>();
				for (int a = 1; a <= Numberofleftspans; a++) {
					String data = driver.findElement(By.xpath(
							"//*[@id='collapsible-txns']/div["+c+"]/div[" + i + "]/div[2]/div/div[1]/p/span[" + a + "]"))
							.getText();
					String[] details = data.split(":");
					detailsofUI.put(details[0].trim(), details[1].trim());
				}
				for (int b = 1; b <= Numberofrightspans; b++) {
					String data = driver.findElement(By.xpath(
							"//*[@id='collapsible-txns']/div["+c+"]/div[" + i + "]/div[2]/div/div[2]/p/span[" + b + "]"))
							.getText();
					String[] details = data.split(":");
					detailsofUI.put(details[0].trim(), details[1].trim());
				}
				userdata.add(detailsofUI);
				if (i < 10) {
					driver.findElement(By.xpath("//*[@id='collapsible-txns']/div["+c+"]/div[" + i + "]/div[1]")).click();
					Thread.sleep(3000);
				}
				//robot.keyPress(KeyEvent.VK_PAGE_UP);
				System.out.println(detailsofUI);
			}
			}
			if (numberofPages > 1) {
				//Robot robot = new Robot();
				//robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
				Thread.sleep(10000);
				/*robot.keyPress(KeyEvent.VK_PAGE_UP);
				robot.keyPress(KeyEvent.VK_PAGE_UP);
				robot.keyPress(KeyEvent.VK_PAGE_UP);
				robot.keyPress(KeyEvent.VK_PAGE_UP);
				robot.keyPress(KeyEvent.VK_PAGE_UP);*/
				//ScrollToElement(driver.findElement(transactionArea));
				JavascriptExecutor jse = (JavascriptExecutor) driver;
				jse.executeScript("window.scrollTo(document.body.scrollHeight,0 )");
				Thread.sleep(5000);
			}
		}
		System.out.println(userdata);
		return userdata;
	}

	public ArrayList<String> SelectAvailableCategories()
			throws IOException, AWTException, InterruptedException {
		SpendAnalyzer spendAnalyzer = new SpendAnalyzer();
		ArrayList<String> listofcategories = new ArrayList<>();
		SpendAnalyzer.Categories categories = spendAnalyzer.new Categories();
		categories.ClearAll.click();
		int numberofcategories = driver.findElements(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button"))
				.size()-1;
		listofcategories = new ArrayList<String>();
		for (int i = 1; i <= numberofcategories; i++) {
			WebElement element = driver
					.findElement(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button[" + i + "]"));
			element.click();
			String categoryname = element.getText();
			listofcategories.add(categoryname);
		}
		categories.Apply.click();	
		return listofcategories;		
	}	
	
	
	public ArrayList<LinkedHashMap> verifyChartData(ArrayList<LinkedHashMap> uiData,ArrayList<String> listofCategories) {
		double TotalSum = 0.0;
		System.out.println(uiData.size());
		for(int c=0;c<uiData.size();c++) {
				System.out.println(uiData.get(c).get("Original Amount").toString());
				TotalSum = TotalSum+Double.parseDouble(uiData.get(c).get("Original Amount").toString().replace("$", "").replace(",",""));
				System.out.println(TotalSum);
			}
		
		
		long Percentage;
		ArrayList<LinkedHashMap> sumoneachCategories = new ArrayList<>();
		for(int b=0;b<listofCategories.size();b++) {
		double sumofindividuals = 0.0;	
		LinkedHashMap<String,String> map= new LinkedHashMap<>();
		for(int a=0;a<uiData.size();a++) {
		if(uiData.get(a).get("Category").equals(listofCategories.get(b).toString())) 
		{
			sumofindividuals = sumofindividuals+Double.parseDouble(uiData.get(a).get("Original Amount").toString().replace("$", "").replace(",",""));
		}
		}
		Percentage = Math.round((sumofindividuals/TotalSum)*100);
		map.put("Category",listofCategories.get(b).toString());
		map.put("SumOfIndividuals",Double.toString(sumofindividuals));		
		map.put("Percentage",Long.toString(Percentage));
		if(!Double.toString(sumofindividuals).equals("0.0") && !Long.toString(Percentage).equals("0")) {
		sumoneachCategories.add(map);
		}
		}
		
		return sumoneachCategories;
	}
	
	public void topspendingsingraph(ArrayList<LinkedHashMap> data) throws IOException {
		String TopSpending = driver.findElement(By.xpath("//*[@id='main']/div[2]/article[2]/div/div[2]/div[2]/div[3]/h3/strong")).getText();
		AssertVerify(TopSpending, "Top "+data.size()+" Spending Categories");
		for(int i=0;i<data.size();i++) {
			ScrollToElement(PieChart);
			String percentage = driver.findElement(By.xpath("//*[@id='main']/div[2]/article[2]/div/div[2]/div[2]/div[3]/p["+(i+1)+"]/span[1]")).getText();
			String categoryText = driver.findElement(By.xpath("//*[@id='main']/div[2]/article[2]/div/div[2]/div[2]/div[3]/p["+(i+1)+"]")).getText().trim();
			String[] categorysplit = categoryText.split(" ");
			String Category= categorysplit[2];
			String sum = driver.findElement(By.xpath("//*[@id='main']/div[2]/article[2]/div/div[2]/div[2]/div[3]/p["+(i+1)+"]/span[2]")).getText();			
			for(int a=0;a<data.size();a++) {
			if(data.get(a).get("Category").equals(Category)) {
				String sumOfIndviduals = data.get(a).get("SumOfIndividuals").toString();
				String[] splitvalues= sumOfIndviduals.split("\\.");
				if(splitvalues[splitvalues.length-1].length()==1) {
					sumOfIndviduals = sumOfIndviduals+"0";
				}			
				/*if(sumOfIndviduals.endsWith(".0")) {
					sumOfIndviduals=sumOfIndviduals.replace(".0", ".00");
				}*/
				AssertVerify(data.get(a).get("Percentage").toString()+" %", percentage);
				AssertVerify("$"+sumOfIndviduals, sum.replace(",", ""));
			}
			}
		}
							
	}
	
	public class SaveThisSearchConfirmModal {

		private By closeIcon = By.cssSelector("#modalContent > div.modal-header > button > span:nth-child(1)");

		private By modalTitle = By.cssSelector("#modalContent > div.modal-header > h3");
		public String expectedmodalTitle = "Save Transaction Search";
		private By savesearchName = By.id("searchName");
		private By save = By.cssSelector("#modalContent > div.modal-footer > button.btn.btn-primary.btn-sm");
		private By cancel = By.cssSelector("#modalContent > div.modal-footer > button:nth-child(2)");
		public By successmessage = By.cssSelector("#toast-container > div > div");

		public WebElement CloseIcon, ModalTitle, Save, Cancel, SaveSearchName;

		public SaveThisSearchConfirmModal() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(modalTitle));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				ModalTitle = driver.findElement(modalTitle);
				Save = driver.findElement(save);
				Cancel = driver.findElement(cancel);
				SaveSearchName = driver.findElement(savesearchName);
				test.pass("Navigated to Save this search screen",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Save this search Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}	
}


