package POM_Classes;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class Payments extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");
	public static String expectedwelcomeMessage = "Payments";
	
	// Filters
	private By filterExpanderButton = By.cssSelector(
			"#main > div.col-35 > div:nth-child(1) > div > div:nth-child(1) > h3 > span > span");
	
	private By filterTitle = By.xpath("//*[@id='main']/div[3]/div[1]/div/div[1]/h3");
	
	private By filtersHelpIcon = By.cssSelector(
			"#main > div.col-35 > div:nth-child(1) > div > div:nth-child(1) > h3 > button > span.icon-info-circled");

	private By paymentsHelpIcon = By.xpath("#main > div.page-header > button > span.icon-info-circled");
	private By modifyAutoPay=By.cssSelector("#main > div.col-65 > div > article:nth-child(1) > div > span > a");
	private By makeOneTimePayment=By.cssSelector("#main > div.col-65 > div > article:nth-child(1) > div > a");
	private By noPayments=By.xpath("id('main')/div[@class='col-65']/div[@class='module module-dark']/article[@class='module-light module-border']/header[@class='h3 list-header']/span[1]");
	
	
	//amount
	private By amountLabel = By.cssSelector("#collapsible-filters > div > div:nth-child(1) > label");
	private By amountOption = By.cssSelector("#collapsible-filters > div > div:nth-child(1) > button");
	private By dateLabel=By.cssSelector("#collapsible-filters > div > div:nth-child(2) > label");
	private By dateOption=By.cssSelector("#collapsible-filters > div > div:nth-child(2) > button");
	private By orderBylabel = By.cssSelector("#collapsible-filters > div > div:nth-child(3) > label");
	private By orderByoption = By.cssSelector("#collapsible-filters > div > div:nth-child(3) > button");
	private By paymentstatusLabel = By.cssSelector("#collapsible-filters > div > div:nth-child(4) > label");
	private By paymentstatusoption = By.cssSelector("#collapsible-filters > div > div:nth-child(4) > button");
	private By lookingforSomething=By.xpath("//*[@id='main']/div[3]/div[2]");

	public ArrayList<String> expectedListofPaymentStatus = new ArrayList<>(Arrays.asList("All","Pending","Canceled","Processing","Processed","Returned","Posted"));

	public WebElement WelcomeMessage, WelcomeHeader, FiltersExpanderButton, FiltersTitle,NoRecords,
			FiltersHelpIcon, AmountLabel,AmountOption, OrderBylabel, OrderByoption, 
			DateLabel,DateOption,PaymentStatusLabel,PaymentStatusOption,LookingForSomething,ModifyAutoPay,MakeOneTimePayment;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public Payments() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);			
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filterExpanderButton));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filterTitle));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filtersHelpIcon));
			WelcomeHeader = driver.findElement(welcomeHeader);
			WelcomeMessage = driver.findElement(welcomeMessage);
			FiltersExpanderButton = driver.findElement(filterExpanderButton);
			FiltersTitle = driver.findElement(filterTitle);
			FiltersHelpIcon = driver.findElement(filtersHelpIcon);			
			AmountLabel = driver.findElement(amountLabel);
			AmountOption = driver.findElement(amountOption);
			OrderBylabel = driver.findElement(orderBylabel);
			OrderByoption = driver.findElement(orderByoption);
			DateLabel=driver.findElement(dateLabel);
			DateOption=driver.findElement(dateOption);
			PaymentStatusLabel=driver.findElement(paymentstatusLabel);
			PaymentStatusOption=driver.findElement(paymentstatusoption);
			LookingForSomething=driver.findElement(lookingforSomething);
			try {
			ModifyAutoPay=driver.findElement(modifyAutoPay);
			}
			catch(Exception e) {
				System.out.println("Auto Pay is NOT Enabled");
			}
			MakeOneTimePayment=driver.findElement(makeOneTimePayment);
			test.pass("Navigated to Payments Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());

		} catch (Exception e) {
			test.fail("Payments Page Error *********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	public String getNoRecords() {
		NoRecords=driver.findElement(noPayments);
		return NoRecords.getText().trim();
		
	}
	public class CustomDateRangeForPayments {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
				 
		private By addCustomDateRangeSideRight = By.cssSelector(
				"body > div.aside.right.am-slide-right.aside-overflow-visible");
		
		private By fromLabel = By.cssSelector("body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.field.form-stacked > label:nth-child(1)");
		
		private By fromYear = By.cssSelector("body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.field.form-stacked > div:nth-child(2) > div > div:nth-child(1) > select");		
		private By fromMonth = By.cssSelector("body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.field.form-stacked > div:nth-child(2) > div > div:nth-child(2) > select");
		private By fromDay = By.cssSelector("body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.field.form-stacked > div:nth-child(2) > div > div:nth-child(3) > select");

		private By toLabel = By.cssSelector("body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.field.form-stacked > label:nth-child(3)");
		private By toYear = By.cssSelector("body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.field.form-stacked > div:nth-child(4) > div > div:nth-child(1) > select");
		private By toMonth = By.cssSelector("body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.field.form-stacked > div:nth-child(4) > div > div:nth-child(2) > select");
		private By toDay = By.cssSelector("body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.field.form-stacked > div:nth-child(4) > div > div:nth-child(3) > select");

		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-body > div.aside-footer > button");

		public WebElement CloseIcon, AddCustomDateRangeSideRight, FromLabel, FromYear, FromMonth, FromDay, ToLabel,
				ToYear, ToMonth, ToDay, Apply;

		public CustomDateRangeForPayments() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(addCustomDateRangeSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				AddCustomDateRangeSideRight = driver.findElement(addCustomDateRangeSideRight);
				// FromLabel = driver.findElement(fromLabel);
				FromYear = driver.findElement(fromYear);
				FromMonth = driver.findElement(fromMonth);
				FromDay = driver.findElement(fromDay);
				// ToLabel = driver.findElement(toLabel);
				ToYear = driver.findElement(toYear);
				ToMonth = driver.findElement(toMonth);
				ToDay = driver.findElement(toDay);
				Apply = driver.findElement(apply);
				test.pass("Navigated to Custom Date Range Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Custom Date Range Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}

		}
	}

	
	public class Amount {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By amountSideRight = By.cssSelector("body > div.aside.right.am-slide-right");

		private By fromLabel = By.cssSelector("body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > form > div:nth-child(1) > label");
		private By fromAmount = By.cssSelector("body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > form > div:nth-child(1) > input");

		private By toLabel = By.cssSelector("body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > form > div:nth-child(2) > label");
		private By toAmount = By.cssSelector("body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > form > div:nth-child(2) > input");

		private By apply = By.cssSelector("body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div > button");

		public WebElement CloseIcon, AmountSideRight, Apply, FromLabel, ToLabel, FromAmount, ToAmount, Clear;

		public Amount() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(amountSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				AmountSideRight = driver.findElement(amountSideRight);
				FromLabel = driver.findElement(fromLabel);
				FromAmount = driver.findElement(fromAmount);
				ToLabel = driver.findElement(toLabel);
				ToAmount = driver.findElement(toAmount);
				Apply = driver.findElement(apply);				
				test.pass("Navigated to Amount Side Bar",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Amount Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public class OrderBy {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By orderBySideRight = By.cssSelector("body > div.aside.right.am-slide-right");

		private By ascendingOrder = By.xpath("//*[@id='orderByDirectionReverse']/div/button[1]");
		private By descendingOrder = By.xpath("//*[@id='orderByDirectionReverse']/div/button[2]");
		
		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-footer > button");

		public WebElement CloseIcon, OrderBySideRight, DescendingOrder, AscendingOrder, Apply;

		public OrderBy() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(orderBySideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				OrderBySideRight = driver.findElement(orderBySideRight);
				DescendingOrder = driver.findElement(descendingOrder);
				AscendingOrder = driver.findElement(ascendingOrder);
				Apply = driver.findElement(apply);
				test.pass("Navigated to Order By Side Bar",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Order By Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	public class PaymentStatus {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By paymentStatusSideRight = By.cssSelector("body > div.aside.right.am-slide-right");

		private By all = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/div/button[1]");
		private By pending = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/div/button[2]");
		private By cancelled = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/div/button[3]");
		private By processing = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/div/button[4]");
		private By processed = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/div/button[5]");
		private By returned = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/div/button[6]");
		private By posted = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/div/button[7]");
		
		
		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-footer > button");

		public WebElement CloseIcon, PaymentStatusSideRight, All,Pending,Cancelled,Processing,Processed,Returned,Posted,Apply;

		public PaymentStatus() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(paymentStatusSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				PaymentStatusSideRight = driver.findElement(paymentStatusSideRight);
				All=driver.findElement(all);
				Pending=driver.findElement(pending);
				Cancelled=driver.findElement(cancelled);
				Processing=driver.findElement(processing);
				Processed=driver.findElement(processed);
				Returned=driver.findElement(returned);
				Posted=driver.findElement(posted);
				Apply = driver.findElement(apply);
				test.pass("Navigated to Order By Side Bar",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Order By Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	
	public ArrayList<String> listofPaymentStatus() {
		List<WebElement> Element = driver.findElements(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/div/button"));
		int numberofstatus = Element.size();
		ArrayList<String> paymentStatus = new ArrayList<>(); 
		for(WebElement status:Element) {
			String text = status.getText();
			paymentStatus.add(text);
		}
		return paymentStatus;
	}
	
	
	public int numberofTransactions() {
		List<WebElement> Element = driver.findElements(By.xpath("id('main')/div[@class='col-65']/div[@class='module module-dark']/article[@class='module-light module-border accordion']/div"));
		int numberoftransactions = Element.size();
		return numberoftransactions;
	}
	
	public String getDate(int index) {
		String value = driver
				.findElement(By.xpath("id('main')/div[@class='col-65']/div[@class='module module-dark']/article[@class='module-light module-border accordion']/div["+index+"]/div[@class='grid list-item']/div[@class='col-40']/div[1]"))
				.getText();
		return value;
	}
	
	public String getAmount(int index) {
		String value = driver
				.findElement(By.xpath("//*[@id='main']/div[2]/div/article[2]/div["+index+"]/div[1]/div[1]/h4")).getText().trim().replace("$", "");;
		return value;
	}
	
	
	public boolean verifyDateAscendingOrder() throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("id('Payments')/span[1]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		for (int i = 1; i < numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String transactiondate1 = getDate(i);
			String transactiondate2 = getDate(i+1);

			transactiondate1 = transactiondate1.toLowerCase();
			String firstLetter1 = transactiondate1.substring(0, 1);
			String newdate1 = firstLetter1.toUpperCase() + transactiondate1.substring(1);
			transactiondate1 = newdate1;
			System.out.println(transactiondate1);
			transactiondate2 = transactiondate2.toLowerCase();
			String firstLetter2 = transactiondate2.substring(0, 1);
			String newdate2 = firstLetter2.toUpperCase() + transactiondate2.substring(1);
			transactiondate2 = newdate2;
			System.out.println(transactiondate2);

			LocalDate date1 = DateValue(transactiondate1);
			LocalDate date2 = DateValue(transactiondate2);
			if (date1.compareTo(date2) < 0) {
				System.out.println("Date1 is before Date2");
				flag = true;
			} else if (date1.compareTo(date2) == 0) {
				System.out.println("Date1 is equal to Date2");
				flag = true;
			} else {
				flag = false;
				return flag;
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;

	}

	public boolean verifyDateDescendingOrder() throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("id('Payments')/span[1]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		for (int i = 1; i < numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String transactiondate1 = getDate(i);
			String transactiondate2 = getDate(i+1);

			transactiondate1 = transactiondate1.toLowerCase();
			String firstLetter1 = transactiondate1.substring(0, 1);
			String newdate1 = firstLetter1.toUpperCase() + transactiondate1.substring(1);
			transactiondate1 = newdate1;
			System.out.println(transactiondate1);
			transactiondate2 = transactiondate2.toLowerCase();
			String firstLetter2 = transactiondate2.substring(0, 1);
			String newdate2 = firstLetter2.toUpperCase() + transactiondate2.substring(1);
			transactiondate2 = newdate2;
			System.out.println(transactiondate2);
			LocalDate date1 = DateValue(transactiondate1);
			LocalDate date2 = DateValue(transactiondate2);
			if (date1.compareTo(date2) > 0) {
				System.out.println("Date1 is after Date2");
				flag = true;
			} else if (date1.compareTo(date2) == 0) {
				System.out.println("Date1 is equal to Date2");
				flag = true;
			} else {
				flag = false;
				return flag;
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;

	}
	
	public boolean verifyAmountIsWithInTheRange(String from, String To) throws InterruptedException, AWTException, IOException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("id('Payments')/span[1]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		for (int i = 1; i <= numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String amount1 = driver
					.findElement(By.xpath("//*[@id='main']/div[2]/div/article[2]/div["+i+"]/div[1]/div[1]/h4"))
					.getText().replace("$", "");
			
			amount1 = amount1.replace(",", "");
			if (from.length() > 0 && To.length() > 0) {
				float v1 = Float.parseFloat(amount1);
				float v2 = Float.parseFloat(from);
				float v3 = Float.parseFloat(To);
				if (v1 >= v2 && v1 <= v3) {
					flag = true;
					test.pass(amount1 + " is within the range of Lowerrange " + v2 + " and Upper Range " + v3,MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				} else {
					flag = false;
					test.fail(amount1 + " is NOT within the range of Lowerrange " + v2 + " and Upper Range " + v3,MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					return flag;
				}
			}
			if (from.length() == 0 && To.length() > 0) {
				float v1 = Float.parseFloat(amount1);
				float v3 = Float.parseFloat(To);
				if (v1 <= v3) {
					flag = true;
					test.pass(amount1 + " is within the Upper Range " + v3,MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				} else {
					flag = false;
					test.fail(amount1 + " is greater than the Upper Range " + v3,MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					return flag;
				}
			}

			if (from.length() > 0 && To.length() == 0) {
				float v1 = Float.parseFloat(amount1);
				float v2 = Float.parseFloat(from);
				if (v1 >= v2) {
					flag = true;
					test.pass(amount1 + " is on or above the Lower Range " + v2,MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				} else {
					flag = false;
					test.fail(amount1 + " is lesser than the Lower Range " + v2,MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					return flag;
				}
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;
	}

	public boolean verifyDateIsWithinRange(String from, String to) throws InterruptedException, AWTException, IOException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("id('Payments')/span[1]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
			int numberofrows = numberofTransactions();
			System.out.println(numberofrows);
			for (int i = 1; i <= numberofrows; i++) {
				String transactiondate = getDate(i);
				transactiondate = transactiondate.toLowerCase();
				String firstLetter = transactiondate.substring(0, 1);
				String newdate = firstLetter.toUpperCase() + transactiondate.substring(1);
				transactiondate = newdate;
				if (from.length() > 0 && to.length() > 0) {
					LocalDate date1 = DateValue(from);
					LocalDate date2 = DateValue(transactiondate);
					LocalDate date3 = DateValue(to);
					if (date2.compareTo(date1) >= 0 && date2.compareTo(date3) <= 0) {
						System.out.println(date1);
						System.out.println(date2);
						System.out.println(date3);
						System.out.println(date2.compareTo(date3));
						System.out.println(date1.compareTo(date2));
						System.out.println("Transaction date is within the range");
						test.pass("Transaction date is within the range",MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
						flag = true;
					} else {
						flag = false;
						test.fail("Transaction date is NOT within the range",MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
						return flag;
					}
				}
				if (from.length() == 0 && to.length() > 0) {
					// LocalDate date1 = DateValue(from);
					LocalDate date2 = DateValue(transactiondate);
					LocalDate date3 = DateValue(to);
					if (date2.compareTo(date3) <= 0) {
						System.out.println(date2);
						System.out.println(date3);
						System.out.println(date2.compareTo(date3));
						System.out.println("Transaction date is within the range");	
						test.pass("Transaction date is within the range",MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
						flag = true;
					} else {
						flag = false;
						test.fail("Transaction date is NOT within the range",MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
						return flag;
					}
				}
				if (from.length() > 0 && to.length() == 0) {
					LocalDate date1 = DateValue(from);
					LocalDate date2 = DateValue(transactiondate);
					// LocalDate date3 = DateValue(to);
					if (date2.compareTo(date1) >= 0) {
						System.out.println(date1);
						System.out.println(date2);
						System.out.println(date1.compareTo(date2));
						System.out.println("Transaction date is within the range");
						test.pass("Transaction date is within the range",MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
						flag = true;
					} else {
						flag = false;
						test.fail("Transaction date is NOT within the range",MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
						return flag;
					}
				}
			}
			if (numberofPages > 1) {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			}
		}
		return flag;
	}
	
	public void verifyStatus(String input) throws IOException, AWTException, InterruptedException {
		
		String noRecords = getNoRecords();
		System.out.println(noRecords);
		if(!noRecords.equals("There are no payments at this time.")) {
		String numberofTransactions = driver.findElement(By.xpath("id('Payments')/span[1]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);
		
		for (int k = 1; k <= numberofPages; k++) {
		int numberofelements = numberofTransactions();
		for(int i=1;i<=numberofelements;i++) {
		String element1 = driver.findElement(By.xpath("//*[@id='main']/div[2]/div/article[2]/div["+i+"]/div[1]/div[2]/div[1]")).getText();
		AssertVerify(element1,input);
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
	}
	}
		else {
			test.info("No Records found for the selected category",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
	
	public int returnIndex(String confirmationNumber) throws AWTException, InterruptedException {	
			int index = 0;
			String numberofTransactions = driver.findElement(By.xpath("id('Payments')/span[1]")).getText()
					.replace(")", "").replace("(", "");
			int numberofPages = numberofPages(numberofTransactions);
			System.out.println(numberofPages);
			
			for (int k = 1; k <= numberofPages; k++) {
			int numberofelements = numberofTransactions();
			for(int i=1;i<=numberofelements;i++) {
				String element = driver.findElement(By.xpath("//*[@id='main']/div[2]/div/article[2]/div["+i+"]/div[1]/div[2]/div[3]")).getText();
				System.out.println(element);
				confirmationNumber=confirmationNumber.replace(":", "");
				System.out.println(confirmationNumber);
				if(element.equals(confirmationNumber)) {
				
					index=i;
					return index;
				}
			}
			if (numberofPages > 1) {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
				Thread.sleep(15000);
				robot.keyPress(KeyEvent.VK_PAGE_UP);
			}
		}
			return -1;
				
	}
	
	public class CancelPayment{
		//amount
		private By modalTitle = By.cssSelector("#dialogTitle");
		private By confrimationText = By.cssSelector("#dialogDesc");
		private By paymentAmountLabel=By.cssSelector("body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-body > div:nth-child(3) > span.text-muted");
		private By paymentAmount=By.cssSelector("body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-body > div:nth-child(3) > span:nth-child(2)");
		private By cancelPayment = By.cssSelector("body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-footer > button");
		private By closeIcon = By.cssSelector("body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-header > button > span:nth-child(1)");
		private By paymentDueDate=By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div[2]"); 
		
		public String expectedconfirmationText="You are about to cancel a Payment. To confirm, please click the Cancel Payment Button.";
		
		public WebElement ModalTitle,ConfrimationText, PaymentAmountLabel, PaymentAmount, CancelPayment,CloseIcon,PaymentDueDate;
	

		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public CancelPayment() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 120);			
				ModalTitle = driver.findElement(modalTitle);
				ConfrimationText = driver.findElement(confrimationText);
				PaymentAmountLabel = driver.findElement(paymentAmountLabel);
				PaymentAmount=driver.findElement(paymentAmount);
				CancelPayment = driver.findElement(cancelPayment);
				CloseIcon = driver.findElement(closeIcon);
				PaymentDueDate=driver.findElement(paymentDueDate);
				test.pass("Navigated to Payments Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());

			} catch (Exception e) {
				test.fail("Payments Page Error *********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public CancelPayment clickCancel(int index) throws IOException {
		// TODO Auto-generated method stub
		WebElement element = driver.findElement(By.xpath("//*[@id='main']/div[2]/div/article[2]/div["+index+"]/div[1]/div[2]/div[2]/button[1]"));
		element.click();
		CancelPayment cancelPayment=new CancelPayment();
		return cancelPayment;
	}
	
	public void clickEdit(int index) throws IOException {
		// TODO Auto-generated method stub
		WebElement element = driver.findElement(By.xpath("//*[@id='main']/div[2]/div/article[2]/div["+index+"]/div[1]/div[2]/div[2]/button[2]"));
		element.click();
	}

}