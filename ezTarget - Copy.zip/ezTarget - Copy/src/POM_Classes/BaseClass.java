package POM_Classes;

import static org.testng.Assert.fail;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Properties;
import java.util.Set;
import java.util.StringTokenizer;

import javax.net.ssl.HttpsURLConnection;

import org.apache.commons.io.FileUtils;
import org.apache.http.client.HttpResponseException;
import org.apache.log4j.Logger;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.json.simple.JSONObject;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.Point;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.os.WindowsUtils;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.server.Session;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.asserts.Assertion;
import com.aventstack.extentreports.MediaEntityBuilder;
import com.testrail.connection.APIClient;
import com.testrail.connection.APIException;

import atu.testrecorder.ATUTestRecorder;

import org.testng.Assert;
import org.testng.asserts.*;
import java.io.IOException;
import java.util.Properties;



public class BaseClass extends ReporterClass {

	public static WebDriver driver;
	//public static String targeturl = "URL";
	public static String targeturl = "URL";
	public static String Adminurl ="URL";
	public static String username = "target1234";
	public static String password = "Target111##";
	public static String transactionusername = "target1234";
	public static String transactionuserpassword = "Target111##";
	public static String unsuccessfulusername = "TestMCP0000";
	public static String unsuccessfulpassword = "Target11##";
	public ATUTestRecorder record;
	public String TestCaseId = null;
	public String TestCaseStatus;
	
	public List<String> expectedalertTypes = Arrays.asList("(Set amount) Transactions made in a single day","Account past due","Balance dropped below (set amount)","Balance exceeds (set amount)","Balance within (set amount) of credit limit","Card not present","Credit limit reached","Credit/return posted to my account","Foreign transaction or currency purchase","Payment due reminder","Payment posted to my account","Single purchase exceeds (set amount)");
	public static void launchUrl() throws IOException, InterruptedException {
		try {
			driver.quit();
		}
		catch(Exception e) {
			
		}
		
		try {
			System.setProperty("webdriver.ie.driver", "./IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			driver.get(targeturl);
			driver.manage().window().maximize();
			
			Thread.sleep(5000);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
	
	public static void launchAdminUrl() throws IOException, InterruptedException {
		try {
			driver.quit();
		}
		catch(Exception e) {
			
		}
		
		try {
			System.setProperty("webdriver.ie.driver", "./IEDriverServer.exe");
			driver = new InternetExplorerDriver();
			driver.get(Adminurl);
			driver.manage().window().maximize();
			
			Thread.sleep(5000);
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	public static void CleanCache() throws IOException, InterruptedException {
		Runtime.getRuntime().exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 2");
		Runtime.getRuntime().exec("RunDll32.exe InetCpl.cpl,ClearMyTracksByProcess 1");
		Thread.sleep(15000);
		Runtime.getRuntime().exec("taskkill /F /IM iexpore.exe");
		Runtime.getRuntime().exec("taskkill /F /IM iexpore *32.exe");
	}

	public String captureScreen() throws IOException {
		TakesScreenshot screen = (TakesScreenshot) driver;
		File src = screen.getScreenshotAs(OutputType.FILE);
		String dest = "./reports/" + System.currentTimeMillis() + ".png";
		File target = new File(dest);
		FileUtils.copyFile(src, target);
		return target.getAbsolutePath();	
	}

	public void AssertVerify(String actual, String expected) throws IOException {

		try {			
			Assert.assertEquals(expected, actual);			
			test.pass("Expected: " + expected + " and Actual Message: " + actual + " matched",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (AssertionError e) {
			System.out.println(actual);
			System.out.println(expected);
			//org.testng.Assert.fail("Assertion fail");
			test.fail("Expected: " + expected + " and Actual Message: " + actual + " is NOT matched",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			org.testng.Assert.fail("Assertion fail");
		}

	}
	
	public void AssertVerify(int actual, int expected) throws IOException {

		try {
			
			Assert.assertEquals(expected, actual);			
			test.pass("Expected: " + expected + " and Actual Message: " + actual + " matched",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (AssertionError e) {
			//org.testng.Assert.fail("Assertion fail");
			test.fail("Expected: " + expected + " and Actual Message: " + actual + " is NOT matched",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			org.testng.Assert.fail("Assertion fail");
		}

	}
	
	public void AssertVerify(boolean actual, boolean expected) throws IOException {

		try {
			Assert.assertEquals(expected, actual);
			test.pass("Expected: " + expected + " and Actual Message: " + actual + " matched",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (AssertionError e) {
			
			test.fail("Expected: " + expected + " and Actual Message: " + actual + " is NOT matched",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			org.testng.Assert.fail("Assertion fail");
		}

	}

	/*
	 * This method is used to update the result in Test Rail testCaseId and Status
	 * are the args. TestCase Id is run Id which starts with TXXXXX and Status is
	 * Passed/Failed/ etc.
	 */

	public static void updateResults(String testCaseId, String Status)
			throws MalformedURLException, IOException, APIException {
		APIClient client = new APIClient("https://testrail.fnis.com");
		client.setUser("e3020722");
		client.setPassword("Blabla0000$");
		String statusCode = null;
		if (Status.equalsIgnoreCase("Passed")) {
			statusCode = "1";
		} else if (Status.equalsIgnoreCase("Failed")) {
			statusCode = "5";
		} else if (Status.equalsIgnoreCase("Blocked")) {
			statusCode = "2";
		} else if (Status.equalsIgnoreCase("Untested")) {
			statusCode = "3";
		} else if (Status.equalsIgnoreCase("Retest")) {
			statusCode = "4";
		} else if (Status.equalsIgnoreCase("In Progress")) {
			statusCode = "6";
		}
		HashMap<String, String> data = new HashMap();
		data.put("status_id", statusCode);
		data.put("comment", "Eclipse Java TestNG frame work test is passed");
		JSONObject r = (JSONObject) client.sendPost("add_result/" + testCaseId + "", data);
	}

	
	/*
	 * This will clear the reports from the report path.
	 */
	public void clearreports() {
		File dir = new File("./reports");
		for (File file : dir.listFiles())
			if (!file.isDirectory())
				file.delete();
	}
	
	/*
	 * This method is used to check the links on the current page.
	 */

	public void brokenLink() throws IOException {
		List<WebElement> urllinks = driver.findElements(By.tagName("a"));
		for (int i = 0; i < urllinks.size(); i++) {
			WebElement urllink = urllinks.get(i);
			String link = urllink.getAttribute("href");
			if (link != null && !link.isEmpty()){	
				if(!link.contains("localhost") && !link.contains("tel") && !link.equalsIgnoreCase("http://target.com/"))
			verifylinkActive(link);
			}
		}
	}

	private void verifylinkActive(String link) throws IOException {
		if (link.length() > 0) {
			int responseCode = 0;
			try {
				if(link.equalsIgnoreCase("https://tgtprelim.fisglobal.com/External/Statements")) {
					link = "https://target-archive.fisglobal.com/Statement";
				}
				URL activelinks = new URL(link);

				System.setProperty("https.proxyHost", "proxy.fnfis.com");
				System.setProperty("https.proxyPort", "8080");
				HttpsURLConnection httpUrlConnect = (HttpsURLConnection) activelinks.openConnection();
				httpUrlConnect.usingProxy();
				httpUrlConnect.setConnectTimeout(30000);
				httpUrlConnect.connect();

				if (httpUrlConnect.getResponseCode() == 200) {
					System.out.println(link + "-------" + httpUrlConnect.getResponseCode() + " "
							+ httpUrlConnect.getResponseMessage());
				} else {
					responseCode = httpUrlConnect.getResponseCode();
					throw new HttpResponseException(httpUrlConnect.getResponseCode(), "");
				}
				test.pass("Broken Link is Passed on " + link);
			} catch (Exception e) {
				test.fail("Broken Link is Failed on " + link + "---" + responseCode);
			}
		}
	}
	
	/*
	 * This method is used to read the excel values from the Test Data file
	 * Arguments are SheetName and Rownumber
	 * Eg., SheetName is Sheet1 and Row is 1.
	 * The returned values are stored as K,V Pair in HashMap
	 */

	public static HashMap<String, String> ReadExcel(String SheetName, int Rownumber) throws IOException {
		// Define the File Folder
		XSSFWorkbook sourceBook = new XSSFWorkbook("./testdata.xlsx");
		XSSFSheet sourceSheet = sourceBook.getSheet(SheetName);
		int lastRowNumber = sourceSheet.getLastRowNum();
		int lastColumnNumber = sourceSheet.getRow(0).getLastCellNum();
		XSSFRow headerRow = sourceSheet.getRow(0);
		HashMap<String, String> ValuesMap = new HashMap<String, String>();
		for (int i = 0; i < lastColumnNumber; i++) {
			ValuesMap.put(headerRow.getCell(i).toString(), sourceSheet.getRow(Rownumber).getCell(i).toString());
		}
		return ValuesMap;

	}
	
	/*
	 * This method is used to select Drop down Values by Values, by Index and by Visible Text
	 */
	
	 public void selectDropDownByValue(WebElement element, String text) {
		
		 org.openqa.selenium.support.ui.Select select = new org.openqa.selenium.support.ui.Select(element);
		 select.selectByValue(text);		   
	   }
	 
	 public void selectDropDownByIndex(WebElement element, int index) {
			
		 org.openqa.selenium.support.ui.Select select = new org.openqa.selenium.support.ui.Select(element);
		 select.selectByIndex(index);		   
	   }
	 public void selectDropDownByVisibleText(WebElement element, String text) {
			
		 org.openqa.selenium.support.ui.Select select = new org.openqa.selenium.support.ui.Select(element);
		 select.selectByVisibleText(text);		   
	   }
	 
	 /*
	  * This class is used to define constansts for the Alert Me When Drop Downs.	  * 
	  */
	 
	public static class AlertMeConstants{
		public static String PaymentDueReminder = "Payment due reminder";
		public static String PaymentReturned = "Credit/return posted to my account";
		public static String SetamountTransactionsmadeinasingleday= "(Set amount) Transactions made in a single day";
		public static String ACreditotherthanpaymentpoststomyaccount = "Card not present";
		public static String AtransactionhasoccurredoutsidetheUS = "Foreign transaction or currency purchase";
		public static String AccountPastDue ="Account past due";
		public static String Availablebalancedropsbelow = "Balance dropped below (set amount)";
		public static String Balanceexceeds = "Balance exceeds (set amount)";
		public static String Balancewithinsetamountofcreditlimit = "Balance within (set amount) of credit limit";
		public static String CreditLimitreached ="Credit limit reached"; 
		public static String Paymentpostedtomyaccount = "Payment posted to my account";		
		public static String Singlepurchaseexceedssetamount = "Single purchase exceeds (set amount)";
	}
	
	/*
	 * This login method is used for other than login modules.
	 *///
	
	public void LoginApplication(String username, String password) throws IOException, InterruptedException {
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(username);
		/*WebDriverWait wait = new WebDriverWait(driver, 60);		
		wait.until(waitForAjaxCalls());*/
		Thread.sleep(15000);
		if(driver.getCurrentUrl().contains("Security")) {
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		securityquestionPage.securityAnswerValidator();
		}
		PasswordPage passwordPage = new PasswordPage();
		passwordPage.passwordValidator(password);
		//Thread.sleep(60000);
	}
	
	public boolean VerifyElementIsDispalyed(WebElement element) {
		boolean flag = false;
		try {
		if(element.isDisplayed()) {
		flag = true;
		}
		}
		catch(Exception e){
			flag = false;
		}
		return flag;	
	}
	
	public boolean VerifyLocatorIsDispalyed(By by) {
		boolean flag = false;
		try {
		if(driver.findElement(by).isDisplayed()) {
		flag = true;
		}
		}
		catch(Exception e){
			flag = false;
		}
		return flag;	
	}
	
	public String getTextForWebElement(WebElement element) {	
		String value = element.getText();
		return value;
	}
	
	public void closeBrowsers() {
		try {
			driver.close();
			WindowsUtils.killByName("IEDriverServer.exe");
			Runtime.getRuntime().exec("taskkill /F /IM IEDriverServer.exe");
			Runtime.getRuntime().exec("taskkill /F /IM iexpore.exe");
			Runtime.getRuntime().exec("taskkill /F /IM iexpore *32.exe");
		}
		catch(Exception e) {
			
		}
	}
	
	public static class CardTypes {
		public static String CreditCard = "Credit";
		public static String DebitCard = "Debit";
	}
	
	public static class ReportTypes{
		public static String CSVFormat = "csv";
		public static String QBOFormat = "qbo";
		public static String QFXFormat = "qfx";
		public static String TabFormat = "tab";
	}
	public static class GetInputData {
		public static String GetMerchantName = "GetMerchantName";
		public static String GetAmount = "GetAmount";
		public static String GetCategory = "GetCategory";
	}

	public void ScrollToElement(WebElement element) {
		Point pos = element.getLocation();
		int xoff = pos.getX();
		JavascriptExecutor jse = (JavascriptExecutor) driver;
		jse.executeScript("window.scrollBy(0," + xoff + ")", "");
	}
	
	public LocalDate DateValue(String string) {
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MMM dd, yyyy", Locale.ENGLISH);
		LocalDate date = LocalDate.parse(string, formatter);
		return date;
	}
	
	public String getFullMonth(String string) {
		String month=null;
		switch(string) {
		case "Jul":
		month ="July";
		break;	
		case "Jun":
			month ="June";
			break;	
		case "May":
			month ="May";
			break;	
		case "Apr":
			month ="April";
			break;	
		case "Mar":
			month ="March";
			break;	
		case "Feb":
			month ="February";
			break;	
		case "Jan":
			month ="January";
			break;	
		case "Aug":
			month ="August";
			break;	
		case "Sep":
			month ="September";
			break;	
		case "Oct":
			month ="October";
			break;	
		case "Nov":
			month ="November";
			break;	
		case "Dec":
			month ="December";
			break;	
		}
		return month;
	}
	
	public static String getLatestFilefromDir() throws InterruptedException{
		Thread.sleep(40000);
		String dirPath = "C:/Users/e3020722/Downloads";
	    File dir = new File(dirPath);
	    File[] files = dir.listFiles();
	    System.out.println(files);
	    if (files == null || files.length == 0) {
	        return null;
	    }
	
	    File lastModifiedFile = files[0];
	    for (int i = 1; i < files.length; i++) {
	       if (lastModifiedFile.lastModified() < files[i].lastModified()) {
	           lastModifiedFile = files[i];
	       }
	    }
	    return lastModifiedFile.getName();
	}
	
	public static void clearExportFiles() {
		File dir = new File("C:/Users/e3020722/Downloads");		
		for (File f : dir.listFiles()) {
		    if (f.getName().startsWith("Transactions_")) {
		        f.delete();
		    }
		}
	}
	public void clickOnSave() throws AWTException, InterruptedException, IOException {

        	Runtime.getRuntime().exec("C:\\Users\\e3020722\\eclipse-workspace\\ezTarget\\libs\\ClickOnSave.exe");
			//press s key to save
			/*Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_ESCAPE);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_F6);
			Thread.sleep(2000);
			robot.keyPress(KeyEvent.VK_TAB);
	        Thread.sleep(2000);
	        robot.keyRelease(KeyEvent.VK_ENTER);
	        Thread.sleep(2000);*/
	        
	        
		}
	
	/*public void DownloadAndSaveReport(String type) throws IOException, InterruptedException, FindFailed {
		Screen screen = new Screen();		
		if(type.equals("csv")) {
		screen.click("./libs/csv.png");
		}
		if(type.equals("qbo")) {
			screen.click("./libs/qbo.png");
			}
		if(type.equals("tab")) {
			screen.click("./libs/tab.png");
			}
		if(type.equals("qfx")) {
			screen.click("./libs/qfx.png");
			}
		Thread.sleep(7000);
		test.info("Download Prompt", MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		screen.click("./libs/save.png");
		test.info("Download complete", MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
	
	}*/
	
	public static ArrayList<LinkedHashMap> ReadFiles(String split, String filename) throws IOException {
       ArrayList<LinkedHashMap> exportData = new ArrayList<>(); 
       //String splitBy = "	";
       BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\e3020722\\Downloads\\"+filename));
       //Header
       String header = br.readLine();
       String[] headervalues = header.split(split);
       System.out.println(headervalues.length);
       for(int i =0;i<headervalues.length;i++) {
    	   System.out.println(headervalues[i]);
       }
       String line = br.readLine();
              
       while ((line = br.readLine()) !=null) {
    	   LinkedHashMap<String, String> rowValues = new LinkedHashMap<>();
    	   String[] b = line.split(split);
           for(int j=0;j<headervalues.length;j++) {
        	   //System.out.println(split);
        	   //System.out.println(b[j]);
        	   if(split.equals(",")) {
         		  if(b[j].contains("$") && !b[j+1].startsWith("\"")) {
         			  b[j]=b[j]+","+b[j+1];         			  
         		  }
         		 if(!b[j].startsWith("\"") && b[j].length()>0) {
        			  b[j]=b[j+1];         			  
        		  }
         	   }
        	   rowValues.put(headervalues[j], b[j]);
        	   
           }
    	   //System.out.println(b[10]);
           exportData.add(rowValues);
    	 }
       
       System.out.println(exportData);
       br.close();
       return exportData;
	}
	
	
	public void compareUIAndExportData(ArrayList<LinkedHashMap> exportData, ArrayList<LinkedHashMap> uiData) throws IOException {
		int size =uiData.size();
		for(int i=0;i<size;i++) {
			System.out.println("ith Value:"+i);
			String type;
			if(exportData.get(i).get("Amount").toString().contains("(") == true)
			{
				type = "Credit";
			}
			else {
				type = "Debit";
			}
			AssertVerify(type, exportData.get(i).get("Type").toString().replace("\"", ""));
			AssertVerify(uiData.get(i).get("Original Amount").toString(), exportData.get(i).get("Amount").toString().replace("\"", "").replace("(", "").replace(")", ""));
			AssertVerify(uiData.get(i).get("Merchant Description").toString(), exportData.get(i).get("Description").toString().replace("\"", ""));
			AssertVerify(uiData.get(i).get("Transaction Type").toString(), exportData.get(i).get("Transaction Type").toString().replace("\"", ""));			
			AssertVerify(uiData.get(i).get("Originating Account #").toString().contains("*"),true);
			AssertVerify(uiData.get(i).get("Originating Account #").toString().replace("*", "XXXX-"), exportData.get(i).get("Originating Account Last 4").toString().replace("\"", ""));
			//AssertVerify(convertDateToExportFormat(uiData.get(i).get("Transaction Date").toString()), exportData.get(i).get("Trans Date").toString().replace("\"", ""));
			AssertVerify(uiData.get(i).get("Merchant").toString(), exportData.get(i).get("Merchant Name").toString().replace("\"", ""));
			String Category = uiData.get(i).get("Category").toString();
			//Work Around for Temp fix due to data issue which is reported
			if(Category.equalsIgnoreCase("Household") && uiData.get(i).get("Merchant").toString().equalsIgnoreCase("TEST CREDIT TRANSACTION")) {
			Category="Clothing"	;
			}
			AssertVerify(Category, exportData.get(i).get("Category").toString().replace("\"", ""));
			//AssertVerify(convertDateToExportFormat(uiData.get(i).get("Transaction Date").toString()), exportData.get(i).get("Posting Date").toString().replace("\"", ""));
			if(uiData.get(i).containsKey("Reference Number") && exportData.get(i).get("Reference Number").toString().length()>0) {
				AssertVerify(uiData.get(i).get("Reference Number").toString(), exportData.get(i).get("Reference Number").toString().replace("\"", ""));
			}
			
		}		
	}

	public String convertDateToExportFormat(String value) {
		
		LocalDate date = DateValue(value);
		DateTimeFormatter formatters = DateTimeFormatter.ofPattern("MM/dd/uuuu");
		String text = date.format(formatters);
		LocalDate parsedDate = LocalDate.parse(text, formatters);
		System.out.println("date: " + date);
		System.out.println("Text format " + text);
		System.out.println("parsedDate: " + parsedDate.format(formatters));
		return parsedDate.format(formatters);
	}
	
	public int numberofPages(String numberofTransactions) {
		int Pages = Integer.parseInt(numberofTransactions) / 10;

		int reminder = Integer.parseInt(numberofTransactions) % 10;
		int numberofPages;
		if (Integer.parseInt(numberofTransactions) <= 10) {
			numberofPages = 1;
		} else {
			if (reminder == 0) {
				numberofPages = Pages;
			} else {
				numberofPages = Pages + 1;
			}
		}
		return numberofPages;
	}
	
	public static ExpectedCondition<Boolean> waitForAjaxCalls() {
        return new ExpectedCondition<Boolean>() {
            @Override
            public Boolean apply(WebDriver driver) {
                return Boolean.valueOf(((JavascriptExecutor) driver).executeScript("return (window.angular !== undefined) && (angular.element(document).injector() !== undefined) && (angular.element(document).injector().get('$http').pendingRequests.length === 0)").toString());
            }
        };
    }
	
	public static void CreateMessage() throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://vwcapeztgtwb.fisdev.local/DesignStudioSaml");
		WebDriverWait wait = new WebDriverWait(driver, 90);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='userList']")));
		driver.findElement(By.xpath("//*[@id='userList']")).click();
		driver.findElement(By.xpath("//*[@id='userList']")).sendKeys("TargetFullMixUser (Target client with both DS and CS)");
		driver.findElement(By.xpath("//*[@id='userList']")).click();
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='main']/div/div/div[1]/form/div[4]/input")));
		driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/form/div[4]/input")).sendKeys(transactionusername);
		driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/form/div[7]/button[1]")).click();
		Thread.sleep(1000);
		String accountId = driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/table/tbody/tr/td[2]/button")).getText();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id='main-menu']/ul/li[2]/a")).click();
		Thread.sleep(5000);
		//Create New Case
		driver.findElement(By.xpath("//*[@id='main']/div[1]/div[2]/button[3]")).click();
		
		driver.findElement(By.xpath("//*[@id='main']/div[1]/div/article/div/div[2]/div/div[1]/input")).sendKeys(accountId);
		driver.findElement(By.xpath("//*[@id='main']/div[1]/div/article/div/div[2]/div/div[2]/select")).click();
		driver.findElement(By.xpath("//*[@id='main']/div[1]/div/article/div/div[2]/div/div[2]/select")).sendKeys("General Inquiry");
		driver.findElement(By.xpath("//*[@id='main']/div[1]/div/article/div/div[2]/div/div[2]/select")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[contains(@id, 'taTextElement')]")).sendKeys("Test Message for Message Icon");
		driver.findElement(By.xpath("//*[@id='main']/div[1]/div/article/div/div[2]/div/button")).click();
		driver.quit();
	}
	

	public static void DisableOnlineAccessandEnrollNow(String disableuser) throws InterruptedException {
		// TODO Auto-generated method stub
		//System.setProperty("webdriver.ie.driver", "./IEDriverServer.exe");
		System.setProperty("webdriver.chrome.driver", "./chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("http://vwcapeztgtwb.fisdev.local/DesignStudioSaml");
		WebDriverWait wait = new WebDriverWait(driver, 300);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='userList']")));
		driver.findElement(By.xpath("//*[@id='userList']")).click();
		driver.findElement(By.xpath("//*[@id='userList']")).sendKeys("TargetFullMixUser (Target client with both DS and CS)");
		driver.findElement(By.xpath("//*[@id='userList']")).click();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//*[@id='submit']")).click();
		Thread.sleep(10000);
		wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id='main']/div/div/div[1]/form/div[4]/input")));
		driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/form/div[4]/input")).sendKeys(disableuser);
		//driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/form/div[2]/input")).sendKeys("00000004349");
		driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/form/div[7]/button[1]")).click();
		Thread.sleep(10000);
		driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/table/tbody/tr/td[2]/button")).click();
		Thread.sleep(30000);
		driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/article/div[2]/article[1]/ul[2]/li[1]/button")).click();
		driver.findElement(By.xpath("//button[(text() = 'Confirm' or . = 'Confirm')]")).click();
		Thread.sleep(30000);
		driver.findElement(By.xpath("//*[@id='main']/div/div/div[1]/article/div[1]/article[1]/div[1]/div/h3/button")).click();;
		driver.findElement(By.name("username")).sendKeys(disableuser);
		driver.findElement(By.name("userNickname")).sendKeys(disableuser);
		driver.findElement(By.name("newEmail")).sendKeys("chandrasekaran.ganapathy@fisglobal.com");
		driver.findElement(By.name("emailRetype")).sendKeys("chandrasekaran.ganapathy@fisglobal.com");
		driver.findElement(By.name("password")).sendKeys("TargetTemp22##");
		driver.findElement(By.name("passwordConfirm")).sendKeys("TargetTemp22##");
		driver.findElement(By.xpath("/html/body/div[3]/div/div/form/div[2]/input")).click();	
		Thread.sleep(30000);
		driver.quit();	
	}
	
	public ArrayList<String> getWindowHandles() {
		boolean flag = false;
		ArrayList<String> titles= new ArrayList<>();
		Set<String> allWindows = driver.getWindowHandles();
		System.out.println(allWindows);	
		for (String changewindow:allWindows){
			driver.switchTo().window(changewindow);
			System.out.println("Title is "+ driver.getTitle());
			/*if(driver.getTitle().equalsIgnoreCase(windowName)){
				flag = true;
				//driver.close();
				return flag;
			}*/
			if(!driver.getTitle().equalsIgnoreCase("Home - RCAM"))
			titles.add(driver.getTitle());
			
		}
		return titles;
	}
	
	public String getPreviousDate(String input) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMMM-dd");
		Date myDate = dateFormat.parse(input);
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(myDate);
		cal1.add(Calendar.DAY_OF_YEAR, -1);
		Date previousDate = cal1.getTime();
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMM dd, YYYY");
		String yesDate = dateFormat1.format(previousDate); 
		System.out.println(yesDate);
		return yesDate;
	}
	
	public String getFutureDate(String input,int datedifference) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MMMM-dd");
		Date myDate = dateFormat.parse(input);
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(myDate);
		cal1.add(Calendar.DAY_OF_YEAR, datedifference);
		Date previousDate = cal1.getTime();
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMMM-dd-YYYY");
		String yesDate = dateFormat1.format(previousDate); 
		System.out.println(yesDate);
		return yesDate;
	}
	

	public String getPastDate(String input,int datedifference) throws ParseException {
		SimpleDateFormat dateFormat = new SimpleDateFormat("MMM dd, yyyy");
		Date myDate = dateFormat.parse(input);
		Calendar cal1 = Calendar.getInstance();
		cal1.setTime(myDate);
		cal1.add(Calendar.DAY_OF_YEAR, datedifference);
		Date previousDate = cal1.getTime();
		SimpleDateFormat dateFormat1 = new SimpleDateFormat("MMM dd, yyyy");
		String yesDate = dateFormat1.format(previousDate); 
		System.out.println(yesDate);
		return yesDate;
	}
	
}
