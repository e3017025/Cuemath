package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class Agreements extends BaseClass{
	
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span");
		
		private By instruction=By.xpath("//*[@id='main']/div/div[2]/span");
		private By agreementBlock=By.xpath("//*[@id='main']/div/div[3]");
		private By agreeandcontinue=By.xpath("//*[@id='main']/div/div[3]/div[2]/button");
		
		
		public WebElement WelcomeHeader,WelcomeMessage,Instruction,AgreementBlock,AgreeAndContinue;
		
		public Agreements() throws IOException {
			try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.presenceOfElementLocated(instruction));
			wait.until(ExpectedConditions.presenceOfElementLocated(welcomeMessage));
			WelcomeHeader=driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			Instruction=driver.findElement(instruction);
			AgreementBlock=driver.findElement(agreementBlock);
			AgreeAndContinue=driver.findElement(agreeandcontinue);
			test.pass("Navigating Agreement Infoamtion Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) {
				test.fail("Failed on Navigating Agreement Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
			}
			
		}	
		
		public class NextAgreement extends BaseClass{
			
			private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
			private By welcomeMessage = By.cssSelector("#mainHeading > span");
			
			private By instruction=By.xpath("//*[@id='main']/div/div[2]/span");
			private By agreementBlock=By.xpath("//*[@id='main']/div/div[3]");
			private By agreeandcontinue=By.xpath("//*[@id='main']/div/div[3]/div[2]/button");
			
			
			public WebElement WelcomeHeader,WelcomeMessage,Instruction,AgreementBlock,AgreeAndContinue;
			
			public NextAgreement() throws IOException {
				try {
				WebDriverWait wait = new WebDriverWait(driver, 120);
				wait.until(ExpectedConditions.presenceOfElementLocated(instruction));
				wait.until(ExpectedConditions.presenceOfElementLocated(welcomeMessage));
				WelcomeHeader=driver.findElement(welcomeHeader);
				WelcomeMessage=driver.findElement(welcomeMessage);
				Instruction=driver.findElement(instruction);
				AgreementBlock=driver.findElement(agreementBlock);
				AgreeAndContinue=driver.findElement(agreeandcontinue);
				test.pass("Navigating Agreement Infoamtion Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				}
				catch(Exception e) {
					test.fail("Failed on Navigating Agreement Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
				}
				
			}	
	}
		
	public class WelcomePage{
			
			private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
			private By currentStep =By.xpath("//*[@id='loginPageHeader']/span[1]");
			private By currentStepName = By.xpath("//*[@id='loginPageHeader']/span[2]");
			private By welcomeMessage = By.cssSelector("#mainHeading");
			
			private By instruction=By.xpath("//*[@id='main']/div/div[2]/div/div/div[1]/div[1]");
			private By next=By.xpath("//*[@id='main']/div/div[2]/div/div/div[2]/button");
			private By image=By.xpath("//*[@id='main']/div/div[2]/div/div/div[1]/div[2]/img");
			
			
			public WebElement WelcomeHeader,WelcomeMessage,CurrentStep,CurrentStepName,Instruction,Next,Image;
			
			public WelcomePage() throws IOException {
				try {
				WebDriverWait wait = new WebDriverWait(driver, 120);
				wait.until(ExpectedConditions.presenceOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.presenceOfElementLocated(welcomeMessage));
				WelcomeHeader=driver.findElement(welcomeHeader);
				WelcomeMessage=driver.findElement(welcomeMessage);
				CurrentStep=driver.findElement(currentStep);
				CurrentStepName=driver.findElement(currentStepName);
				Instruction=driver.findElement(instruction);
				Next=driver.findElement(next);
				Image=driver.findElement(image);				
				test.pass("Navigating Agreement Infoamtion Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				}
				catch(Exception e) {
					test.fail("Failed on Navigating Agreement Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
				}
				
			}	
	}
		
	public class ActivateCard{
		
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By currentStep =By.xpath("//*[@id='loginPageHeader']/span[1]");
		private By currentStepName = By.xpath("//*[@id='loginPageHeader']/span[2]");
		private By welcomeMessage = By.xpath("//*[@id='mainHeading']/span");
		
		private By selectcard=By.xpath("//*[@id='selectAccount']");
		private By cvv=By.id("cvv");
		private By activate=By.xpath("//*[@type = 'submit' and @class = 'btn btn-sm btn-primary']");
		private By skiptoNext=By.xpath("//*[@type = 'submit' and @class = 'btn btn-sm btn-secondary']");

		
		public WebElement WelcomeHeader,WelcomeMessage,CurrentStep,CurrentStepName,Skip,SelectAccount,Activate,CVV;
		
		public ActivateCard() throws IOException {
			try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.presenceOfElementLocated(currentStep));
			wait.until(ExpectedConditions.presenceOfElementLocated(welcomeMessage));
			WelcomeHeader=driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			CurrentStep=driver.findElement(currentStep);
			CurrentStepName=driver.findElement(currentStepName);
			SelectAccount=driver.findElement(selectcard);
			CVV=driver.findElement(cvv);
			Activate=driver.findElement(activate);
			Skip=driver.findElement(skiptoNext);
			test.pass("Navigating Agreement Infoamtion Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) {
				test.fail("Failed on Navigating Agreement Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
			}
			
		}	
}
	public class StatementDelivery{
		
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By currentStep =By.xpath("//*[@id='loginPageHeader']/span[1]");
		private By currentStepName = By.xpath("//*[@id='loginPageHeader']/span[2]");
		private By welcomeMessage = By.xpath("//*[@id='mainHeading']/span");
		
		private By electroniconly=By.id("paperless-yes");
		private By mail=By.id("paperless-no");
		private By skiptoNext=By.xpath("//*[@type = 'button' and @class = 'btn btn-sm btn-secondary pull-right']");
		private By agree=By.xpath("//*[@type = 'button' and @class = 'btn btn-sm btn-primary']");
		//*[@class = 'btn btn-sm btn-primary']
		
		
		public WebElement WelcomeHeader,WelcomeMessage,CurrentStep,CurrentStepName,Skip,ElectronicOnly,Mail,Agree;
		
		public StatementDelivery() throws IOException {
			try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.presenceOfElementLocated(currentStep));
			wait.until(ExpectedConditions.presenceOfElementLocated(welcomeMessage));
			WelcomeHeader=driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			CurrentStep=driver.findElement(currentStep);
			CurrentStepName=driver.findElement(currentStepName);
			ElectronicOnly=driver.findElement(electroniconly);
			Mail=driver.findElement(mail);
			//Skip=driver.findElement(skiptoNext);
			Agree=driver.findElement(agree);
			test.pass("Navigating Agreement Infoamtion Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) {
				test.fail("Failed on Navigating Agreement Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
			}
			
		}	
}
public class GettingStarted{
		
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By currentStep =By.xpath("//*[@id='loginPageHeader']/span[1]");
		private By currentStepName = By.xpath("//*[@id='loginPageHeader']/span[2]");
		private By welcomeMessage = By.xpath("//*[@id='mainHeading']");
		

		private By complete=By.xpath("//button[@class = 'btn btn-sm btn-primary']");
		private By image=By.xpath("//*[@id='main']/div/div[2]/div/div/div[1]/div[2]/img");
		
	
		
		
		public WebElement WelcomeHeader,WelcomeMessage,CurrentStep,CurrentStepName,Complete;
		
		public GettingStarted() throws IOException {
			try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.presenceOfElementLocated(currentStep));
			wait.until(ExpectedConditions.presenceOfElementLocated(welcomeMessage));
			WelcomeHeader=driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			CurrentStep=driver.findElement(currentStep);
			CurrentStepName=driver.findElement(currentStepName);
			Complete =driver.findElement(complete);
			test.pass("Navigating Agreement Infoamtion Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) {
				test.fail("Failed on Navigating Agreement Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
			}
			
		}	
}

public class confirmDeliveryMethod {
	private By modalHeader = By.xpath("//*[@id='dialogTitle']");
	private By modalDescription = By.xpath("//*[@id='dialogDesc']");

	private By cancel=By.xpath("//*[@type = 'button' and @class = 'btn btn-sm']");
	private By confirm=By.xpath("//*[@type = 'button' and @class = 'btn btn-primary btn-sm']");
	private By closeIcon=By.xpath("//*[@id='app']/body/div[4]/form/div/div/div[1]/button/span[1]");
	
	
	
	public WebElement ModalHeader,ModalDescription,Cancel,Confirm,CloseIcon;
	
	public confirmDeliveryMethod() throws IOException {
		try {
		WebDriverWait wait = new WebDriverWait(driver, 120);
		wait.until(ExpectedConditions.presenceOfElementLocated(modalHeader));
		wait.until(ExpectedConditions.presenceOfElementLocated(modalDescription));
		ModalHeader=driver.findElement(modalHeader);
		ModalDescription=driver.findElement(modalDescription);
		Cancel=driver.findElement(cancel);
		CloseIcon=driver.findElement(closeIcon);
		Confirm =driver.findElement(confirm);
		
		test.pass("Navigating Agreement Infoamtion Page",
				MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
		catch(Exception e) {
			test.fail("Failed on Navigating Agreement Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
		}
		
	}	
}
}