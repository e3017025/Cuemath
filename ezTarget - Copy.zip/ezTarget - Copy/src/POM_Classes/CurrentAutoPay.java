package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class CurrentAutoPay extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
	private By currentAutoPayTitle=By.cssSelector("#main > div.module.module-dark.max-800.center > div > h2");
	public String expectedTitle="Current Auto Pay";
	
	private By card=By.cssSelector("#main > div.module.module-dark.max-800.center > div > p:nth-child(2) > span");
	private By payFrom=By.cssSelector("#main > div.module.module-dark.max-800.center > div > p:nth-child(3) > span");
	private By planType=By.cssSelector("#main > div.module.module-dark.max-800.center > div > div:nth-child(4) > p:nth-child(1) > span");
	private By paymentAmountLabel=By.xpath("//span[(text() = 'Payment Amount:' or . = 'Payment Amount:')]");	
	private By paymentAmount=By.xpath("//*[@id='main']/div[2]/div/div[1]/p[2]/span[2]");
	private By lastPaymentDate=By.cssSelector("#main > div.module.module-dark.max-800.center > div > div:nth-child(5) > p > span");
	private By nextPaymentDate= By.cssSelector("#main > div.module.module-dark.max-800.center > div > div:nth-child(6) > p > span.text-bold");
	private By autoPaypreText=By.xpath("//*[@data-ng-if = 'vm.currentAccount.currentCycleDate']");
	public String expectedAutoPayPreText="Auto Pay management is unavailable from 5:00 p.m. Central Time on your payment due date until 7:00 a.m. Central Time of the next business day.";
	private By returnToSummary=By.xpath("//a[@href = '#/PaymentOverview' and (text() = 'Return to Summary' or . = 'Return to Summary')]");
	
	private By resumeAutoPay=By.cssSelector("#main > div.module.module-dark.max-800.center > div > div.text-right > button:nth-child(2)");
	private By suspendAutoPay=By.cssSelector("#main > div.module.module-dark.max-800.center > div > div.text-right > button:nth-child(2)");
	private By cancelAutoPay=By.cssSelector("#main > div.module.module-dark.max-800.center > div > div.text-right > button:nth-child(3)");
	private By cancelAndCreateNewAutoPay=By.cssSelector("#main > div.module.module-dark.max-800.center > div > div.text-right > button:nth-child(4)");
	
	
	public WebElement WelcomeMessage, WelcomeHeader,CurrentAutoPayTitle,Card,PayFrom,PlanType,PaymentAmountLabel,PaymentAmount,
	LastPaymentDate,NextPaymentDate,AutoPayPreText,ReturnToSummary,ResumeAutoPay,SuspendAutoPay,CancelAutoPay,CancelAndCreateNewAutoPay;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public CurrentAutoPay() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			WelcomeHeader = driver.findElement(welcomeHeader);			
			WelcomeMessage = driver.findElement(welcomeMessage);
			CurrentAutoPayTitle=driver.findElement(currentAutoPayTitle);
			Card=driver.findElement(card);
			PayFrom=driver.findElement(payFrom);
			PlanType=driver.findElement(planType);
			PaymentAmountLabel=driver.findElement(paymentAmountLabel);
			PaymentAmount=driver.findElement(paymentAmount);
			LastPaymentDate=driver.findElement(lastPaymentDate);
			NextPaymentDate=driver.findElement(nextPaymentDate);
			AutoPayPreText=driver.findElement(autoPaypreText);
			ReturnToSummary=driver.findElement(returnToSummary);
			ResumeAutoPay=driver.findElement(resumeAutoPay);
			CancelAutoPay=driver.findElement(cancelAutoPay);
			CancelAndCreateNewAutoPay=driver.findElement(cancelAndCreateNewAutoPay);			
			test.pass("Payment Step 1",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail("Payment Step 1 Page Error ********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
	
	public class CancelAutoPayModal {
		
		private By modalTitle=By.cssSelector("body > div.modal.no-print.top.am-fade > form > div > div > div.modal-header > h3");
		private By closeIcon=By.cssSelector("body > div.modal.no-print.top.am-fade > form > div > div > div.modal-header > button > span:nth-child(1)");
		private By confirmationText=By.cssSelector("body > div.modal.no-print.top.am-fade > form > div > div > div:nth-child(2) > div.modal-body");
		private By cancelAutoPay=By.cssSelector("body > div.modal.no-print.top.am-fade > form > div > div > div:nth-child(2) > div.modal-footer > div:nth-child(2) > button");
		public String expectedConfirmationText="Are you sure you want to cancel your current Auto Pay and create a new one?";
		public String expectedModalTitle="Are you sure you want to cancel Auto Pay?";
		public String expectedConfirmationText1="Please Note: canceling Auto Pay does not relieve your obligation from paying your monthly bill.";

		public WebElement ModalTitle,CloseIcon,ConfirmationText,CancelAutoPay;
		
		public CancelAutoPayModal() throws IOException {
			try {
			ModalTitle=driver.findElement(modalTitle);
			CloseIcon=driver.findElement(closeIcon);
			ConfirmationText=driver.findElement(confirmationText);
			CancelAutoPay=driver.findElement(cancelAutoPay);
			test.pass("Confirmation Modal",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch (Exception e) {
				test.fail("Confirmation Modal Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
		
	}
	
public class SuspendAutoPayModal {
		//Work is Not yet completed......
		private By modalTitle=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > strong");
		
		private By submit=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(1) > button");
		private By cancel=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > button");
		public By close=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(2) > button");
		public WebElement Submit,Cancel;
		
		public SuspendAutoPayModal() {
		Submit=driver.findElement(submit);
		Cancel=driver.findElement(cancel);
			
		}
		
	}
	
}