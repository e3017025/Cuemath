package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

import POM_Classes.CurrentAutoPay.CancelAutoPayModal;

public class ManageAutoPay extends BaseClass {
	//private static final String ManageAutoPay = null;
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
	public static String expectedWelcomeMessage = "Manage Auto Pay";
	private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
	
	private By addPaymentAccount = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.sm-and-up.form-stacked > div.text-small > span");
	private By selectAccount = By.xpath("//*[@id='paymentAccount']");
	private By returnPaymentSummary = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
	private By next= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(4) > button");
	private By step1=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.sm-and-up.form-stacked > h3 > strong");
	public static String expectedStep1Text = "Step 1 of 5: Choose a bank account";
	private By accountHelpIcon = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.sm-and-up.form-stacked > h3 > button > span.icon-info-circled");
	
	private By autopayPreText = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.module.module-condensed > p");
	private By paymentInformationTitle =By.xpath("//*[@id='main']/article/div/div[2]/div/p/span");
	private By paymentInformationNote = By.xpath("//*[@id='main']/article/div/div[2]/div/p");
	private By accountStep = By.xpath("//*[@id='step1']/span");
	private By amountStep = By.xpath("//*[@id='step2']/span");
	private By dateStep = By.xpath("//*[@id='step3']/span");
	private By reviewStep = By.xpath("//*[@id='step4']/span");
	private By confirmationStep = By.xpath("//*[@id='step5']/span");
	public static String expectedPaymentInformationTitle = "Payment Information:";
	public static String expectedPaymentInformationNote = "Payment Information:With Auto Pay, your REDcard account is paid automatically from your selected bank account each month on your payment due date, as indicated on your monthly statement. You can only have one Auto Pay plan set up on your account.";
	public static String ExpectedAutoPayPreText="Please Note: Auto Pay management is unavailable from 5:00 p.m. Central Time on your payment due date until 7:00 a.m. Central Time of the next business day."; 
	
	
	public WebElement WelcomeMessage, ReturnPaymentSummary, Next, WelcomeHeader,PaymentHelpIcon,AddPaymentAccount,AutoPayPreText,
	SelectAccount,Step1,AccountHelpIcon,PaymentInformationTitle,PaymentInformationNote,AccountStep,AmountStep,DateStep,ReviewStep,ConfirmationStep;
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public ManageAutoPay() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			wait.until(ExpectedConditions.visibilityOfElementLocated(addPaymentAccount));
			WelcomeHeader = driver.findElement(welcomeHeader);			
			WelcomeMessage = driver.findElement(welcomeMessage);
			PaymentHelpIcon=driver.findElement(paymenthelpIcon);
			AddPaymentAccount=driver.findElement(addPaymentAccount);
			SelectAccount = driver.findElement(selectAccount);
			Step1=driver.findElement(step1);
			AccountHelpIcon=driver.findElement(accountHelpIcon);
			PaymentInformationTitle=driver.findElement(paymentInformationTitle);
			PaymentInformationNote =driver.findElement(paymentInformationNote);
			AccountStep=driver.findElement(accountStep);
			AmountStep =driver.findElement(amountStep);
			DateStep=driver.findElement(dateStep);
			ReviewStep=driver.findElement(reviewStep);
			ConfirmationStep =driver.findElement(confirmationStep);
			ReturnPaymentSummary = driver.findElement(returnPaymentSummary);
			Next = driver.findElement(next);	
			AutoPayPreText=driver.findElement(autopayPreText);
			test.pass("Payment Step 1",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail("Payment Step 1 Page Error ********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
	
	public class ManageAutoPayAmountSelection {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
		public static final String expectedWelcomeMessage = "Manage Auto Pay";
		private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
		private By amountHelpIcon=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.sm-and-up > h3 > button > span.icon-info-circled");
		
		private By returnToSummary = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
		private By back=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(1) > button");
		private By next= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(2) > button");
		
		private By step2=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.sm-and-up > h3 > strong");
		public static final String expectedStep2Text = "Step 2 of 5: Select the amount to be paid each month";
		
		private By minimumDueRadioButton=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.sm-and-up > label:nth-child(3) > span.col-c-70 > input");
		private By minimumDueAmountLabel=By.xpath("//*[@id='main']/article/div/div[2]/div/div[2]/label[1]/span[1]/span");
		private By minimumDueAmount=By.xpath("//*[@id='main']/article/div/div[2]/div/div[2]/label[1]/span[2]/span");
		
		private By lastStatementBalanceRadioButton = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.sm-and-up > label:nth-child(5) > span.col-c-70 > input");
		private By lastStatementBalanceLabel = By.xpath("//*[@id='main']/article/div/div[2]/div/div[2]/label[2]/span[1]/span");
		private By lastStatementBalanceAmount = By.xpath("//*[@id='main']/article/div/div[2]/div/div[2]/label[2]/span[2]/span");
		
		private By fixedAmountRadioButton = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.sm-and-up > label:nth-child(7) > input");
		private By fixedAmountInputText = By.xpath("id('main')/article[@class='module module-dark max-800 center']/div[@class='wizard']/div[@class='clearfix basic-animation']/div[@class='module module-condensed']/div[@class='sm-and-up']/div[@class='form-stacked']/div[1]/div[@class='col-40']/div[@class='field']/input[@id='fixedAmount']");
		private By fixedAmountPreText=By.xpath("//div[@data-ct-help = 'FixedPaymentDescription']");
		public String expectedfixedAmountPreText="Your payment will either be the fixed payment amount, or the minimum payment due as indicated on your monthly statement, whichever is greater, regardless of other payments made during the month. If the fixed payment you�ve scheduled is less than your minimum due, we�ll automatically process a payment for the minimum due. If your account is past due, you may be responsible for making an additional payment to bring the account current. If your current balance is less than the fixed payment amount at the time the payment is made, only the current balance will be withdrawn.";
		
		
		
		public WebElement WelcomeMessage, Next, WelcomeHeader,Back,
		MinimumDueRadioButton,MinimumDueAmountLabel,MinimumDueAmount,LastStatementBalanceRadioButton,LastStatementBalanceLabel,FixedAmountPreText,
		LastStatementBalanceAmount,ReturnPaymentSummary,FixedAmountRadioButton,FixedAmountInputText,Step2,AmountPreText;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public ManageAutoPayAmountSelection() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				Back = driver.findElement(back);
				Step2=driver.findElement(step2);
				MinimumDueRadioButton = driver.findElement(minimumDueRadioButton);
				MinimumDueAmountLabel=driver.findElement(minimumDueAmountLabel);
				MinimumDueAmount=driver.findElement(minimumDueAmount);
				LastStatementBalanceRadioButton=driver.findElement(lastStatementBalanceRadioButton);
				LastStatementBalanceLabel=driver.findElement(lastStatementBalanceLabel);
				LastStatementBalanceAmount=driver.findElement(lastStatementBalanceAmount);
				FixedAmountRadioButton=driver.findElement(fixedAmountRadioButton);
				//FixedInputText=driver.findElement(fixedAmountInputText);
				ReturnPaymentSummary = driver.findElement(returnPaymentSummary);
				//FixedAmountPreText=driver.findElement(fixedAmountPreText);
				Next = driver.findElement(next);				
				test.pass("Navigated to  Payment Step 2 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Navigated to  Payment Step 2 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
		
		public WebElement getFixedAmount() throws IOException {
			FixedAmountInputText=driver.findElement(fixedAmountInputText);
			FixedAmountPreText=driver.findElement(fixedAmountPreText);
			System.out.println(FixedAmountInputText.getText());
			//FixedAmountInputText.clear();
			AssertVerify(FixedAmountPreText.getText().trim().toString(),expectedfixedAmountPreText);
			return FixedAmountInputText;
		}
	}
	
	public class ManageAutoPayDateSelection {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
		public static final String expectedWelcomeMessage = "Manage Auto Pay";
		private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
		private By paymentDateHelpIcon = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		
		private By returntoSummary = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
		private By back=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(1) > button");
		private By next= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(3) > button");
		
		private By step3=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public static final String expectedStep3Text = "Step 3 of 5: Review the start date and payment dates";
		
		private By paymentpreText = By.xpath("//*[@id='main']/article/div/div[2]/div/div/p[2]");
		public String expectedPreText="Your recurring payment will be automatically processed on your payment due date, as shown above, and indicated on your monthly statement.";
		
		
		private By paymentDueDateLabel=By.xpath("//*[@id='main']/article/div/div[2]/div/div/p[1]/span");
		private By paymentDueDate=By.xpath("//*[@id='main']/article/div/div[2]/div/div/p[1]");
		
		
		
		public WebElement WelcomeMessage,  Next, WelcomeHeader,Back,PaymentHelpIcon,PaymentDateHelpIcon,ReturnPaymentSummary,
		PaymentPreText,PaymentDueDateLabel,PaymentDueDate,Step3;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public ManageAutoPayDateSelection() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				Back = driver.findElement(back);				
				ReturnPaymentSummary = driver.findElement(returnPaymentSummary);
				Step3=driver.findElement(step3);
				Next = driver.findElement(next);
				PaymentHelpIcon=driver.findElement(paymenthelpIcon);
				PaymentDateHelpIcon=driver.findElement(paymentDateHelpIcon);
				PaymentPreText=driver.findElement(paymentpreText);
				PaymentDueDateLabel=driver.findElement(paymentDueDateLabel);
				PaymentDueDate=driver.findElement(paymentDueDate);
				test.pass("Navigated to  Payment Step 3 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Payment Step 3 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	public class ManageAutoPayReview {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
		public static final String expectedWelcomeMessage = "Manage Auto Pay";
		private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
		private By paymentreviewHelpIcon = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		public By cardendingDigit = By.xpath("//*[@id='app']/body/div[1]/div[2]/header/div/form/div/button/span[1]");
		private By returnToSummary = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
		private By back=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(1) > button");
		private By saveAutoPay= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(5) > button");
		private By step4=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public String expectedstep4Text="Step 4 of 5: Verify payment information and confirm";
		
		private By cardLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(3) > span");
		private By cardnumber=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(3)");
		private By payfromLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(4) > span");
		private By payfromAccount=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(4)");
		private By paymentAmountLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div:nth-child(5) > p:nth-child(2) > span.text-bold");
		private By paymentAmount = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div:nth-child(5) > p:nth-child(2) > span:nth-child(2)");
		private By planTypeLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div:nth-child(5) > p:nth-child(1) > span");
		private By planType=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div:nth-child(5) > p:nth-child(1)");
		private By paymentDueDate=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.col-100 > p:nth-child(1)");
		//private By NameandCard = By.cssSelector("#mainHeading > span:nth-child(2)");
		private By reivewPreText=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p.text-small");
		public String expectedReviewText = "Your payment will either be the fixed payment amount, or the minimum payment due as indicated on your monthly statement, whichever is greater, regardless of other payments made during the month. If the fixed payment you�ve scheduled is less than your minimum due, we�ll automatically process a payment for the minimum due. If your account is past due, you may be responsible for making an additional payment to bring the account current. If your current balance is less than the fixed payment amount at the time the payment is made, only the current balance will be withdrawn.\r\n" + 
				"By selecting �Save Auto Pay�, you authorize us to automatically transfer your monthly amount from your \"*963\" bank account as a payment to your REDcard account ending in 7303.  These transfers will be automatically processed each month on your payment due date until you cancel this authorization.  You may cancel this authorization in the Manage Auto Pay section of this website, by calling us at 1-800-394-1829, or by writing to us at Target Card Services, P.O. Box 673, Minneapolis, MN 55440-9285. You should print a copy of this authorization for your records.";
		
		public String expectedreivewTextForNonFixedAmount ="By selecting �Save Auto Pay�, you authorize us to automatically transfer your monthly amount from your \"*963\" bank account as a payment to your REDcard account ending in 7303.  These transfers will be automatically processed each month on your payment due date until you cancel this authorization.  You may cancel this authorization in the Manage Auto Pay section of this website, by calling us at 1-800-394-1829, or by writing to us at Target Card Services, P.O. Box 673, Minneapolis, MN 55440-9285. You should print a copy of this authorization for your records";
		public String expectedRecurringPaymentPreText="Your recurring payment will be automatically processed on your payment due date, as shown above, and indicated on your monthly statement.";
		private By recurringpaymentPreText=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div.col-100 > p.text-small");
		
		
		public WebElement WelcomeMessage,WelcomeHeader,PaymentHelpIcon,PaymentReviewHelpIcon,ReturnPaymentSummary,
		Cancel,Back,SaveAutoPay,CardLabel,CardNumber,PayFromlabel,PayFromAccount,PaymentAmountLabel,
		PaymentAmount,PlanTypeLabel,PlanTypeValue,ReviewPreText,RecurringpaymentPreText,PaymentDueDate,Step4;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public ManageAutoPayReview() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				Step4=driver.findElement(step4);
				PaymentHelpIcon = driver.findElement(paymenthelpIcon);
				PaymentReviewHelpIcon=driver.findElement(paymentreviewHelpIcon);
				ReturnPaymentSummary=driver.findElement(returnToSummary);
				Back=driver.findElement(back);
				SaveAutoPay=driver.findElement(saveAutoPay);
				CardLabel=driver.findElement(cardLabel);
				CardNumber=driver.findElement(cardnumber);
				PayFromlabel=driver.findElement(payfromLabel);
				PayFromAccount=driver.findElement(payfromAccount);
				PaymentAmountLabel=driver.findElement(paymentAmountLabel);
				PaymentAmount=driver.findElement(paymentAmount);
				PlanTypeLabel=driver.findElement(planTypeLabel);
				PlanTypeValue=driver.findElement(planType);
				ReviewPreText=driver.findElement(reivewPreText);	
				PaymentDueDate=driver.findElement(paymentDueDate);
				RecurringpaymentPreText=driver.findElement(recurringpaymentPreText);
				test.pass("Navigated to  Payment Step 4 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Payment Step 4 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	public class ManageAutoPayConfirmation {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
		public static final String expectedWelcomeMessage = "Manage Auto Pay";
		private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
		private By paymentconfirmationHelpIcon = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		
		private By returnToSummary= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(6) > a");
		private By step5=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public static final String expectedStep5Text = "Step 5 of 5: Your auto payment has been scheduled";
		
		private By cardLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(3) > span");
		private By cardnumber=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(3)");
		private By payfromLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(4) > span");
		private By payfromAccount=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(4)");
		private By paymentAmountLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > p:nth-child(2) > span.text-bold");
		private By paymentAmount = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > p:nth-child(2) > span:nth-child(2)");
		private By planTypeLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > p:nth-child(1) > span");
		private By planType=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > p:nth-child(1)");

		
		
		public WebElement WelcomeMessage,WelcomeHeader,PaymentHelpIcon,PaymentConfirmationHelpIcon,
		Cancel,ReturnToSummary,CardLabel,CardNumber,PayFromlabel,PayFromAccount,PaymentAmountLabel,
		PaymentAmount,PlanTypeLabel,PlanTypeValue,Step5;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public ManageAutoPayConfirmation() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				PaymentHelpIcon = driver.findElement(paymenthelpIcon);
				PaymentConfirmationHelpIcon=driver.findElement(paymentconfirmationHelpIcon);
				ReturnToSummary=driver.findElement(returnToSummary);
				CardLabel=driver.findElement(cardLabel);
				CardNumber=driver.findElement(cardnumber);
				PayFromlabel=driver.findElement(payfromLabel);
				PayFromAccount=driver.findElement(payfromAccount);
				PaymentAmountLabel=driver.findElement(paymentAmountLabel);
				PaymentAmount=driver.findElement(paymentAmount);
				PlanTypeLabel=driver.findElement(planTypeLabel);
				PlanTypeValue=driver.findElement(planType);
				Step5=driver.findElement(step5);		
				test.pass("Navigated to  Payment Step 5 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Payment Step 5 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	
	public static ManageAutoPay NavigateToManageAutoPay(String autoPayStatus) throws IOException {
		if(autoPayStatus.equals("Enrolled")) {
			CurrentAutoPay currentAutoPay = new CurrentAutoPay();
			currentAutoPay.CancelAndCreateNewAutoPay.click();
			CurrentAutoPay.CancelAutoPayModal cancelModal= currentAutoPay.new CancelAutoPayModal();
			cancelModal.CancelAutoPay.click();
			ManageAutoPay manageAutoPay = new ManageAutoPay();
			return manageAutoPay;
			}
		else {
			ManageAutoPay manageAutoPay = new ManageAutoPay();
			return manageAutoPay;
		}
		
	}
	
	
}