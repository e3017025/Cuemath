package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class ChangePassword extends BaseClass{
	
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		
		private By instruction=By.xpath("//*[@id='main']/div[2]/div/div/form/p[1]");
		private By passwordmust=By.xpath("//*[@id='main']/div[2]/div/div/form/p[2]");
		
		private By condition1=By.xpath("//*[@id='main']/div[2]/div/div/form/ul/li[1]");
		private By condition2=By.xpath("//*[@id='main']/div[2]/div/div/form/ul/li[2]");
		private By condition3=By.xpath("//*[@id='main']/div[2]/div/div/form/ul/li[3]");
		private By condition4=By.xpath("//*[@id='main']/div[2]/div/div/form/ul/li[4]");
		private By condition5=By.xpath("//*[@id='main']/div[2]/div/div/form/ul/li[5]");
		private By condition6=By.xpath("//*[@id='main']/div[2]/div/div/form/ul/li[6]");
		private By condition7=By.xpath("//*[@id='main']/div[2]/div/div/form/ul/li[7]");
		private By newPassword = By.xpath("//*[@id='newPassword']");
		private By confirmPassword = By.xpath("//*[@id='newPassword2']");
		private By submit=By.xpath("//*[@id='main']/div[2]/div/div/form/div[3]/button");
				
		public WebElement WelcomeHeader,WelcomeMessage,Condition1,Condition2,Condition3,Condition4,Condition5,Condition6,Condition7,Submit,NewPassword,ConfirmPassword;
		
		public ChangePassword() throws IOException {
			try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.presenceOfElementLocated(instruction));
			wait.until(ExpectedConditions.presenceOfElementLocated(welcomeMessage));
			wait.until(ExpectedConditions.presenceOfElementLocated(condition1));
			//wait.until(ExpectedConditions.presenceOfElementLocated(phone));
			//wait.until(ExpectedConditions.presenceOfElementLocated(businessPhone));
			WelcomeHeader=driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			Condition1=driver.findElement(condition1);
			Condition2=driver.findElement(condition2);
			Condition3=driver.findElement(condition3);
			Condition4=driver.findElement(condition4);
			Condition5=driver.findElement(condition5);
			Condition6=driver.findElement(condition6);
			Condition7=driver.findElement(condition7);
			NewPassword=driver.findElement(newPassword);
			ConfirmPassword=driver.findElement(confirmPassword);
			Submit=driver.findElement(submit);
			test.pass("Navigating Change Contact Infoamtion Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) {
				test.fail("Failed on Navigating Change Contact Infoamtion Page ******* "+ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build() );
			}
			
		}	
		
}