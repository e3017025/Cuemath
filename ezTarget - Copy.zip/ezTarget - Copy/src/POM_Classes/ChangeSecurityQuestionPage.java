package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class ChangeSecurityQuestionPage extends BaseClass{
	
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		private By successMessage = By.cssSelector("#toast-container > div > div");
		public String expectedSuccessMessage = "Your Security Questions and Answers have been successfully changed";
		private By questionblock = By.xpath("id('main')/div[@class='col-70']/div[@class='module module-dark']");
		public static By numberofQuestions = By.xpath("//*[@id='quesitonDiv']/div[1]/label");
		
		private By question1label=By.xpath("//*[@for='1_q']");
		private By question1=By.xpath("//*[@id='1_q']");
		public static By question1option=By.xpath("//*[@id='1_q']/option[2]");
		private By answer1=By.xpath("//*[@id='1_a']");
		
		private By question2label=By.xpath("//*[@for='2_q']");
		private By question2=By.xpath("//*[@id='2_q']");
		public static By question2option=By.xpath("//*[@id='2_q']/option[2]");
		private By answer2=By.xpath("//*[@id='2_a']");
		
		private By question3label=By.xpath("//*[@for='3_q']");
		private By question3=By.xpath("//*[@id='3_q']");
		public static By question3option=By.xpath("//*[@id='3_q']/option[2]");
		private By answer3=By.xpath("//*[@id='3_a']");
		
		private By question4label=By.xpath("//*[@for='4_q']");
		private By question4=By.xpath("//*[@id='4_q']");
		public static By question4option=By.xpath("//*[@id='4_q']/option[2]");
		private By answer4=By.xpath("//*[@id='4_a']");
		
		private By submit=By.id("btnSubmit");
		private By cancel=By.id("btnCancel");
		private By lookingforsomething = By.xpath("id('main')/div[@class='col-30']/div[@class='module module-dark']");
		
		public static By closeIcon=By.xpath("//*[@class='icon-cancel-circled']");
		public static By tooltip = By.xpath("//*[@id='quesitonDiv']/div[2]/div/div[2]");
		
				
		private By errorMessage = By.xpath("//div[@data-ct-helpselect='headerError']");		
		public String expectedSecurityQuestionErrorMessageOnSameAnswer = "Answers cannot be the same across multiple questions. Please try again.";
		public String expectedSecurityQuestionErrorMessageOnLengthValidation = "User update failed";
		public String expectedSecurityQuestionErrorMessageOnLengthIsEmpty = "Enter security answer between 3 and 30 characters for Challenge Question 1";
				
		public WebElement WelcomeHeader,WelcomeMessage,QuestionBlock,Question1Label,Question1,Answer1,Question2Label,Question2,Answer2,Question3Label,Question3,Answer3,Question4Label,Question4,Answer4,LookingForSomething,Cancel,Submit,SuccessMessage,ErrorMessage;
		
		public ChangeSecurityQuestionPage() throws IOException {
			try {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.presenceOfElementLocated(questionblock));
			wait.until(ExpectedConditions.presenceOfElementLocated(question1));
			wait.until(ExpectedConditions.presenceOfElementLocated(question2));
			WelcomeHeader=driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			Question1Label=driver.findElement(question1label);
			Question1=driver.findElement(question1);			
			Answer1=driver.findElement(answer1);			
			Question2Label=driver.findElement(question2label);
			Question2=driver.findElement(question2);
			Answer2=driver.findElement(answer2);			
			Question3Label=driver.findElement(question3label);
			Question3=driver.findElement(question3);
			Answer3=driver.findElement(answer3);			
			Question4Label=driver.findElement(question4label);
			Question4=driver.findElement(question4);
			Answer4=driver.findElement(answer4);
			Cancel=driver.findElement(cancel);
			Submit= driver.findElement(submit);
			LookingForSomething=driver.findElement(lookingforsomething);
			test.pass("Navigating Change Security Question Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) {
				test.fail("Failed on Navigating Change Security Question Page *******" + ExceptionUtils.getStackTrace(e),MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build() );
			}
			
		}	
		
		public String ChangeSecurityQuestion() throws InterruptedException {
			
			selectDropDownByIndex(Question1, 1);
			WebElement question1= driver.findElement(ChangeSecurityQuestionPage.question1option);
			String securityAnswer1 = SecurityQustionPage.getsecurityAnswer(question1.getText());
			Answer1.sendKeys(securityAnswer1);
			selectDropDownByIndex(Question2, 1);
			WebElement question2= driver.findElement(ChangeSecurityQuestionPage.question2option);
			String securityAnswer2 = SecurityQustionPage.getsecurityAnswer(question2.getText());
			Answer2.sendKeys(securityAnswer2);
			selectDropDownByIndex(Question3, 1);
			WebElement question3= driver.findElement(ChangeSecurityQuestionPage.question3option);
			String securityAnswer3 = SecurityQustionPage.getsecurityAnswer(question3.getText());
			Answer3.sendKeys(securityAnswer3);			
			selectDropDownByIndex(Question4, 1);
			WebElement question4= driver.findElement(ChangeSecurityQuestionPage.question4option);
			String securityAnswer4 = SecurityQustionPage.getsecurityAnswer(question4.getText());
			Answer4.sendKeys(securityAnswer4);
			Submit.click();
			WebDriverWait wait = new WebDriverWait(driver, 10);
			wait.until(ExpectedConditions.presenceOfElementLocated(successMessage));
			String SuccessMessage = driver.findElement(successMessage).getText();
			Thread.sleep(5000);
			return SuccessMessage;
		}
		
		public String ErrorMessage() {
			WebDriverWait wait = new WebDriverWait(driver, 120);
			wait.until(ExpectedConditions.presenceOfElementLocated(errorMessage));
			ErrorMessage=driver.findElement(errorMessage);				
			return ErrorMessage.getText().toString();		
		}
}