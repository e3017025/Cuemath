package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.MediaEntityBuilder;

public class UserNamePage extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By
			.cssSelector("#main > div > div > div > div:nth-child(1) > div > div > form > div.h3");
	private By username = By.id("username");
	private By forgotUsername = By.cssSelector(
			"#main > div > div > div > div:nth-child(1) > div > div > form > div.grid > div > div > div > div.col-50.text-smaller > button");
	private By signInButton = By.id("btnLogin");
	private By enrollNowButton = By
			.cssSelector("#main > div > div > div > div:nth-child(3) > div > div:nth-child(1) > div > a");
	private static By errorMessage = By.xpath("//div[@data-ct-helpselect='headerError']");
	private By saveusername = By.cssSelector(
			"#main > div > div > div > div:nth-child(1) > div > div > form > div.grid > div > div > div > div.col-50.text-right.text-small > label > input");
	private By useanotherusernameButton = By.cssSelector(
			"#main > div > div > div > div:nth-child(1) > div > div > form > div.grid > div > div > div > div.col-50.text-right.text-small > button");

	// Expected Messages
	public static String inlineTextForUsername = "Username";
	public static String welcomeMessageText = "Sign in to Manage My REDcard";

	public WebElement UserName, WelcomeMessage, ForgotUsername, SignInButton, EnrollNowButton, WelcomeHeader;
	public static WebElement ErrorMessage, UseAnotherUserName, SaveUserName;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */
	


	public UserNamePage() throws IOException {
		try {
			
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(username));
			wait.until(ExpectedConditions.visibilityOfElementLocated(signInButton));
			wait.until(ExpectedConditions.visibilityOfElementLocated(forgotUsername));
			WelcomeHeader = driver.findElement(welcomeHeader);
			UserName = driver.findElement(username);
			WelcomeMessage = driver.findElement(welcomeMessage);
			ForgotUsername = driver.findElement(forgotUsername);
			SignInButton = driver.findElement(signInButton);
			EnrollNowButton = driver.findElement(enrollNowButton);
			test.pass("UserNamPage is Displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail("UserNamPage Error ***********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	/*
	 * This method is used to enter the username for login username should be passed
	 * as the arg.
	 */

	public void EnterUsername(String username) throws IOException, InterruptedException {
		
		//UserNamePage usernamePage = new UserNamePage();
		
		Assert.assertEquals(WelcomeMessage.getText().toString(), UserNamePage.welcomeMessageText);
		// If username is already saved then clear the user.
		try {
			UseAnotherUserName = driver.findElement(useanotherusernameButton);
			UseAnotherUserName.click();
		} catch (Exception e) {
			// User is not saved earlier login
		}
		UserName.sendKeys(username);
		SignInButton.click();
		Thread.sleep(10000);
		// Verify Error Message is displayed
		System.out.println(driver.getCurrentUrl().toString());
		if(driver.getCurrentUrl().contains("Security"))
		{
				test.info("RSA is ON: Navigating to Security Question Page");
		}
		else if(driver.getCurrentUrl().toString().contains("Password")){			
				test.info("RSA is OFF: Navigating to Password Page");
				}			
		else{
			test.fail(ErrorMessage + " is displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	/*
	 * This method is used to save the username while on login
	 */

	public void SaveUsername(String username) throws IOException, InterruptedException {
		UserNamePage usernamePage = new UserNamePage();
		try {
			UseAnotherUserName = driver.findElement(usernamePage.useanotherusernameButton);
			UseAnotherUserName.click();
		} catch (Exception e) {
			// User is not saved earlier login
		}
		usernamePage.UserName.sendKeys(username);
		SaveUserName = driver.findElement(saveusername);
		SaveUserName.click();
		usernamePage.SignInButton.click();
		Thread.sleep(15000);
		// Verify Error Message is displayed
		System.out.println(driver.getCurrentUrl().toString());
		if(driver.getCurrentUrl().contains("Security"))
		{			
				
				//SecurityQustionPage secQuestionPage = new SecurityQustionPage();
				test.pass("RSA is ON: Navigated to Password Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
		else if(driver.getCurrentUrl().toString().contains("Password")){
				//PasswordPage passwordPage = new PasswordPage();
				test.pass("RSA is OFF: Navigated to Password Page",
								MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				}			
		else{
			test.fail(ErrorMessage + " is displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	/*
	 * This method is used to login the already saved username. This does not need
	 * username as arg, as it is already saved.
	 */

	public void ValidateSavedUsername() throws IOException, InterruptedException {
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.SignInButton.click();
		Thread.sleep(10000);
		// Verify Error Message is displayed
		System.out.println(driver.getCurrentUrl().toString());
		if(driver.getCurrentUrl().contains("Security"))
		{			
				
				//SecurityQustionPage secQuestionPage = new SecurityQustionPage();
				test.pass("RSA is ON: Navigated to Password Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
		else if(driver.getCurrentUrl().toString().contains("Password")){
				//PasswordPage passwordPage = new PasswordPage();
				test.pass("RSA is OFF: Navigated to Password Page",
								MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				}			
		else{
			test.fail(ErrorMessage + " is displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
}