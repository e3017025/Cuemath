package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class SettingsAndHelp extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By
			.cssSelector("body > div.main-container.shell-wrapper > div.page-wrapper > header > div > div > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");
	
	private By profile=By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(3) > h3"); 
	private By changeContactInformation = By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(3) > ul > li:nth-child(1) > a");
	private By changePassword= By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(3) > ul > li:nth-child(2) > a");
	private By changeSecurityQuestion=By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(3) > ul > li:nth-child(3) > a");
	private By changeUsername=By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(3) > ul > li:nth-child(4) > a");
	private By disabledOnlineAccess=By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(3) > ul > li:nth-child(5) > a");
	private By incomeCollectionPage=By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(3) > ul > li:nth-child(6) > a");
	
	
	private By redCardManagement= By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(5) > h3");
	private By associatedCards = By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(5) > ul > li:nth-child(1) > a");
	private By addCardHolder = By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(5) > ul > li:nth-child(2) > a");
	private By requestReplacementCard = By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(5) > ul > li:nth-child(3) > a");
	private By managePIN = By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(5) > ul > li:nth-child(4) > a");
	private By statementPreferences = By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(5) > ul > li:nth-child(5) > a");
	private By notificationPreferences = By.cssSelector("#main > div.grid > article:nth-child(1) > div > div > div:nth-child(5) > ul > li:nth-child(6) > a");
	private By help = By.cssSelector("#main > div.grid > article:nth-child(2) > div > div > h2");
	private By faq=By.cssSelector("#main > div.grid > article:nth-child(2) > div > div > ul > li > a");
	
	private By contactus=By.cssSelector("#main > div.grid > article:nth-child(3) > div > div > h2");
	private By byPhoneorMail = By.cssSelector("#main > div.grid > article:nth-child(3) > div > div > ul > li > a");
	
	private By accountdisclosures=By.cssSelector("#main > div.grid > article:nth-child(4) > div > div > div > h2");
	private By agreements = By.cssSelector("#main > div.grid > article:nth-child(4) > div > div > div > ul > li:nth-child(1) > a");
	private By targetCreditCardPrivacyPolicy = By.cssSelector("#main > div.grid > article:nth-child(4) > div > div > div > ul > li:nth-child(2) > a");
	private By redcardBenefitsProgramRules = By.cssSelector("#main > div.grid > article:nth-child(4) > div > div > div > ul > li:nth-child(3) > a");
	private By terms = By.cssSelector("#main > div.grid > article:nth-child(4) > div > div > div > ul > li:nth-child(4) > a");
	private By interestbasedads = By.cssSelector("#main > div.grid > article:nth-child(4) > div > div > div > ul > li:nth-child(5) > a");
	private By caprivacyrights = By.cssSelector("#main > div.grid > article:nth-child(4) > div > div > div > ul > li:nth-child(6) > a");
	private By privacy = By.cssSelector("#main > div.grid > article:nth-child(4) > div > div > div > ul > li:nth-child(7) > a");
	
	
	private By errorMessage = By.xpath("//div[@data-ct-helpselect='headerError']");
	public String expectedsessionExpiredMessage = "Your session has expired or you were not authorized to use this functionality. Please log in to continue";
	
	public WebElement WelcomeHeader,WelcomeMessage,Profile,ChangeContactInformation,ChangePassword,ChangeSecurityQuestion,ChangeUsername,DisableOnlineAccess,IncomeCollectionPage,Help,FAQ,REDCardManagement,AssociatedCards,AddCardHolder,ManagePIN,StatementPreferences,NotificationPreferences,Agreeements,TargetCreditCardPrivacyPolicy,REDCardBenefitsProgramRules,Terms,InterestBasedAds,CAPrivacyRights,Privacy,ContactUs,ByPhoneOrMail;
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public SettingsAndHelp() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.presenceOfElementLocated(changeContactInformation));
			wait.until(ExpectedConditions.presenceOfElementLocated(changePassword));
			wait.until(ExpectedConditions.presenceOfElementLocated(changeSecurityQuestion));
			wait.until(ExpectedConditions.presenceOfElementLocated(changeUsername));
			wait.until(ExpectedConditions.presenceOfElementLocated(disabledOnlineAccess));
			//wait.until(ExpectedConditions.presenceOfElementLocated(incomeCollectionPage));			
			WelcomeHeader = driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			Profile=driver.findElement(profile);
			ChangeContactInformation = driver.findElement(changeContactInformation);
			ChangePassword=driver.findElement(changePassword);
			ChangeSecurityQuestion=driver.findElement(changeSecurityQuestion);
			ChangeUsername=driver.findElement(changeUsername);
			DisableOnlineAccess=driver.findElement(disabledOnlineAccess);
			//IncomeCollectionPage=driver.findElement(incomeCollectionPage);
			REDCardManagement =driver.findElement(redCardManagement);
			//AssociatedCards = driver.findElement(associatedCards);
			//AddCardHolder =driver.findElement(addCardHolder);
			//ManagePIN=driver.findElement(managePIN);
			//StatementPreferences = driver.findElement(statementPreferences);
			NotificationPreferences=driver.findElement(notificationPreferences);
			Help=driver.findElement(help);
			FAQ=driver.findElement(faq);
			ContactUs=driver.findElement(contactus);
			ByPhoneOrMail=driver.findElement(byPhoneorMail);
			Agreeements=driver.findElement(agreements);
			//TargetCreditCardPrivacyPolicy=driver.findElement(targetCreditCardPrivacyPolicy);
			//REDCardBenefitsProgramRules = driver.findElement(redcardBenefitsProgramRules);
			//Terms=driver.findElement(terms);
			//InterestBasedAds=driver.findElement(interestbasedads);
			//CAPrivacyRights = driver.findElement(caprivacyrights);
			//Privacy=driver.findElement(privacy);
			test.pass("Settings and Help Page is Displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			
		} catch (Exception e) {
			test.fail("Settings and Help Error *****"+ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}


	public void Click(WebElement element) throws InterruptedException {
		element.click();
		Thread.sleep(10000);
	}
	
	public String ErrorMessage() {
		ErrorMessage=driver.findElement(errorMessage);				
		return ErrorMessage.getText().toString();		
	}
	
	public class ChangeUserName {
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		public String expectedsuccessMessage = "Your Username has been successfully changed";
		private By successMessage = By.cssSelector("#toast-container > div > div");
		
		
		private By username = By.id("username");
		private By cancel= By.cssSelector("#main > div.col-70 > div > div > form > div.text-right > a");
		private By submit= By.cssSelector("#main > div.col-70 > div > div > form > div.text-right > button");
		private By lookingforSomethingBlock=By.cssSelector("#main > div.col-30 > div");
				
		public WebElement WelcomeHeader,WelcomeMessage,UserName,Cancel,Submit,LookingForSomething,SuccessMessage;
		
		public ChangeUserName() throws IOException {
			try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.presenceOfElementLocated(username));
			wait.until(ExpectedConditions.presenceOfElementLocated(submit));
			WelcomeHeader=driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			UserName=driver.findElement(username);
			Cancel=driver.findElement(cancel);
			Submit=driver.findElement(submit);
			LookingForSomething=driver.findElement(lookingforSomethingBlock);
			test.pass("Change Username Page is Displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch(Exception e) {
				test.fail("Change Username Page error ******** "+ ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
		
		public String changeusername(String username) throws InterruptedException {
			UserName.sendKeys(username);
			Submit.click();
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(successMessage));
			SuccessMessage = driver.findElement(successMessage);
			System.out.println(SuccessMessage);
			return SuccessMessage.getText().toString();
		}
		
	}
}