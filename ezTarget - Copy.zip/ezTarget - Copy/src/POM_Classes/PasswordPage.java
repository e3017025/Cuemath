package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.MediaEntityBuilder;

public class PasswordPage extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");
	private By password = By.id("password");
	private By forgotPassword = By
			.cssSelector("#main > div > div > div.grid > div > div > div > form > div.field > button");
	private By signInButton = By.id("btnSubmit");
	private By cancelButton = By.id("btnCancel");
	private By help = By.cssSelector("#main > div > div > div.page-header > button > span.icon-info-circled");

	private static By errorMessage = By.xpath("//div[@data-ct-helpselect='headerError']");

	// Expected Messages
	public static String inlineTextForPassword = "Password";
	public static String welcomeMessageText = "Please Enter Your Password";
	public static String expectederrorMessage= "The password you entered is incorrect";
	public static String invalidpasswordexpectederrorMessage= "We're unable to log you into Manage My REDcard. Please try again later. If you are trying to make a payment or need immediate assistance please contact us at 1-800-394-1829. We�re available 24 hours a day, 7 days a week.";
	
	public WebElement UserName, Password, WelcomeMessage, ForgotPassword, SignInButton, CancelButton, WelcomeHeader,
			PasswordHelpIcon;
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public PasswordPage() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(password));
			wait.until(ExpectedConditions.visibilityOfElementLocated(signInButton));
			WelcomeHeader = driver.findElement(welcomeHeader);
			Password = driver.findElement(password);
			WelcomeMessage = driver.findElement(welcomeMessage);
			ForgotPassword = driver.findElement(forgotPassword);
			SignInButton = driver.findElement(signInButton);
			CancelButton = driver.findElement(cancelButton);
			PasswordHelpIcon = driver.findElement(help);
			test.pass("Navigated to Password Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail("Password Page Error ********" +ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	/*
	 * This method is used to enter the password
	 */
	public void passwordValidator(String password) throws IOException, InterruptedException {
		
		Assert.assertEquals(Password.getAttribute("placeholder").toString(),
				inlineTextForPassword);
		Password.sendKeys(password);
		SignInButton.click();
		 try {
			Thread.sleep(30000);
			driver.getCurrentUrl().contains("Secure");
			test.info("Navigating to Home Page");
			
		} catch (Exception e) {					
			test.fail(ErrorMessage + " is displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	/*
	 * This class is password confirmation modal on click of Forgot password on
	 * Password Page.
	 */

	public class PasswordConfirmationModal {
		private By modalTitle = By.cssSelector("#dialogTitle");
		private By modalDescription = By.cssSelector("#dialogDesc > span");
		private By cancel = By.cssSelector(
				"body > div.modal.no-print.top.am-fade > form > div > div > div.modal-footer > button:nth-child(1)");
		private By ok = By.cssSelector(
				"body > div.modal.no-print.top.am-fade > form > div > div > div.modal-footer > button.btn.btn-sm.btn-primary");

		public WebElement ModalTitle, ModalDescription, CancelButton, OkButton;
		// public static WebElement ErrorMessage;

		public PasswordConfirmationModal() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(modalTitle));
				wait.until(ExpectedConditions.visibilityOfElementLocated(modalDescription));
				wait.until(ExpectedConditions.visibilityOfElementLocated(cancel));
				wait.until(ExpectedConditions.visibilityOfElementLocated(ok));
				ModalTitle = driver.findElement(modalTitle);
				ModalDescription = driver.findElement(modalDescription);
				CancelButton = driver.findElement(cancel);
				OkButton = driver.findElement(ok);
				test.pass("Password confirmation Modal is displayed", MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			catch (Exception e) {
				test.fail("Password Confirmation Modal",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}

	}

	/*
	 * This class is password grid modal on click of help icon on Password Page.
	 */

	public class HelpModal {
		private By helpgrid = By.cssSelector("#main > div > div > div.grid");
		private By skip = By.cssSelector(
				"body > div.introjs-tooltipReferenceLayer > div > div.introjs-tooltipbuttons > button.introjs-button.introjs-skipbutton");
		private By next = By.cssSelector(
				"body > div.introjs-tooltipReferenceLayer > div > div.introjs-tooltipbuttons > button.introjs-button.introjs-nextbutton");
		private By done = By.cssSelector(
				"body > div.introjs-tooltipReferenceLayer > div > div.introjs-tooltipbuttons > button.introjs-button.introjs-skipbutton");
		private By back = By.cssSelector(
				"body > div.introjs-tooltipReferenceLayer > div > div.introjs-tooltipbuttons > button.introjs-button.introjs-nextbutton");

		public WebElement HelpGrid, SkipButton, NextButton, DoneButton, BackButton;

		public HelpModal() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(helpgrid));
				wait.until(ExpectedConditions.visibilityOfElementLocated(skip));
				wait.until(ExpectedConditions.visibilityOfElementLocated(next));				
				HelpGrid = driver.findElement(helpgrid);
				SkipButton = driver.findElement(skip);
				NextButton = driver.findElement(next);
				DoneButton = driver.findElement(done);
				BackButton = driver.findElement(back);
				test.pass("Help Modal is displayed",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Help Modal Error in Password Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	public String ErrorMessage() {
		ErrorMessage=driver.findElement(errorMessage);
		System.out.println(ErrorMessage.getText());
		return ErrorMessage.getText().toString();		
	}

}