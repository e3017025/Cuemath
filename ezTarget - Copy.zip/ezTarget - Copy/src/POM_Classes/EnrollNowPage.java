package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class EnrollNowPage extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");
	
	
	private By nameonCard = By.id("enrollName");
	private By last4digitsofssn= By.id("taxId");
	private By cvv=By.id("enrollCvv");
	private By cardholdersince = By.id("openDate");
	private By cancel = By
			.cssSelector("#main > div > div:nth-child(3) > div > div.col-60 > div > div > form > div.clearfix > div.pull-left > a");
	private By next = By.cssSelector(
			"#main > div > div:nth-child(3) > div > div.col-60 > div > div > form > div.clearfix > div.pull-right > button");
	private By errorMessage = By.xpath("//div[@data-ct-helpselect='headerError']");

	public static String welcomeMessageText = "Enter Account Details";
	public String expectederrorMessage = "We're sorry, we were unable to identify you as an account holder. Please verify your information and try again.\r\n" + 
			" If you need immediate assistance, please contact us at 1-800-394-1829. We�re available 24 hours a day, 7 days a week.";

	public WebElement WelcomeMessage, WelcomeHeader,NameOnCard, Last4DigitsOfSSN, CVV, Next, Cancel, CardHolderSince;
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public EnrollNowPage() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(nameonCard));
			wait.until(ExpectedConditions.visibilityOfElementLocated(last4digitsofssn));
			wait.until(ExpectedConditions.visibilityOfElementLocated(cvv));
			wait.until(ExpectedConditions.visibilityOfElementLocated(cardholdersince));
			WelcomeHeader = driver.findElement(welcomeHeader);			
			WelcomeMessage = driver.findElement(welcomeMessage);
			NameOnCard = driver.findElement(nameonCard);
			Last4DigitsOfSSN= driver.findElement(last4digitsofssn);
			CVV=driver.findElement(cvv);
			CardHolderSince= driver.findElement(cardholdersince);
			Next= driver.findElement(next);			
			Cancel = driver.findElement(cancel);
			test.pass("Navigated to Enroll Now Page", MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			
		} catch (Exception e) {
			test.fail("Enroll Now Page Error **********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build());
		}
	}

	/*
	 * This method is used to enter the username for login username should be passed
	 * as the arg.
	 */	
	
	/*public void EnterAccountDetails(String CardNumber) throws IOException {
		ForgotUserName forgotusername = new ForgotUserName();
		Assert.assertEquals(forgotusername.WelcomeMessage.getText().toString(), ForgotUserName.welcomeMessageText);
		forgotusername.CardNumber.sendKeys(CardNumber);
		forgotusername.BeginForgotUserName.click();
		// Verify Error Message is displayed
		try {
			Thread.sleep(5000);
			ErrorMessage = driver.findElement(errorMessage);
			test.fail(ErrorMessage + " is displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.pass("Navigated to Enroll Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}*/
	
	public String ErrorMessage() {
		ErrorMessage=driver.findElement(errorMessage);				
		return ErrorMessage.getText().toString();
		
	}
}