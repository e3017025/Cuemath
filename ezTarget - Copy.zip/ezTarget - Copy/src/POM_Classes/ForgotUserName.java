package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class ForgotUserName extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
	private By cardnumber = By.id("enterCCNumber");
	private By cancel = By
			.cssSelector("#main > div.grid > div.col-60 > article > div > form > div.clearfix > div.pull-left > a");
	private By beginForgotUsername = By.cssSelector(
			"#main > div.grid > div.col-60 > article > div > form > div.clearfix > div.pull-right > button");

	private static By errorMessage = By.xpath("//div[@data-ct-helpselect='headerError']");

	// Expected Messages
	public static String inlineTextForCardNumber = "XXXX-XXXX-XXXX-XXXX";
	public static String welcomeMessageText = "Forgot Username";
	public String expectederrorMessage = "We're sorry, the account number you entered is not a valid account number. Please verify your account number and try again.";
	public String expectedErrorMessageforSecondAccountEnrollment = "We're sorry, the account number you entered is not a valid account number. Please verify your account number and try again.";

	public WebElement CardNumber, WelcomeMessage, ForgotUsername, Cancel, BeginForgotUserName, WelcomeHeader;
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public ForgotUserName() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(cardnumber));
			wait.until(ExpectedConditions.visibilityOfElementLocated(beginForgotUsername));
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			WelcomeHeader = driver.findElement(welcomeHeader);
			CardNumber = driver.findElement(cardnumber);
			WelcomeMessage = driver.findElement(welcomeMessage);
			Cancel = driver.findElement(cancel);
			BeginForgotUserName = driver.findElement(beginForgotUsername);
			test.pass("Navigated to ForgotUserName Page",
					MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build());
		} catch (Exception e) {
			test.fail("ForgotUserName Page Error ********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromBase64String(captureScreen()).build());
		}
	}

	/*
	 * This method is used to enter the username for login username should be passed
	 * as the arg.
	 */

	public void EnterCardNumber(String cardNumber) throws IOException {		
		//Assert.assertEquals(forgotusername.WelcomeMessage.getText().toString(), ForgotUserName.welcomeMessageText);
		CardNumber.sendKeys(cardNumber);
		BeginForgotUserName.click();
		// Verify Error Message is displayed
		try {
			Thread.sleep(5000);
			ErrorMessage = driver.findElement(errorMessage);
			test.fail(ErrorMessage + " is displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.pass("Navigated to Enroll Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
	
	public String ErrorMessage() {
		ErrorMessage=driver.findElement(errorMessage);				
		return ErrorMessage.getText().toString();		
	}

}