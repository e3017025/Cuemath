package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class MakeOneTimePayment extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
	public static String expectedWelcomeMessage = "Make a One-Time Payment";
	private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
	
	private By addPaymentAccount = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div.sm-and-up.clearfix > div.text-small > span > span > a");
	private By selectAccount = By.xpath("//*[@id='payment-account']");
	private By cancel = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
	private By next= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(5) > button");
	private By step1=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div.sm-and-up.clearfix > h3 > strong");
	public static String expectedStep2Text = "Step 1 of 5: Choose a bank account";
	private By accountHelpIcon = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div.sm-and-up.clearfix > h3 > button > span.icon-info-circled");
	private By autopayEnabledText = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div:nth-child(3) > div");
	private By paymentInformationTitleWhenAutoPayNotEnabled =By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[3]/span[1]");
	private By paymentInformationNoteWhenAutoPayNotEnabled = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[3]/span[2]");
	private By paymentInformationTitleWhenAutoPayEnabled =By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[4]/span[1]");
	private By paymentInformationNoteWhenAutoPayEnabled = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[4]/span[2]");
	private By accountStep = By.xpath("//*[@id='step1']/span");
	private By amountStep = By.xpath("//*[@id='step2']/span");
	private By dateStep = By.xpath("//*[@id='step3']/span");
	private By reviewStep = By.xpath("//*[@id='step4']/span");
	private By confirmationStep = By.xpath("//*[@id='step5']/span");
	public static String expectedPaymentInformationTitle = "Payment Information:";
	public static String expectedPaymentInformationNote = "Please confirm the bank account information you provided is correct. If necessary, you can add a payment account. If you have enrolled in Auto Pay, changing the bank account for this one-time payment will not change the bank account enrolled in Auto Pay.";
	public static String ExpectedAutoPayWarningText="IMPORTANT: You are currently enrolled in Auto Pay. If you choose to make a one time payment, the one time payment will be in addition to the recurring Auto Pay you have scheduled."; 
	public static final String expectedStep1Text = "Step 1 of 5: Choose a bank account";
	
	public WebElement WelcomeMessage, Cancel, Next, WelcomeHeader,PaymentHelpIcon,AddPaymentAccount,AutoPayEnabledWarningText,
	SelectAccount,Step1,AccountHelpIcon,PaymentInformationTitle,PaymentInformationNote,AccountStep,AmountStep,DateStep,ReviewStep,ConfirmationStep;
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public MakeOneTimePayment() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			wait.until(ExpectedConditions.visibilityOfElementLocated(addPaymentAccount));
			WelcomeHeader = driver.findElement(welcomeHeader);			
			WelcomeMessage = driver.findElement(welcomeMessage);
			PaymentHelpIcon=driver.findElement(paymenthelpIcon);
			AddPaymentAccount=driver.findElement(addPaymentAccount);
			SelectAccount = driver.findElement(selectAccount);
			Step1=driver.findElement(step1);
			AccountHelpIcon=driver.findElement(accountHelpIcon);
			try {
				AutoPayEnabledWarningText=driver.findElement(autopayEnabledText);
				PaymentInformationTitle=driver.findElement(paymentInformationTitleWhenAutoPayEnabled);
				PaymentInformationNote =driver.findElement(paymentInformationNoteWhenAutoPayEnabled);	
			}
			catch(Exception e) {
				PaymentInformationTitle=driver.findElement(paymentInformationTitleWhenAutoPayNotEnabled);
				PaymentInformationNote =driver.findElement(paymentInformationNoteWhenAutoPayNotEnabled);
			}
			AccountStep=driver.findElement(accountStep);
			AmountStep =driver.findElement(amountStep);
			DateStep=driver.findElement(dateStep);
			ReviewStep=driver.findElement(reviewStep);
			ConfirmationStep =driver.findElement(confirmationStep);
			Cancel = driver.findElement(cancel);
			Next = driver.findElement(next);			
			test.pass("Payment Step 1",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail("Payment Step 1 Page Error ********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
	
	public class MakeOneTimePaymentAmountSelection {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
		public static final String expectedWelcomeMessage = "Make a One-Time Payment";
		private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
		private By amountHelpIcon=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div.md-and-up.clearfix > h3 > button > span.icon-info-circled");
		
		private By cancel = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
		private By back=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(3) > button");
		private By next= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(4) > button");
		
		private By step2=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div.md-and-up.clearfix > h3 > strong");
		public static final String expectedStep2Text = "Step 2 of 5: Choose a payment amount";
		
		private By minimumDueRadioButton=By.cssSelector("#minimumPaymentDue");
		private By minimumDueAmountLabel=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='minimumPaymentDue']/span[1]");
		private By minimumDueAmount=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='minimumPaymentDue']/span[2]");
		
		private By currentBalanceRadioButton = By.id("accountBalance");
		private By currentBalanceLabel = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='accountBalance']/span[1]");
		private By currentBalanceAmount = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='accountBalance']/span[2]");
		
		private By remainingBalanceRadioButton=By.id("remainingAmount");
		private By remainingBalanceLabel=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='remainingAmount']/span[1]");
		private By remainingBalanceAmount=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='remainingAmount']/span[2]");
		
		private By lastStatementBalanceRadioButton = By.id("lastStatementAmount");
		private By lastStatementBalanceLabel = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='lastStatementAmount']/span[1]");
		private By lastStatementBalanceAmount = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='lastStatementAmount']/span[2]");
		
		private By lastPaymentRadioButton = By.id("lastPaymentAmount");
		private By lastPaymentLabel = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='lastPaymentAmount']/span[1]");
		private By lastPaymentAmount = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field-condensed field']/label[@for='lastPaymentAmount']/span[2]");
		
		private By otherAmountRadioButton = By.id("otherAmount");
		private By otherAmountLabel=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field field-condensed']/label[@class='col-90 text-normal']/span");
		private By otherAmountInputText = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/fieldset/span[@class='grid col-75 field field-condensed']/label[@class='col-90 text-normal']/input");
		
		private By pendingPaymentsLabel = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/span[1]/span/label");
		private By pendingPaymentAmount = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/span[1]/span/span");
		
		private By remainingbalancewithoutRadiobutton = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/span[2]/span/label");
		private By remainingbalanceAmountwithoutRadiobutton = By.xpath("//*[@id='main']/article/div/div[2]/div/div/div[2]/span[2]/span/span");
		private By amountpreText=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div.md-and-up.clearfix > p > span");
		public String expectedPreText="Your payment amount cannot exceed your Current Balance.";
		
		
		public WebElement WelcomeMessage, Cancel, Next, WelcomeHeader,Back,AmountHelpIcon,RemainingBalanceRadioButton,
		MinimumDueRadioButton,MinimumDueAmountLabel,MinimumDueAmount,CurrentBalanceRadioButton,
		CurrentBalanceLabel,CurrentBalanceAmount,LastStatementBalanceRadioButton,LastStatementBalanceLabel,RemainingBalanceAmountWithoutRadioButton,
		LastPaymentRadioButton,LastPaymentLabel,LastPaymentAmount,LastStatementBalanceAmount,RemainingBalanceLabelWithoutRadioButton,
		OtherAmountRadioButton,OtherInputText,PendingPayementLabel,RemainingBalanceLabel,RemainingBalanceAmount,Step2,AmountPreText;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public MakeOneTimePaymentAmountSelection() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				Back = driver.findElement(back);
				Step2=driver.findElement(step2);
				MinimumDueRadioButton = driver.findElement(minimumDueRadioButton);
				MinimumDueAmountLabel=driver.findElement(minimumDueAmountLabel);
				MinimumDueAmount=driver.findElement(minimumDueAmount);
				CurrentBalanceRadioButton=driver.findElement(currentBalanceRadioButton);
				CurrentBalanceLabel=driver.findElement(currentBalanceLabel);
				CurrentBalanceAmount=driver.findElement(currentBalanceAmount);
				LastPaymentRadioButton=driver.findElement(lastPaymentRadioButton);
				LastPaymentLabel=driver.findElement(lastPaymentLabel);
				LastPaymentAmount=driver.findElement(lastPaymentAmount);
				if(!WelcomeMessage.getText().equals("Edit A Payment")) {
				LastStatementBalanceRadioButton=driver.findElement(lastStatementBalanceRadioButton);
				LastStatementBalanceLabel=driver.findElement(lastStatementBalanceLabel);
				LastStatementBalanceAmount=driver.findElement(lastStatementBalanceAmount);
				}
				OtherAmountRadioButton=driver.findElement(otherAmountRadioButton);
				OtherInputText=driver.findElement(otherAmountInputText);
				PendingPayementLabel= driver.findElement(pendingPaymentsLabel);
				RemainingBalanceLabelWithoutRadioButton=driver.findElement(remainingbalancewithoutRadiobutton);
				RemainingBalanceAmountWithoutRadioButton=driver.findElement(remainingbalanceAmountwithoutRadiobutton);
				OtherAmountRadioButton.click();
				if(!RemainingBalanceAmountWithoutRadioButton.getText().toString().equals(CurrentBalanceAmount.getText().toString())) {
					RemainingBalanceRadioButton=driver.findElement(remainingBalanceRadioButton);
					RemainingBalanceLabel = driver.findElement(remainingBalanceLabel);
					RemainingBalanceAmount =driver.findElement(remainingBalanceAmount);	
				}				
				Cancel = driver.findElement(cancel);
				AmountPreText=driver.findElement(amountpreText);
				Next = driver.findElement(next);	
				AmountHelpIcon=driver.findElement(amountHelpIcon);
				test.pass("Navigated to  Payment Step 2 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Navigated to  Payment Step 2 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	public class MakeOneTimePaymentDateSelection {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
		public static final String expectedWelcomeMessage = "Make a One-Time Payment";
		private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
		private By paymentDateHelpIcon = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		private By cancel = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
		private By back=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(3) > button");
		private By next= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(4) > button");
		
		private By step3=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public static final String expectedStep3Text = "Step 3 of 5: Choose a payment date";
		
		private By paymentpreText = By.xpath("//*[@id='main']/article/div/div[2]/div/p/span");
		public String expectedPreText="Please Note: Online payments must be made prior to 5:00 p.m. Central Time to be considered received the same day.";
		private By year=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div > div:nth-child(1) > div > div > div:nth-child(1) > select");
		private By month=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div > div:nth-child(1) > div > div > div:nth-child(2) > select");
		private By date=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > div > div > div:nth-child(1) > div > div > div:nth-child(3) > select");
		
		private By paymentDueDateLabel=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div/p[1]");
		private By paymentDueDate=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div/p[1]/span");
		private By todaysPaymentLabel=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div/p[2]");
		private By todaysPayment=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div/p[2]/span");
		private By sendAlertVia=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div/div[2]/fieldset/legend");
		private By sendAlertTo=By.xpath("//*[@id='main']/article/div/div[2]/div/div/div/div[2]/fieldset/div/button");
		
		
		public WebElement WelcomeMessage, Cancel, Next, WelcomeHeader,Back,PaymentHelpIcon,PaymentDateHelpIcon,
		PaymentPreText,Year,Month,Day,PaymentDueDateLabel,PaymentDueDate,TodaysPaymentLabel,TodaysPayment,SendAlertVia,SendAlertTo,Step3;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public MakeOneTimePaymentDateSelection() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				Back = driver.findElement(back);				
				Cancel = driver.findElement(cancel);
				Step3=driver.findElement(step3);
				Next = driver.findElement(next);
				PaymentHelpIcon=driver.findElement(paymenthelpIcon);
				PaymentDateHelpIcon=driver.findElement(paymentDateHelpIcon);
				PaymentPreText=driver.findElement(paymentpreText);
				Year=driver.findElement(year);
				Month=driver.findElement(month);
				Day=driver.findElement(date);
				PaymentDueDateLabel=driver.findElement(paymentDueDateLabel);
				PaymentDueDate=driver.findElement(paymentDueDate);
				TodaysPaymentLabel=driver.findElement(todaysPaymentLabel);
				TodaysPayment=driver.findElement(todaysPayment);
				SendAlertVia=driver.findElement(sendAlertVia);
				SendAlertTo=driver.findElement(sendAlertTo);
				test.pass("Navigated to  Payment Step 3 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Payment Step 3 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	public class MakeOneTimePaymentReview {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
		public static final String expectedWelcomeMessage = "Make a One-Time Payment";
		private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
		private By paymentreviewHelpIcon = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		
		private By cancel = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
		private By back=By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(3) > button");
		private By makePayment= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(6) > button");		
		private By step4=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public String expectedstep4Text="Step 4 of 5: Review information and submit payment";
		
		private By cardLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(3) > span.text-bold");
		private By cardnumber=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(3) > span:nth-child(2)");
		private By payfromLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(4) > span.text-bold");
		private By payfromAccount=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(4) > span:nth-child(2)");
		private By paymentAmountLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(5) > span.text-bold");
		private By paymentAmount = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(5) > span:nth-child(2)");
		private By payOnLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(5) > span:nth-child(2)");
		private By payOnDate=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(6) > span:nth-child(2)");
		private By sendAlertViaLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(7) > span.text-bold");
		private By sendAlertVia=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(7) > span:nth-child(2) > span");
		private By NameandCard = By.cssSelector("#mainHeading > span:nth-child(2)");
		private By reivewPreText=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p.text-small > span");
		public String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of $1.00 from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in 7303. If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		private By errorMessage=By.xpath("//*[@id='app']/body/div[1]/div[2]/div[1]/div/div/div");
		public String expectederrorMessageForScheduledMorethan30Days="We're unable to process your payment request at this time. You cannot schedule a payment more than 30 days in the future for a single payment account.";
		private By closeIconforErrorMessage = By.cssSelector("body > div.main-container.shell-wrapper > div.page-wrapper > div:nth-child(1) > div > span > span > span.icon-cancel-circled");
		
		public WebElement WelcomeMessage,WelcomeHeader,PaymentHelpIcon,PaymentReviewHelpIcon,
		Cancel,Back,MakePayment,CardLabel,CardNumber,PayFromlabel,PayFromAccount,PaymentAmountLabel,
		PaymentAmount,PayOnLabel,PayOnDate,SendAlertViaLabel,SendAlertVia,ReviewPreText,NameAndCardDetails,Step4;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public MakeOneTimePaymentReview() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				Step4=driver.findElement(step4);
				PaymentHelpIcon = driver.findElement(paymenthelpIcon);
				PaymentReviewHelpIcon=driver.findElement(paymentreviewHelpIcon);
				Cancel=driver.findElement(cancel);
				Back=driver.findElement(back);
				MakePayment=driver.findElement(makePayment);
				CardLabel=driver.findElement(cardLabel);
				CardNumber=driver.findElement(cardnumber);
				PayFromlabel=driver.findElement(payfromLabel);
				PayFromAccount=driver.findElement(payfromAccount);
				PaymentAmountLabel=driver.findElement(paymentAmountLabel);
				PaymentAmount=driver.findElement(paymentAmount);
				PayOnLabel=driver.findElement(payOnLabel);
				PayOnDate=driver.findElement(payOnDate);
				SendAlertViaLabel=driver.findElement(sendAlertViaLabel);
				SendAlertVia=driver.findElement(sendAlertVia);
				ReviewPreText=driver.findElement(reivewPreText);	
				NameAndCardDetails=driver.findElement(NameandCard);
				test.pass("Navigated to  Payment Step 4 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Payment Step 4 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
		
		public String getErrorMessage() {
			String error = driver.findElement(errorMessage).getText().trim();
			//driver.findElement(closeIconforErrorMessage).click();
			return error;
		}
		
		public WebElement getCloseIconOnErrorMessage() {
			return driver.findElement(closeIconforErrorMessage);
			
		}
	}
	
	public class MakeOneTimePaymentConfirmation {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading > span:nth-child(1)");
		public static final String expectedWelcomeMessage = "Make a One-Time Payment";
		private By paymenthelpIcon = By.cssSelector("#main > div > button > span.icon-info-circled");
		private By paymentconfirmationHelpIcon = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		
		private By cancel = By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-left-xs > div > a");
		private By close= By.cssSelector("#main > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(1) > a");
		private By step5=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public static final String expectedStep5Text = "Step 5 of 5: Your payment has been submitted ";
		
		private By cardLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(4) > span.text-bold");
		private By cardnumber=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(4) > span:nth-child(2)");
		private By payfromLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(5) > span.text-bold");
		private By payfromAccount=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(5) > span:nth-child(2)");
		private By paymentAmountLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(6) > span.text-bold");
		private By paymentAmount = By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(6) > span:nth-child(2)");
		private By payOnLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(7) > span.text-bold");
		private By payOnDate=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(7) > span:nth-child(2)");
		private By confirmationLabel=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(3) > span.text-bold");
		private By confirmationNumber=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p:nth-child(3)");
		
		private By reivewPreText=By.cssSelector("#main > article > div > div.clearfix.basic-animation > div > p.text-small > span");
		public String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of $1.00 from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in 7303. If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		
		
		public WebElement WelcomeMessage,WelcomeHeader,PaymentHelpIcon,PaymentConfirmationHelpIcon,
		Cancel,Back,Close,CardLabel,CardNumber,PayFromlabel,PayFromAccount,PaymentAmountLabel,
		PaymentAmount,PayOnLabel,PayOnDate,ConfirmationLabel,ConfirmationNumber,Step5;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public MakeOneTimePaymentConfirmation() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				PaymentHelpIcon = driver.findElement(paymenthelpIcon);
				PaymentConfirmationHelpIcon=driver.findElement(paymentconfirmationHelpIcon);
				Cancel=driver.findElement(cancel);
				Close=driver.findElement(close);
				CardLabel=driver.findElement(cardLabel);
				CardNumber=driver.findElement(cardnumber);
				PayFromlabel=driver.findElement(payfromLabel);
				PayFromAccount=driver.findElement(payfromAccount);
				PaymentAmountLabel=driver.findElement(paymentAmountLabel);
				PaymentAmount=driver.findElement(paymentAmount);
				PayOnLabel=driver.findElement(payOnLabel);
				PayOnDate=driver.findElement(payOnDate);
				ConfirmationLabel=driver.findElement(confirmationLabel);
				ConfirmationNumber=driver.findElement(confirmationNumber);
				Step5=driver.findElement(step5);		
				test.pass("Navigated to  Payment Step 4 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Payment Step 4 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	
}