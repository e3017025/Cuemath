package POM_Classes;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.util.List;
import java.util.NoSuchElementException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.Point;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.remote.server.handler.interactions.touch.Scroll;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;

import com.aventstack.extentreports.MediaEntityBuilder;

import POM_Classes.Transactions.DeleteModal;
import POM_Classes.Transactions.SaveThisSearchConfirmModal;

public class Transactions extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");
	public static String expectedwelcomeMessage = "Transactions";
	public By transactionDescription = By.cssSelector("#main > div.page-header > div");
	public static String expectedtransacrtionDescription = "These transactions should be used for reference purposes only, as your bank records should be considered the true source of your Target Debit Card transactions.";

	// Saved Search
	public static By savedsearchExpanderButton = By.cssSelector(
			"#main > div.grid > article.col-40.transaction-search-controls > section:nth-child(1) > div > div:nth-child(1) > h3 > span > span");
	private By savedsearchTitle = By.xpath("//*[@id='main']/div[2]/article[1]/section[1]/div/div[1]/h3");
	private By savedSearchHelpIcon = By.cssSelector(
			"#main > div.grid > article.col-40.transaction-search-controls > section:nth-child(1) > div > div:nth-child(1) > h3 > button > span.icon-info-circled");
	public By savedSearchName = By.xpath("//*[@id='collapsible-searches']/div/ul/li[1]/div[1]/button");
	public By deletesearch = By.cssSelector(
			"#collapsible-searches > div > ul > li > div.col-c-30.text-right > button > span.icon-trash.text-muted");
	// Filters
	private By filterExpanderButton = By.cssSelector(
			"#main > div.grid > article.col-40.transaction-search-controls > section:nth-child(2) > div > div:nth-child(1) > h3 > span > span");
	private By filterTitle = By.xpath("//*[@id='main']/div[2]/article[1]/section[2]/div/div[1]/h3");
	private By filtersHelpIcon = By.cssSelector(
			"#main > div.grid > article.col-40.transaction-search-controls > section:nth-child(2) > div > div:nth-child(1) > h3 > button > span.icon-info-circled");

	// Time Period
	private By timePeriodLabel = By.cssSelector("#collapsible-filters > div > form > div:nth-child(1) > label");
	private By timePeriodOption = By.cssSelector("#buttonTimePeriod");
	private By categoriesLabel = By.cssSelector("#collapsible-filters > div > form > div:nth-child(2) > label");
	private By categoriesOption = By.cssSelector("#buttonCategories");
	private By amountLabel = By.cssSelector("#collapsible-filters > div > form > div:nth-child(3) > label");
	private By amountOption = By.cssSelector("#buttonAmount");
	private By orderBylabel = By.cssSelector("#collapsible-filters > div > form > div:nth-child(4) > label");
	private By orderByoption = By.cssSelector("#buttonOrder");
	private By groupResultsByCategory = By
			.cssSelector("#collapsible-filters > div > form > div.field.checkboxes > label > input");
	private By savethisSearch = By
			.cssSelector("#collapsible-filters > div > form > div:nth-child(6) > button.btn.btn-sm.btn-secondary");
	public By clearAllSearch = By
			.cssSelector("#collapsible-filters > div > form > div:nth-child(6) > button.btn.btn-sm.btn-default");

	private By exportLabel = By.cssSelector("#collapsible-filters > div > form > div:nth-child(8) > label");
	private By exportOption = By.cssSelector("#exportResults");

	private By spendAnalyzer = By.xpath("//*[@id='collapsible-filters']/div/form/div[8]/a");
	private By gotoSummary = By.xpath("//*[@id='collapsible-filters']/div/form/div[9]/a");

	// Search
	private By searchInput = By.cssSelector(
			"#main > div.grid > article.col-60.transaction-search-results > div > section > div > div > form > input");
	private By searchButton = By.cssSelector(
			"#main > div.grid > article.col-60.transaction-search-results > div > section > div > div > form > span > button:nth-child(2)");
	private By clearButton = By.cssSelector(
			"#main > div.grid > article.col-60.transaction-search-results > div > section > div > div > form > span > button:nth-child(1) > i");

	private By transactionsResultsexpander = By.xpath("//*[@id='Transactions']/div/span[1]/span");
	private By transactionsResultsAttribute = By.xpath("//*[@id='Transactions']/div/span[1]");
	private By transactionLabel = By.cssSelector("#transactionLabel");
	private By numberofTransactions = By.cssSelector("#Transactions > div > span:nth-child(3)");

	private By savedSearchExpanderAttribute = By
			.xpath("//*[@id='main']/div[2]/article[1]/section[1]/div/div[1]/h3/span");
	private By filtersExpanderAttribute = By.xpath("//*[@id='main']/div[2]/article[1]/section[2]/div/div[1]/h3/span");
	// private By transactionReultExpander=

	// Filters in the Search Results
	public By filter1 = By.xpath("//*[@id='main']/div[2]/article[2]/div/section/div/span[2]/button");
	public By filter2 = By.xpath("//*[@id='main']/div[2]/article[2]/div/section/div/span[3]/button");
	public By filter3 = By.xpath("//*[@id='main']/div[2]/article[2]/div/section/div/span[4]/button");

	public By clearAllButton = By.xpath("//*[@data-ct-help='ClearAll' and @class='btn btn-xs btn-label']");

	// Edit
	private By expandfirstRowToEdit = By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[1]");
	private By editCategory = By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[2]/div/div[2]/p/button");

	public ArrayList<String> expectedListofCategories = new ArrayList<>(Arrays.asList("Miscellaneous", "Household",
			"Groceries", "Adjustment", "Auto Related", "Cash", "Charitable Giving", "Clothing", "Computer Related",
			"Dining Out", "Education", "Entertainment", "Family Expense", "Fee or Interest Charge", "Finance & Other",
			"Gifts Given", "Health & Medical", "Health Care", "Home Repair", "Insurance", "Legal And Professional",
			"Online / Internet", "Payment", "Payments", "Personal Care", "Pet Care", "Recreation", "Rent",
			"Subscriptions & Memberships", "Taxes", "Travel", "Utilities", "Work Related"));

	public WebElement WelcomeMessage, WelcomeHeader, TransactionDescription, SavedSearchExpanderButton,
			SavedSearchTitle, SavedSearchHelpIcon, FiltersExpanderButton, FiltersExpanderAttribute, FiltersTitle,
			FiltersHelpIcon, TimePeriodLabel, TimePeriodOption, CategoriesLabel, CategoriesOption, AmountLabel,
			AmountOption, OrderBylabel, OrderByoption, GroupResultsByCategory, SaveThisSearch, ClearAll, ExportLabel,
			ExportOption, SearchInput, SearchButton, ClearButton, TransactionLabel, NumberOfTransaction,
			TransactionsResultsexpander, SpendAnalyzer, Summaries, SavedSearchExpanderAttribute,
			TransactionResultsAttribute;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public Transactions() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			// wait.until(ExpectedConditions.visibilityOfElementLocated(transactionDescription));
			wait.until(ExpectedConditions.visibilityOfElementLocated(savedsearchExpanderButton));
			wait.until(ExpectedConditions.visibilityOfElementLocated(savedsearchTitle));
			wait.until(ExpectedConditions.visibilityOfElementLocated(savedSearchHelpIcon));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filterExpanderButton));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filterTitle));
			wait.until(ExpectedConditions.visibilityOfElementLocated(filtersHelpIcon));
			WelcomeHeader = driver.findElement(welcomeHeader);
			WelcomeMessage = driver.findElement(welcomeMessage);
			// TransactionDescription = driver.findElement(transactionDescription);
			SavedSearchExpanderButton = driver.findElement(savedsearchExpanderButton);
			SavedSearchTitle = driver.findElement(savedsearchTitle);
			SavedSearchHelpIcon = driver.findElement(savedSearchHelpIcon);
			FiltersExpanderButton = driver.findElement(filterExpanderButton);
			FiltersTitle = driver.findElement(filterTitle);
			FiltersHelpIcon = driver.findElement(filtersHelpIcon);
			TimePeriodLabel = driver.findElement(timePeriodLabel);
			TimePeriodOption = driver.findElement(timePeriodOption);
			CategoriesLabel = driver.findElement(categoriesLabel);
			CategoriesOption = driver.findElement(categoriesOption);
			AmountLabel = driver.findElement(amountLabel);
			AmountOption = driver.findElement(amountOption);
			OrderBylabel = driver.findElement(orderBylabel);
			OrderByoption = driver.findElement(orderByoption);
			GroupResultsByCategory = driver.findElement(groupResultsByCategory);
			SaveThisSearch = driver.findElement(savethisSearch);
			// ClearAll = driver.findElement(clearAll);
			ExportLabel = driver.findElement(exportLabel);
			ExportOption = driver.findElement(exportOption);
			SearchInput = driver.findElement(searchInput);
			ClearButton = driver.findElement(clearButton);
			SearchButton = driver.findElement(searchButton);
			TransactionsResultsexpander = driver.findElement(transactionsResultsexpander);
			try {
				SpendAnalyzer = driver.findElement(spendAnalyzer);
				Summaries = driver.findElement(gotoSummary);
			} catch (Exception e) {
				System.out.println("Debit Card Does not have spendanalyzer");
			}
			SavedSearchExpanderAttribute = driver.findElement(savedSearchExpanderAttribute);
			FiltersExpanderAttribute = driver.findElement(filtersExpanderAttribute);
			TransactionResultsAttribute = driver.findElement(transactionsResultsAttribute);
			test.pass("Navigated to Transaction Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());

		} catch (Exception e) {
			test.fail("Transaction Page Error *********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	public class AddTimeLabel {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By addTimeLabelSideRight = By.cssSelector("body > div.aside.right.am-slide-right");

		private By allHistory = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div > button.btn.btn-100.btn-sm.btn-active");
		private By thisMonth = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div > button:nth-child(2)");
		// Credit Card
		private By sinceLastStatement = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div > button:nth-child(2)");
		private By currentMonthStatement = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div > button.btn.btn-100.btn-sm.btn-active");
		private By customDateRangeOption = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div > button.btn.btn-100.btn-sm.btn-drilldown");

		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-footer > button");

		public WebElement CloseIcon, AddTimeLabelSideRight, AllHistory, ThisMonth, Apply, CustomDateRangeOption,
				SinceLastStatement, CurrentMonthStatement;

		public AddTimeLabel(String cardType) throws IOException {
			try {
				WebDriverWait waitTime = new WebDriverWait(driver, 90);
				waitTime.until(ExpectedConditions.visibilityOfElementLocated(addTimeLabelSideRight));
				waitTime.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				AddTimeLabelSideRight = driver.findElement(addTimeLabelSideRight);
				AllHistory = driver.findElement(allHistory);
				CustomDateRangeOption = driver.findElement(customDateRangeOption);
				Apply = driver.findElement(apply);

				switch (cardType) {
				case "Debit":
					ThisMonth = driver.findElement(thisMonth);
					Apply = driver.findElement(apply);
					test.pass("Navigated to Add Time Label Side Bar",
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					break;
				case "Credit":
					SinceLastStatement = driver.findElement(sinceLastStatement);
					CurrentMonthStatement = driver.findElement(currentMonthStatement);
					CustomDateRangeOption = driver.findElement(customDateRangeOption);
					test.pass("Navigated to Add Time Label Side Bar",
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					break;
				default:
					break;
				}
			} catch (Exception e) {
				test.fail(" Add Time Label Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public class CustomDateRangeForTime {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By addCustomDateRangeSideRight = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside.right.am-slide-right.aside-overflow-visible");

		private By fromLabel = By.cssSelector("//*[@id='formSearchDates']/label[1]");
		private By fromYear = By.cssSelector("#formSearchDates > div:nth-child(2) > div > div:nth-child(1) > select");
		private By fromMonth = By.cssSelector("#formSearchDates > div:nth-child(2) > div > div:nth-child(2) > select");
		private By fromDay = By.cssSelector("#formSearchDates > div:nth-child(2) > div > div:nth-child(3) > select");

		private By toLabel = By.cssSelector("//*[@id='formSearchDates']/label[2]");
		private By toYear = By.cssSelector("#formSearchDates > div:nth-child(4) > div > div:nth-child(1) > select");
		private By toMonth = By.cssSelector("#formSearchDates > div:nth-child(4) > div > div:nth-child(2) > select");
		private By toDay = By.cssSelector("#formSearchDates > div:nth-child(4) > div > div:nth-child(3) > select");

		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside.right.am-slide-right.aside-overflow-visible > div.aside-dialog > div > div.aside-footer > button");

		public WebElement CloseIcon, AddCustomDateRangeSideRight, FromLabel, FromYear, FromMonth, FromDay, ToLabel,
				ToYear, ToMonth, ToDay, Apply;

		public CustomDateRangeForTime() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(addCustomDateRangeSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				AddCustomDateRangeSideRight = driver.findElement(addCustomDateRangeSideRight);
				// FromLabel = driver.findElement(fromLabel);
				FromYear = driver.findElement(fromYear);
				FromMonth = driver.findElement(fromMonth);
				FromDay = driver.findElement(fromDay);
				// ToLabel = driver.findElement(toLabel);
				ToYear = driver.findElement(toYear);
				ToMonth = driver.findElement(toMonth);
				ToDay = driver.findElement(toDay);
				Apply = driver.findElement(apply);
				test.pass("Navigated to Custom Date Range Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Custom Date Range Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}

		}
	}

	// }

	public class Categories {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By categoriesSideRight = By.cssSelector("body > div.aside.right.am-slide-right");

		private By clearAll = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div.grid > button:nth-child(1)");
		private By selectAll = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-body > div.grid > button:nth-child(2)");

		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-footer > button");

		public By selectcategory = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button[1]");

		public WebElement CloseIcon, CategoriesSideRight, Apply, SelectAll, ClearAll;

		public Categories() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(categoriesSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				CategoriesSideRight = driver.findElement(categoriesSideRight);
				Apply = driver.findElement(apply);
				SelectAll = driver.findElement(selectAll);
				ClearAll = driver.findElement(clearAll);
				test.pass("Navigated to Categories Side Bar",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Categories Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public class Amount {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By amountSideRight = By.cssSelector("body > div.aside.right.am-slide-right");

		private By fromLabel = By.cssSelector("#filterAmountForm > div.aside-body > div:nth-child(1) > label");
		private By fromAmount = By.id("fromAmount");

		private By toLabel = By.cssSelector("#filterAmountForm > div.aside-body > div:nth-child(2) > label");
		private By toAmount = By.id("toAmount");

		private By apply = By.cssSelector("#filterAmountForm > div.aside-footer > button.btn.btn-sm.btn-primary");
		private By clear = By.cssSelector("#filterAmountForm > div.aside-footer > button.btn.btn-sm.btn-secondary");

		public WebElement CloseIcon, AmountSideRight, Apply, FromLabel, ToLabel, FromAmount, ToAmount, Clear;

		public Amount() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(amountSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				AmountSideRight = driver.findElement(amountSideRight);
				FromLabel = driver.findElement(fromLabel);
				FromAmount = driver.findElement(fromAmount);
				ToLabel = driver.findElement(toLabel);
				ToAmount = driver.findElement(toAmount);
				Apply = driver.findElement(apply);
				Clear = driver.findElement(clear);
				test.pass("Navigated to Amount Side Bar",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Amount Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public class OrderBy {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By orderBySideRight = By.cssSelector("body > div.aside.right.am-slide-right");

		private By dateDesc = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[1]");
		private By dateAsc = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[2]");
		private By name = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[3]");
		private By amount = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div/button[4]");

		private By apply = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-footer > button");

		public WebElement CloseIcon, OrderBySideRight, DateDescending, DateAscending, Name, Amount, Apply;

		public OrderBy() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(orderBySideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				OrderBySideRight = driver.findElement(orderBySideRight);
				DateDescending = driver.findElement(dateDesc);
				DateAscending = driver.findElement(dateAsc);
				Name = driver.findElement(name);
				Amount = driver.findElement(amount);
				Apply = driver.findElement(apply);
				test.pass("Navigated to Order By Side Bar",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Order By Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public class SaveThisSearchConfirmModal {

		private By closeIcon = By.cssSelector("#modalContent > div.modal-header > button > span:nth-child(1)");

		private By modalTitle = By.cssSelector("#modalContent > div.modal-header > h3");
		public String expectedmodalTitle = "Save Transaction Search";
		private By savesearchName = By.id("searchName");
		private By save = By.cssSelector("#modalContent > div.modal-footer > button.btn.btn-primary.btn-sm");
		private By cancel = By.cssSelector("#modalContent > div.modal-footer > button:nth-child(2)");
		public By successmessage = By.cssSelector("#toast-container > div > div");

		public WebElement CloseIcon, ModalTitle, Save, Cancel, SaveSearchName;

		public SaveThisSearchConfirmModal() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(modalTitle));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				ModalTitle = driver.findElement(modalTitle);
				Save = driver.findElement(save);
				Cancel = driver.findElement(cancel);
				SaveSearchName = driver.findElement(savesearchName);
				test.pass("Navigated to Save this search screen",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Save this search Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public class DeleteModal {

		private By closeIcon = By
				.cssSelector("body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-header > button");

		private By modalTitle = By
				.cssSelector("body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-header > h3");
		public String expectedmodalTitle = "Confirm Delete";
		private By confirmationText = By
				.cssSelector("body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-body > p");
		private By delete = By.cssSelector(
				"body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-footer > button.btn.btn-sm.btn-primary");
		private By cancel = By.cssSelector(
				"body > div.modal.top.am-fade > div.modal-dialog > div > div.modal-footer > button:nth-child(2)");
		public By successmessage = By.cssSelector("#toast-container > div > div");

		public WebElement CloseIcon, ModalTitle, Delete, Cancel;

		public DeleteModal() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(modalTitle));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				ModalTitle = driver.findElement(modalTitle);
				Delete = driver.findElement(delete);
				Cancel = driver.findElement(cancel);
				test.pass("Navigated to Save this search screen",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" Save this search Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public void clearSavedSearch() throws IOException, InterruptedException {
		int sizeofSearchElement = driver.findElements(By.xpath("//*[@id='collapsible-searches']/div/ul/li")).size();
		if (sizeofSearchElement > 0) {
			for (int i = 1; i <= sizeofSearchElement; i++) {
				driver.findElement(By.xpath("//*[@id='collapsible-searches']/div/ul/li/div[2]/button/span[1]")).click();
				Thread.sleep(2000);
				DeleteModal deleteconfirmModal = new DeleteModal();
				deleteconfirmModal.Delete.click();
				Thread.sleep(10000);
				try {
					driver.findElement(deleteconfirmModal.successmessage).click();
				} catch (NoSuchElementException e) {
					// Ignore
				}
			}
		}
	}

	public int numberofTransactions() {
		List<WebElement> Element = driver.findElements(By.xpath("//*[@id='collapsible-txns']/div[1]/div"));
		int numberoftransactions = Element.size();
		return numberoftransactions;
	}

	public String getDataForSearchInput(String inputType) throws InterruptedException {
		// Down Expander Arrow of First Row
		String inputData = null;
		driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[1]")).click();
		Thread.sleep(5000);
		if (inputType.equalsIgnoreCase("GetMerchantName")) {
			String merchantName = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[2]/div/div[1]/p/span[2]"))
					.getText();
			merchantName = merchantName.replace("Merchant:", "").trim();
			System.out.println(merchantName);
			inputData = merchantName;
		} else if (inputType.equalsIgnoreCase("GetCategory")) {
			String category = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[2]/div/div[1]/p/span[3]"))
					.getText();
			category = category.replace("Category:", "").trim();
			System.out.println(category);
			inputData = category;
		} else if (inputType.equalsIgnoreCase("GetAmount")) {
			String amount = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[2]/div/div[2]/p/span[2]"))
					.getText();
			amount = amount.replace("Original Amount: ", "").trim();
			String originalamount = amount.replace("$", "");
			System.out.println(originalamount);
			inputData = originalamount;
		} else if (inputType.equalsIgnoreCase("GetTransactionDate")) {
			String transactionDate = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[2]/div/div[1]/p/span[1]"))
					.getText();
			transactionDate = transactionDate.replace("Transaction Date:", "").trim();
			System.out.println(transactionDate);
			inputData = transactionDate;
		}
		driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[1]")).click();
		return inputData;
	}

	public String getDataForSearchInputforspecificRow(String inputType, int row) throws InterruptedException {
		// Down Expander Arrow of First Row
		String inputData = null;
		// driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div["+row+"]/div[1]")).click();
		Thread.sleep(10000);
		if (inputType.equalsIgnoreCase("GetCategory")) {
			String category = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + row + "]/div[1]/div[2]/div"))
					.getText();
			category = category.replace("Category:", "").trim();
			System.out.println(category);
			inputData = category;
		} else if (inputType.equalsIgnoreCase("GetAmount")) {
			String amount = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + row + "]/div[1]/div[2]/div"))
					.getText();
			amount = amount.replace("Original Amount: ", "").trim();
			String originalamount = amount.replace("$", "");
			System.out.println(originalamount);
			inputData = originalamount;
		} else if (inputType.equalsIgnoreCase("GetTransactionDate")) {
			String transactionDate = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + row + "]/div[1]/div[1]/div"))
					.getText();
			transactionDate = transactionDate.replace("Transaction Date:", "").trim();
			System.out.println(transactionDate);
			transactionDate = transactionDate.toLowerCase();
			String firstLetter = transactionDate.substring(0, 1);
			String newdate = firstLetter.toUpperCase() + transactionDate.substring(1);
			inputData = newdate;
		}

		return inputData;
	}

	public boolean VerifyInputDataForAllTransactions(String inputType, String InputData)
			throws InterruptedException, IOException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		boolean filterapplied;
		
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		System.out.println(numberofrows);
		try {
			filterapplied = driver.findElement(filter1).isDisplayed();
		} catch (Exception e) {
			filterapplied = false;
		}
		Robot robot = new Robot();
		for (int i = 1; i <= numberofrows; i++) {
			System.out.println(i);
			for(int j=1;j<=i;j++)
			{
				robot.keyPress(KeyEvent.VK_DOWN);
				Thread.sleep(1000);
			}

			WebElement expanderbutton = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]"));
			expanderbutton.click();
			
			Thread.sleep(3000);

			if (inputType.equalsIgnoreCase("GetMerchantName")) {
				String merchantName = driver
						.findElement(By
								.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[2]"))
						.getText();
				merchantName = merchantName.replace("Merchant:", "").trim();

				if (merchantName.equalsIgnoreCase(InputData)) {
					flag = true;
					test.pass("Matched Merchant Name Actual: " + merchantName + " Expected: " + InputData,
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());					
				} else {
					flag = false;
					test.fail("Not Matched in Merchant Actual: " + merchantName + " Expected: " + InputData,
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					return flag;
				}
			}
			if (inputType.equalsIgnoreCase("GetCategory")) {
				String categoryName = driver
						.findElement(By
								.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[3]"))
						.getText();
				System.out.println(categoryName);
				if (!categoryName.contains("Category")) {
					categoryName = driver
							.findElement(By.xpath(
									"//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[4]"))
							.getText();
				}
				if (!categoryName.contains("Category")) {
					categoryName = driver
							.findElement(By.xpath(
									"//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[5]"))
							.getText();
				}
				categoryName = categoryName.replace("Category:", "").trim();
				if (categoryName.equalsIgnoreCase(InputData)) {
					flag = true;
					test.pass("Matched in Category Actual: " + categoryName + " Expected: " + InputData,
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				} else {					
					flag = false;
					test.fail("Not Matched in Category Actual: " + categoryName + " Expected: " + InputData,
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					return flag;
				}
			}
			if (inputType.equalsIgnoreCase("GetAmount")) {
				String amount = driver
						.findElement(By
								.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[2]/p/span[2]"))
						.getText();
				amount = amount.replace("Original Amount: ", "");
				InputData = "$" + InputData;
				if (amount.equals(InputData)) {
					flag = true;
					test.pass("Matched in Amount Actual: " + amount + " Expected: " + InputData,
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				} else {
					flag = false;
					test.fail("Not Matched in Amount Actual: " + amount + " Expected: " + InputData,
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					return flag;
				}
			}
			
		
		}
		if (numberofPages > 1) {
			//Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;

	}
	
	
	
	public boolean VerifySearchInputBySearchTextBox(String InputData)
			throws InterruptedException, IOException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		System.out.println(numberofrows);
		Robot robot = new Robot();
		for (int i = 1; i <= numberofrows; i++) {
			System.out.println(i);
			for(int j=1;j<=i;j++)
			{
				robot.keyPress(KeyEvent.VK_DOWN);
				Thread.sleep(1000);
			}

			WebElement expanderbutton = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]"));
			expanderbutton.click();
			
			Thread.sleep(3000);
		System.out.println(driver.findElement(By.xpath("//*[@id='collapsible-txns']/div/div["+i+"]/div[1]/div[1]/span")).getText());
				if(driver.findElement(By.xpath("//*[@id='collapsible-txns']/div/div["+i+"]/div[1]/div[1]/span")).getText().toLowerCase().contains(InputData.toLowerCase())) {
					flag = true;
					test.pass("Matched Text Actual: " + driver.findElement(By.xpath("//*[@id='collapsible-txns']/div/div["+i+"]/div[1]/div[1]/span")).getText() + " Expected: " + InputData,
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				}
				 else {
					 if (driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[2]")).getText().toLowerCase().contains(InputData.toLowerCase())) {
							flag = true;
							test.pass("Matched Text Actual: " + driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[2]")).getText() + " Expected: " + InputData,
									MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());					
						}
					 else if(driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[3]")).getText().toLowerCase().contains(InputData.toLowerCase())) {
													//*[@id='collapsible-txns']/div/div[3]/div[1]/div[1]/span
						flag = true;
						test.pass("Matched Text Actual: " + driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[3]")).getText() + " Expected: " + InputData,
								MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					}
					else if(driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[4]")).getText().toLowerCase().contains(InputData.toLowerCase())) {
						flag = true;
						test.pass("Matched Text Actual: " + driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[4]")).getText() + " Expected: " + InputData,
								MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					}
					else if(driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[2]/p/span[2]")).getText().toLowerCase().contains(InputData.toLowerCase())) {
						flag = true;
						test.pass("Matched Text Actual: " + driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[2]/p/span[2]")).getText() + " Expected: " + InputData,
								MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					}
					else {
					flag = false;
					test.fail("Not Matched in Any of items Expected: " + InputData,
							MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
					return flag;
					}
				}	
				expanderbutton.click();
		}
		if (numberofPages > 1) {
			//Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;
	}
	
	

	public boolean verifyAscendingOrderForAmount() throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;

		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		
		int numberofrows = numberofTransactions();
		for (int i = 1; i < numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String amount1 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[1]/div[2]/div"))
					.getText().replace("$", "").replace(",", "");
			String amount2 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + (i + 1) + "]/div[1]/div[2]/div"))
					.getText().replace("$", "").replace(",", "");
			;
			float v1 = Float.parseFloat(amount1);
			float v2 = Float.parseFloat(amount2);
			if (v1 <= v2) {
				flag = true;
			} else {
				flag = false;
				return flag;
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;

	}

	public boolean verifyAscendingOrderForName() throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		for (int i = 1; i < numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String name1 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[1]/div[1]/span"))
					.getText();
			String name2 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + (i + 1) + "]/div[1]/div[1]/span"))
					.getText();
			int compare = name1.compareToIgnoreCase(name2);
			if (compare < 0) {
				flag = true;
			} else if (compare == 0) {
				flag = true;
			} else {
				flag = false;
				return flag;
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;

	}

	public boolean verifyDescendingOrderForName() throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		for (int i = 1; i < numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String name1 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[1]/div[1]/span"))
					.getText();
			String name2 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + (i + 1) + "]/div[1]/div[1]/span"))
					.getText();
			int compare = name1.compareToIgnoreCase(name2);
			if (compare > 0) {
				flag = true;
			} else if (compare == 0) {
				flag = true;
			} else {
				flag = false;
				return flag;
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;

	}

	public boolean verifyDateAscendingOrder() throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		for (int i = 1; i < numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String transactiondate1 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[1]/div[1]/div"))
					.getText();
			String transactiondate2 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + (i + 1) + "]/div[1]/div[1]/div"))
					.getText();

			transactiondate1 = transactiondate1.toLowerCase();
			String firstLetter1 = transactiondate1.substring(0, 1);
			String newdate1 = firstLetter1.toUpperCase() + transactiondate1.substring(1);
			transactiondate1 = newdate1;

			transactiondate2 = transactiondate2.toLowerCase();
			String firstLetter2 = transactiondate2.substring(0, 1);
			String newdate2 = firstLetter2.toUpperCase() + transactiondate2.substring(1);
			transactiondate2 = newdate2;

			LocalDate date1 = DateValue(transactiondate1);
			LocalDate date2 = DateValue(transactiondate2);
			if (date1.compareTo(date2) < 0) {
				System.out.println("Date1 is before Date2");
				flag = true;
			} else if (date1.compareTo(date2) == 0) {
				System.out.println("Date1 is equal to Date2");
				flag = true;
			} else {
				flag = false;
				return flag;
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;

	}

	public boolean verifyDateDescendingOrder() throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		for (int i = 1; i < numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String transactiondate1 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[1]/div[1]/div"))
					.getText();
			String transactiondate2 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + (i + 1) + "]/div[1]/div[1]/div"))
					.getText();

			transactiondate1 = transactiondate1.toLowerCase();
			String firstLetter1 = transactiondate1.substring(0, 1);
			String newdate1 = firstLetter1.toUpperCase() + transactiondate1.substring(1);
			transactiondate1 = newdate1;

			transactiondate2 = transactiondate2.toLowerCase();
			String firstLetter2 = transactiondate2.substring(0, 1);
			String newdate2 = firstLetter2.toUpperCase() + transactiondate2.substring(1);
			transactiondate2 = newdate2;

			LocalDate date1 = DateValue(transactiondate1);
			LocalDate date2 = DateValue(transactiondate2);
			if (date1.compareTo(date2) > 0) {
				System.out.println("Date1 is after Date2");
				flag = true;
			} else if (date1.compareTo(date2) == 0) {
				System.out.println("Date1 is equal to Date2");
				flag = true;
			} else {
				flag = false;
				return flag;
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;

	}

	public boolean verifyAmountIsWithInTheRange(String from, String To) throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
		int numberofrows = numberofTransactions();
		for (int i = 1; i <= numberofrows; i++) {
			if (i <= 7) {
				ScrollToElement(AmountOption);
			} else {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			}
			String amount1 = driver
					.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[1]/div[2]/div"))
					.getText().replace("$", "");
			amount1 = amount1.replace(",", "");
			if (from.length() > 0 && To.length() > 0) {
				float v1 = Float.parseFloat(amount1);
				float v2 = Float.parseFloat(from);
				float v3 = Float.parseFloat(To);
				if (v1 >= v2 && v1 <= v3) {
					flag = true;
					test.info(amount1 + " is within the range of Lowerrange " + v2 + " and Upper Range " + v3);
				} else {
					flag = false;
					test.info(amount1 + " is NOT within the range of Lowerrange " + v2 + " and Upper Range " + v3);
					return flag;
				}
			}
			if (from.length() == 0 && To.length() > 0) {
				float v1 = Float.parseFloat(amount1);
				float v3 = Float.parseFloat(To);
				if (v1 <= v3) {
					flag = true;
					test.info(amount1 + " is within the Upper Range " + v3);
				} else {
					flag = false;
					test.info(amount1 + " is greater than the Upper Range " + v3);
					return flag;
				}
			}

			if (from.length() > 0 && To.length() == 0) {
				float v1 = Float.parseFloat(amount1);
				float v2 = Float.parseFloat(from);
				if (v1 >= v2) {
					flag = true;
					test.info(amount1 + " is on or above the Lower Range " + v2);
				} else {
					flag = false;
					test.info(amount1 + " is lesser than the Lower Range " + v2);
					return flag;
				}
			}
		}
		if (numberofPages > 1) {
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_DOWN);
			driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			Thread.sleep(15000);
			robot.keyPress(KeyEvent.VK_PAGE_UP);
		}
		}
		return flag;
	}

	public boolean verifyDateIsWithinRange(String from, String to) throws InterruptedException, AWTException {
		// Down Expander Arrow of First Row
		boolean flag = false;
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
			int numberofrows = numberofTransactions();
			System.out.println(numberofrows);
			for (int i = 1; i <= numberofrows; i++) {
				String transactiondate = driver
						.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[1]/div[1]/div"))
						.getText().trim();
				transactiondate = transactiondate.toLowerCase();
				String firstLetter = transactiondate.substring(0, 1);
				String newdate = firstLetter.toUpperCase() + transactiondate.substring(1);
				transactiondate = newdate;
				if (from.length() > 0 && to.length() > 0) {
					LocalDate date1 = DateValue(from);
					LocalDate date2 = DateValue(transactiondate);
					LocalDate date3 = DateValue(to);
					if (date2.compareTo(date1) >= 0 && date2.compareTo(date3) <= 0) {
						System.out.println(date1);
						System.out.println(date2);
						System.out.println(date3);
						System.out.println(date2.compareTo(date3));
						System.out.println(date1.compareTo(date2));
						System.out.println("Transaction date is within the range");
						flag = true;
					} else {
						flag = false;
						return flag;
					}
				}
				if (from.length() == 0 && to.length() > 0) {
					// LocalDate date1 = DateValue(from);
					LocalDate date2 = DateValue(transactiondate);
					LocalDate date3 = DateValue(to);
					if (date2.compareTo(date3) <= 0) {
						System.out.println(date2);
						System.out.println(date3);
						System.out.println(date2.compareTo(date3));
						System.out.println("Transaction date is within the range");
						flag = true;
					} else {
						flag = false;
						return flag;
					}
				}
				if (from.length() > 0 && to.length() == 0) {
					LocalDate date1 = DateValue(from);
					LocalDate date2 = DateValue(transactiondate);
					// LocalDate date3 = DateValue(to);
					if (date2.compareTo(date1) >= 0) {
						System.out.println(date1);
						System.out.println(date2);
						System.out.println(date1.compareTo(date2));
						System.out.println("Transaction date is within the range");
						flag = true;
					} else {
						flag = false;
						return flag;
					}
				}
			}
			if (numberofPages > 1) {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			}
		}
		return flag;
	}

	public String SaveThisSearch() throws InterruptedException, IOException {
		SaveThisSearch.click();
		Thread.sleep(2000);
		SaveThisSearchConfirmModal savethisconfirmModal = new SaveThisSearchConfirmModal();
		savethisconfirmModal.SaveSearchName.sendKeys("AnyTest");
		savethisconfirmModal.Save.click();
		Thread.sleep(2000);
		try {
			WebDriverWait wait = new WebDriverWait(driver, 15);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(savethisconfirmModal.successmessage)));
			System.out.println(driver.findElement(savethisconfirmModal.successmessage).getText());
			// AssertVerify(driver.findElement(savethisconfirmModal.successmessage).getText(),
			// "Transactions Search was saved successfully");
			driver.findElement(savethisconfirmModal.successmessage).click();
		} catch (Exception e) {

		}
		AssertVerify(driver.findElement(savedSearchName).getText(), "AnyTest");
		return driver.findElement(savedSearchName).getText();
	}

	public void DeleThisSearch() throws IOException {
		driver.findElement(deletesearch).click();
		DeleteModal deleteconfirmModal = new DeleteModal();
		deleteconfirmModal.Delete.click();
		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			wait.until(ExpectedConditions.visibilityOf(driver.findElement(deleteconfirmModal.successmessage)));
			// AssertVerify(driver.findElement(deleteconfirmModal.successmessage).getText(),
			// "Transactions Search deleted successfully");
			driver.findElement(deleteconfirmModal.successmessage).click();
		} catch (Exception e) {

		}
		Transactions transaction = new Transactions();
	}

	public void verifyGroupByCategory(ArrayList<HashMap> tableData)
			throws InterruptedException, AWTException, IOException {
		// Down Expander Arrow of First Row
		try {
		boolean flag = false;
		int numberofPages = 0;
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int a = 1; a <= numberofPages; a++) {
			int numberofgroups = driver.findElements(By.xpath("//*[@id='collapsible-txns']/div")).size();
			if (numberofPages < 2) {
				numberofgroups = numberofgroups + 1;
			}
			for (int j = 1; j < numberofgroups; j++) {
				int numberofrowsineachcategory = driver
						.findElements(By.xpath("//*[@id='collapsible-txns']/div[" + j + "]/div")).size();
				System.out.println("numberofrowsineachcategory: " + numberofrowsineachcategory);
				int categorycounter = 0;
				double totalamount = 0;
				String category = null;
				String groupcategoryName = null;
				String groupByCount = null;
				String sumofCurrentSum = null;
				String totalAmount = null;
				String actualgroupByMessage = null;
				String expected = null;
				for (int i = 1; i <= numberofrowsineachcategory; i++) {
					if (i <= 6) {
						ScrollToElement(AmountOption);
					} else {
						Robot robot = new Robot();
						robot.keyPress(KeyEvent.VK_PAGE_DOWN);
					}
					category = driver
							.findElement(By.xpath(
									"//*[@id='collapsible-txns']/div[" + j + "]/div[" + i + "]/div[1]/div[2]/span"))
							.getText();
					System.out.println(category);
					String amount = driver
							.findElement(By.xpath(
									"//*[@id='collapsible-txns']/div[" + j + "]/div[" + i + "]/div[1]/div[2]/div"))
							.getText().replace("$", "").replace(",", "");
					double transactionamount = Double.parseDouble(amount);
					totalamount = totalamount + transactionamount;
					categorycounter = categorycounter + 1;
				}
				System.out.println(categorycounter);
				System.out.println(totalamount);
				totalamount = (Math.round(totalamount * 100) / 100.00);
				groupcategoryName = driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[" + j + "]/header"))
						.getText().trim().toLowerCase();
				System.out.println("Actual:" + groupcategoryName);
				int index = getIndexForCategory(tableData, category);
				String sum = tableData.get(index).get("Sum").toString();
				if (sum.endsWith(".0") == true) {
					sum = sum.replace(".0", ".00");
				}
				DecimalFormat df = new DecimalFormat("0.00");
				String totalsumamount = df.format(totalamount);
				expected = category.toLowerCase() + " " + categorycounter + " of "
						+ tableData.get(index).get("numberofTransactions") + ": $" + totalsumamount + " of " + "$"
						+ sum;
				AssertVerify(groupcategoryName, expected);
			}
			if (numberofPages > 1) {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				/*driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[" + numberofgroups + "]/div/li[5]/a"))
						.click();*/
				driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			}
		}
		}
		catch(Exception e) {
			test.fail("Transaction Page Error *********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}

	}

	public class EditModal {

		private By closeIcon = By.cssSelector("#modalContent > div.modal-header > button > span:nth-child(1)");

		private By modalTitle = By.cssSelector("#dialogTitle");
		public String expectedmodalTitle = "Update Transaction Detail";
		private By helpIcon = By.cssSelector("#dialogTitle > button > span.icon-help-circled");
		private By originalCategoryLabel = By
				.cssSelector("#modalContent > div.modal-body.form-stacked > div:nth-child(1) > label");
		private By originalCategoryValue = By.cssSelector("#mccCategoryId");
		private By newCategory = By.cssSelector("#personalMccCategoryId");
		private By memoLabel = By.cssSelector("#modalContent > div.modal-body.form-stacked > div:nth-child(3) > label");
		private By memoInput = By.cssSelector("#memo");
		private By submit = By.cssSelector("#modalContent > div.modal-footer > button.btn.btn-sm.btn-secondary");
		private By cancel = By.cssSelector("#modalContent > div.modal-footer > button:nth-child(1)");

		public WebElement CloseIcon, ModalTitle, HelpIcon, OriginalCategoryLabel, OriginalCategoryValue, NewCategory,
				MemoLabel, MemoInputField, Submit, Cancel;

		public EditModal() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(modalTitle));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				ModalTitle = driver.findElement(modalTitle);
				HelpIcon = driver.findElement(helpIcon);
				OriginalCategoryLabel = driver.findElement(originalCategoryLabel);
				OriginalCategoryValue = driver.findElement(originalCategoryValue);
				NewCategory = driver.findElement(newCategory);
				MemoLabel = driver.findElement(memoLabel);
				MemoInputField = driver.findElement(memoInput);
				Submit = driver.findElement(submit);
				Cancel = driver.findElement(cancel);
				test.pass("Navigated to Update Transaction Modal screen",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Update Transaction Modal Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public void EditRow() throws InterruptedException {
		driver.findElement(expandfirstRowToEdit).click();
		Thread.sleep(3000);
		driver.findElement(editCategory).click();
	}

	public ArrayList<HashMap> getnumberofRowsandamount() throws IOException, AWTException, InterruptedException {
		try {
		Transactions transaction = new Transactions();

		ScrollToElement(CategoriesOption);
		CategoriesOption.click();
		ArrayList<HashMap> columnArray = new ArrayList<HashMap>();
		int numberofcategories = driver.findElements(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button"))
				.size();
		for (int i = 1; i < numberofcategories; i++) {
			double TotalAmount = 0;
			int numberofPages = 0;
			Transactions.Categories categories = transaction.new Categories();
			categories.ClearAll.click();
			WebElement element = driver
					.findElement(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button[" + i + "]"));
			element.click();
			String categoryname = element.getAttribute("title");
			categories.Apply.click();
			String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
					.replace(")", "").replace("(", "");
			numberofPages = numberofPages(numberofTransactions);
			System.out.println(numberofPages);
			HashMap<String, String> list = new HashMap<String, String>();
			for (int k = 1; k <= numberofPages; k++) {
				int numberofRows = driver.findElements(By.xpath("//*[@id='collapsible-txns']/div[1]/div")).size();
				for (int j = 1; j <= numberofRows; j++) {
					String amount = driver
							.findElement(
									By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + j + "]/div[1]/div[2]/div"))
							.getText().replace("$", "").replace(",", "");
					double transactionamount = Double.parseDouble(amount);
					System.out.println(transactionamount);
					TotalAmount = TotalAmount + transactionamount;
				}
				if (numberofPages > 1) {
					driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
				}
				list.put("CategoryName", categoryname.toLowerCase());
				list.put("numberofTransactions", numberofTransactions);
				list.put("Sum", Double.toString(TotalAmount));

			}
			columnArray.add(list);

			System.out.println(list);
			Robot robot = new Robot();
			robot.keyPress(KeyEvent.VK_PAGE_UP);
			Thread.sleep(2000);
			ScrollToElement(CategoriesOption);
			CategoriesOption.click();
		}
		System.out.println(columnArray);
		return columnArray;
		}
		catch(Exception e) {
			test.fail("Error on Fetching number of transactions and sum");
			return null;
		}
	}

	public int getIndexForCategory(ArrayList<HashMap> data, String CategoryName) {
		int size = data.size();
		System.out.println(data);
		System.out.println(CategoryName);
		for (int i = 0; i < size; i++) {
			if (data.get(i).get("CategoryName").equals(CategoryName.toLowerCase())) {
				System.out.println(CategoryName);
				System.out.println(i);
				return i;
			}
		}
		return -1;

	}

	public ArrayList<String> SelectMultipleCategory(int numberofcategoriestobeselected)
			throws IOException, AWTException, InterruptedException {
		Transactions transaction = new Transactions();
		ArrayList<String> listofcategories = new ArrayList<>();
		ScrollToElement(CategoriesOption);
		CategoriesOption.click();
		Transactions.Categories categories = transaction.new Categories();
		categories.ClearAll.click();
		int numberofcategories = driver.findElements(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button"))
				.size() - 1;
		if (numberofcategories < numberofcategoriestobeselected) {
			numberofcategoriestobeselected = numberofcategories;
		}
		listofcategories = new ArrayList<String>();
		for (int i = 1; i <= numberofcategoriestobeselected; i++) {
			WebElement element = driver
					.findElement(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button[" + i + "]"));
			element.click();
			String categoryname = element.getAttribute("title");
			listofcategories.add(categoryname);
		}
		categories.Apply.click();

		return listofcategories;
	}

	public boolean verifyMultipleCategoryResult(ArrayList<String> categoriesselected) throws IOException {
		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);
		System.out.println(numberofPages);

		for (int k = 1; k <= numberofPages; k++) {
			int numberofRows = driver.findElements(By.xpath("//*[@id='collapsible-txns']/div[1]/div")).size();
			for (int j = 1; j <= numberofRows; j++) {
				String Category = driver
						.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + j + "]/div[1]/div[2]/span"))
						.getText();
				System.out.println(Category);
				boolean flag = false;
				for (int a = 0; a < categoriesselected.size(); a++) {

					if (categoriesselected.get(a).toString().equalsIgnoreCase(Category)) {
						flag = true;
						test.pass(Category + "Matched" + categoriesselected.get(a).toString(),
								MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
						a = categoriesselected.size();
					} else {
						flag = false;
					}
				}
				if (flag == false) {
					test.fail("Mismatch Category expected");
					return flag;
				}
			}
			if (numberofPages > 1) {
				driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
			}

		}
		return true;
	}

	public class ExportModal {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By modal = By.cssSelector("body > div.aside.right.am-slide-right");
		private By modalTitle = By
				.cssSelector("body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > h3");
		public String expectedmodalTitle = "Export Results";
		private By csvFormat = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/form/div/button[1]");
		private By qboFormat = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/form/div/button[2]");
		private By qfxFormat = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/form/div/button[3]");
		private By tabFormat = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/form/div/button[4]");
		private By close = By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[3]/button");

		public WebElement CloseIcon, RightSideModal, ModalTitle, CSVFormat, QBOFormat, QFXFormat, TabFormat, Close;

		public ExportModal() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(modalTitle));
				wait.until(ExpectedConditions.visibilityOfElementLocated(closeIcon));
				CloseIcon = driver.findElement(closeIcon);
				RightSideModal = driver.findElement(modal);
				ModalTitle = driver.findElement(modalTitle);
				CSVFormat = driver.findElement(csvFormat);
				QBOFormat = driver.findElement(qboFormat);
				QFXFormat = driver.findElement(qfxFormat);
				TabFormat = driver.findElement(tabFormat);
				Close = driver.findElement(close);
				test.pass("Navigated to Export Modal screen",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Export Modal Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}

	public ArrayList<String> getAllCategories() throws IOException, InterruptedException {
		WebElement more = driver.findElement(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button[5]"));
		more.click();
		ArrayList<String> categoriesList = new ArrayList<String>();

		int numberofcategoriespresent = driver
				.findElements(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button")).size();
		for (int i = 1; i < numberofcategoriespresent; i++) {
			category = driver.findElement(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/button[" + i + "]"))
					.getAttribute("title");
			categoriesList.add(category);
		}
		int numberofcategoriesnotavailable = driver
				.findElements(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div[3]/button")).size();

		for (int j = 1; j <= numberofcategoriesnotavailable; j++) {
			category = driver
					.findElement(By.xpath("//*[@id='app']/body/div[4]/div[2]/div/div[2]/div[3]/button[" + j + "]"))
					.getText().trim();
			categoriesList.add(category);
		}
		System.out.println(categoriesList);
		return categoriesList;

	}

	public ArrayList<LinkedHashMap> returnDatasToVerifyExportRecord()
			throws InterruptedException, IOException, AWTException {
		try {
		// Down Expander Arrow of First Row
		boolean flag = false;

		String numberofTransactions = driver.findElement(By.xpath("//*[@id='Transactions']/div/span[3]")).getText()
				.replace(")", "").replace("(", "");
		int numberofPages = numberofPages(numberofTransactions);

		System.out.println(numberofPages);
		ArrayList<LinkedHashMap> userdata = new ArrayList<>();
		for (int k = 1; k <= numberofPages; k++) {
			int numberofrows = numberofTransactions();
			System.out.println(numberofrows);

			for (int i = 1; i <= numberofrows; i++) {
				Robot robot = new Robot();
				// Work Around for Page down to get the details of expander view
				if (i <= 5) {
					ScrollToElement(AmountOption);
				}
				if (i >= 6) {
					robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				}
				WebElement expanderbutton = driver
						.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]"));
				expanderbutton.click();
				Thread.sleep(3000);
				int Numberofleftspans = driver
						.findElements(
								By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span"))
						.size();
				int Numberofrightspans = driver
						.findElements(
								By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[2]/p/span"))
						.size();
				if (Numberofrightspans > 4) {
					Numberofrightspans = 5;
				}
				LinkedHashMap<String, String> detailsofUI = new LinkedHashMap<>();
				for (int a = 1; a <= Numberofleftspans; a++) {
					String data = driver.findElement(By.xpath(
							"//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[1]/p/span[" + a + "]"))
							.getText();
					String[] details = data.split(":");
					detailsofUI.put(details[0].trim(), details[1].trim());
				}
				for (int b = 1; b <= Numberofrightspans; b++) {
					String data = driver.findElement(By.xpath(
							"//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[2]/div/div[2]/p/span[" + b + "]"))
							.getText();
					String[] details = data.split(":");
					detailsofUI.put(details[0].trim(), details[1].trim());
				}
				userdata.add(detailsofUI);
				if (i < 5) {
					driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[" + i + "]/div[1]")).click();
					Thread.sleep(3000);
				}
				robot.keyPress(KeyEvent.VK_PAGE_UP);
				System.out.println(detailsofUI);
			}
			if (numberofPages > 1) {
				Robot robot = new Robot();
				robot.keyPress(KeyEvent.VK_PAGE_DOWN);
				driver.findElement(By.xpath("//a[(text() = 'Next')]")).click();
				Thread.sleep(15000);
				robot.keyPress(KeyEvent.VK_PAGE_UP);
			}
		}
		System.out.println(userdata);
		return userdata;
		}
		catch(Exception e) {
			test.fail("Error on Fetching Data");
			return null;
		}
		
	}

}