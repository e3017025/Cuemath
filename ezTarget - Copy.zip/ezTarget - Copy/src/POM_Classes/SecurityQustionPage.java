package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import com.aventstack.extentreports.MediaEntityBuilder;

public class SecurityQustionPage extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By headingmessage = By.id("mainHeading");
	private By username = By
			.cssSelector("#main > div > div > div.grid > div > div > div > form > div:nth-child(1) > h3");
	private By notYourUsername = By.linkText("Not your Username?");
	private By privateDeviceYesIndicator = By.cssSelector(
			"#main > div > div > div.grid > div > div > div > form > div:nth-child(3) > div > label:nth-child(1) > input");
	private By privateDeviceNoIndicator = By.cssSelector(
			"#main > div > div > div.grid > div > div > div > form > div:nth-child(3) > div > label:nth-child(2) > input");
	private By continueButton = By.id("btnSubmit");
	private By cancelButton = By.id("btnCancel");
	private By securityQuestion = By.xpath("//*[@id='main']/div/div/div[2]/div/div/div/form/div[2]/label");
	private By securityanswer = By.xpath("//input[contains(@id, 'Q') and @data-ng-model = 'cq.answer']");
	private By help = By.cssSelector("#main > div > div > div.page-header > button > span.icon-info-circled");

	private static By errorMessage = By.xpath("//div[@data-ct-helpselect='headerError']");
	public String actualerrorMessage;
	public String expectederrorMessage = "We're sorry, the security answer does not match the question.";
	
	// Expected Messages
	public static String inlineTextForUsername = "Username";
	public static String welcomeMessageText = "Sign in to Manage My REDcard";

	public WebElement UserName, HeadingMessage, NotYourUsername, ContinueButton, CancelButton, WelcomeHeader,
			SecurityQuestionHelpIcon, SecurityQuestion, SecurityAnswer,PrivateDeviceYesIndicator,PrivateDeviceNoIndicator;
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public SecurityQustionPage() throws InterruptedException, IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 60);
			wait.until(ExpectedConditions.visibilityOfElementLocated(securityQuestion));
			wait.until(ExpectedConditions.visibilityOfElementLocated(username));
			wait.until(ExpectedConditions.visibilityOfElementLocated(continueButton));
			WelcomeHeader = driver.findElement(welcomeHeader);
			UserName = driver.findElement(username);
			HeadingMessage = driver.findElement(headingmessage);
			NotYourUsername = driver.findElement(notYourUsername);
			ContinueButton = driver.findElement(continueButton);
			CancelButton = driver.findElement(cancelButton);
			SecurityQuestion = driver.findElement(securityQuestion);
			SecurityAnswer = driver.findElement(securityanswer);
			SecurityQuestionHelpIcon = driver.findElement(help);
			PrivateDeviceYesIndicator= driver.findElement(privateDeviceYesIndicator);
			PrivateDeviceNoIndicator=driver.findElement(privateDeviceNoIndicator);
			test.pass("RSA is ON: Navigated to Security Answer Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			
		} catch (Exception e) {
			test.fail("Security Question Page Error *********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	/*
	 * This method is used to get the security answer from the security question.
	 * Logic: If last word security question is >3 characters then security answer
	 * is last word. else last two words.
	 * ************************************************************************ eg.,
	 * If Question is: What is the amount of your monthly car payment? Answer is:
	 * Payment eg., If Questionis: What is your new car? Answer is: new car
	 * *************************************************************************
	 */

	public static String getsecurityAnswer(String securityQuestion) {
		System.out.println(securityQuestion);
		String[] str = securityQuestion.split(" ");
		String lastword = str[str.length - 1];
		String securityanswer;
		if (lastword.length() <= 3) {
			securityanswer = str[str.length - 2] + " " + lastword.replace("?", "");
			System.out.println(securityanswer);
		} else {
			securityanswer = lastword.replace("?", "");
		}
		System.out.println(securityanswer);
		return securityanswer;
	}

	/*
	 * This method is used to enter the security answer
	 */

	public void securityAnswerValidator() throws InterruptedException, IOException {		
		String securityanswer = SecurityQustionPage
				.getsecurityAnswer(SecurityQuestion.getText().toString());
		SecurityAnswer.sendKeys(securityanswer);
		test.info("Security Question is:"+SecurityQuestion.getText().toString()+ " and Answer is "+securityanswer);
		ContinueButton.click();
		try {			
			PasswordPage password= new PasswordPage();						
		} catch (Exception e) {
			ErrorMessage = driver.findElement(errorMessage);
			test.info(ErrorMessage.getText() + " is displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());			
		}
	}

	/*
	 * This method is used to verify the error Message flow
	 */

	 public void errorMessage() throws InterruptedException, IOException {		
		String securityanswer = SecurityQustionPage.getsecurityAnswer(SecurityQuestion.getText().toString());
		Assert.assertEquals(UserName.getText().toString(), BaseClass.unsuccessfulusername);
		SecurityAnswer.sendKeys(securityanswer);
		ContinueButton.click();
		try {
			Thread.sleep(10000);
			ErrorMessage = driver.findElement(errorMessage);
			System.out.println("Error Message: " + ErrorMessage.getText());
			actualerrorMessage = ErrorMessage.getText();
			test.pass(ErrorMessage + " is displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail(ErrorMessage + " is not displayed",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	/*
	 * This class is security question grid modal on click of help icon on security
	 * question Page.
	 */

	public class HelpModal {
		private By helpgrid = By.cssSelector("#main > div > div > div.grid");
		private By done = By
				.cssSelector("body > div.introjs-tooltipReferenceLayer > div > div.introjs-tooltipbuttons > button");

		public WebElement HelpGrid, DoneButton;

		public HelpModal() throws IOException {
			try {
				HelpGrid = driver.findElement(helpgrid);
				DoneButton = driver.findElement(done);
				test.pass("Help Modal is displayed",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("HelpModal Error in Security Question Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}

		}
	}
}