package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

import POM_Classes.CurrentAutoPay.CancelAutoPayModal;

public class ManagePaymentAccounts extends BaseClass {
	//private static final String ManageAutoPay = null;
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.xpath("//*[@id='main']/div[1]/h1[3]");
	public static String expectedWelcomeMessage = "Manage Payment Accounts";
	private By managepaymentaccounthelpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
	private By paymentAccountsTitle=By.cssSelector("#main > div.grid > div.col-65.basic-animation > article > div > header");
	public String expectedpaymentAccountsTitle="Payment Accounts";
	private By paymentsaccounthelpIcon = By.cssSelector("#main > div.grid > div.col-65.basic-animation > article > div > header > button > span.icon-info-circled");
	
	private By addPaymentAccount = By.cssSelector("#main > div.grid > div.col-65.basic-animation > article > div > div.module.module-condensed.clearfix > div > button");
	private By numberoftotalAccount = By.cssSelector("#main > div.grid > div.col-65.basic-animation > article > div > header > span");
	private By lookforSomething=By.xpath("//*[@id='main']/div[2]/div[2]");
	
	
	
	public WebElement WelcomeMessage,WelcomeHeader,ManagePaymentsAccountHelpIcon,PaymentsAccountsTitle,PaymentsAccountHelpIcon,AddPaymentAccount,LookforSomething;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public ManagePaymentAccounts() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			//wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			wait.until(ExpectedConditions.visibilityOfElementLocated(addPaymentAccount));
			WelcomeHeader = driver.findElement(welcomeHeader);			
			//WelcomeMessage = driver.findElement(welcomeMessage);
			ManagePaymentsAccountHelpIcon=driver.findElement(managepaymentaccounthelpIcon);
			PaymentsAccountsTitle=driver.findElement(paymentAccountsTitle);
			PaymentsAccountHelpIcon=driver.findElement(paymentsaccounthelpIcon);
			AddPaymentAccount=driver.findElement(addPaymentAccount);
			LookforSomething=driver.findElement(lookforSomething);
			test.pass("Add Payment accunt Screen1",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail("Add Payment Page Error ********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
	
	public String numberofAccounts() {
		String numberofAccounts = driver.findElement(numberoftotalAccount).getText().toString();
		numberofAccounts = numberofAccounts.replace(")", "").replace("(", "");
		System.out.println(numberofAccounts);
		return numberofAccounts;		
	}
	
	public void deleteAccount(int index) {
		WebElement trash = driver.findElement(By.xpath("//*[@id='main']/div[2]/div[1]/article/div/div[1]/div["+index+"]/div/div[2]/button/span[1]"));
		trash.click();
	}
	
	public String getNickNameForAccount(int index) {
		String nickName;
		try {
		nickName=driver.findElement(By.xpath("//*[@id='main']/div[2]/div[1]/article/div/div[1]/div["+index+"]/div/div[1]/button")).getText().trim();
		}
		catch(Exception e) {
		nickName=driver.findElement(By.xpath("//*[@id='main']/div[2]/div[1]/article/div/div[1]/div["+index+"]/div/div[1]/span")).getText().trim();
		}
		return nickName;
	}
	
	public int getIndexForNickName(String nickName) {
		int size = driver.findElements(By.xpath("//*[@id='main']/div[2]/div[1]/article/div/div[1]/div")).size();
		for(int i=1;i<=size;i++) {
			String returnnickName=getNickNameForAccount(i);
			System.out.println(returnnickName);
			if(nickName.equals(returnnickName)) {
				System.out.println(i);
				return i;
			}
		}
		return -1;
		
	}
	
	public class AddPaymentAccountType {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		public static final String expectedWelcomeMessage = "Add a Payment Account";
		private By addpaymenthelpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
		private By accountHelpIcon=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > div > div.md-and-up > h3 > button > span.icon-info-circled");
		
		private By accountTypeStep = By.xpath("//*[@id='step1']/span");
		private By accountInfoStep = By.xpath("//*[@id='step2']/span");
		private By reviewStep = By.xpath("//*[@id='step3']/span");
		private By confirmationStep = By.xpath("//*[@id='step4']/span");	
		private By step1=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > div > div.md-and-up > h3 > strong");
		//private By step1HelpIcon=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > div > div.md-and-up > h3 > button > span.icon-info-circled");
		public String expectedStep1Text = "Step 1 of 4: Select the account type";
		private By selectAccountType = By.cssSelector("#paymentAccountType");
		private By cancel=By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-left-xs > div > button");
		private By next=By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(5) > button");
		
		
		
		
		public WebElement WelcomeMessage, WelcomeHeader,AddPaymentHelpIcon,AccountHelpIcon,
		AccountTypeStep,AccountInfoStep,ReviewStep,ConfirmationStep,Step1,SelectAccountType,Cancel,Next;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public AddPaymentAccountType() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				AddPaymentHelpIcon=driver.findElement(addpaymenthelpIcon);
				AccountHelpIcon=driver.findElement(accountHelpIcon);
				AccountTypeStep=driver.findElement(accountTypeStep);
				AccountInfoStep=driver.findElement(accountInfoStep);
				ReviewStep=driver.findElement(reviewStep);
				ConfirmationStep=driver.findElement(confirmationStep);
				Step1=driver.findElement(step1);
				SelectAccountType=driver.findElement(selectAccountType);
				Cancel=driver.findElement(cancel);
				Next = driver.findElement(next);				
				test.pass("Navigated to  Add Payment Step 1 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Navigated to  Add Payment Step 1 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	public class AddPaymentAccountInfo {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		public static final String expectedWelcomeMessage = "Add a Payment Account";
		private By addpaymenthelpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
		private By accountinfoHelpIcon = By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid-pattern.ng-invalid.ng-invalid-required.ng-valid-match > div > h3 > button > span.icon-info-circled");
		
		private By cancel = By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-left-xs > div > button");
		private By back=By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(4) > button");
		private By next= By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(5) > button");
		
		private By step2=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid-pattern.ng-invalid.ng-invalid-required.ng-valid-match > div > h3 > strong");
		public static final String expectedStep2Text = "Step 2 of 4: Provide the account information";
		
		private By routingNumberLabel=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid-pattern.ng-invalid.ng-invalid-required.ng-valid-match > div > div > div.col-50.form-stacked > div:nth-child(1) > label");
		private By routingNumber=By.cssSelector("#routingNumber");
		public String expectedRoutingNumberText="Routing Number";
		public String expectedinlineTextforRouting="Routing Number";
		private By accountNumberLabel=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid-pattern.ng-invalid.ng-invalid-required.ng-valid-match > div > div > div.col-50.form-stacked > div:nth-child(2) > label");
		private By accountNumber=By.cssSelector("#paymentAccountNumber");
		public String expectedAccountNumberText="Account Number";
		public String expectedinlineTextforAccountNumber="Enter you bank account number";
		private By reenterAccountNumberlabel=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid-pattern.ng-invalid.ng-invalid-required.ng-valid-match > div > div > div.col-50.form-stacked > div:nth-child(3) > label");
		private By reenterAccountNumber = By.cssSelector("#validPaymentAccountNumber");		
		public String expectedconfirmAccountNumebrText="Re-enter Account Number";
		public String expectedinlineTextforreenterAccountNumber="Re-enter your bank account number";
		private By accountNickNameLabel=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid-pattern.ng-invalid.ng-invalid-required.ng-valid-match > div > div > div.col-50.form-stacked > div:nth-child(4) > label");
		private By accountNickName=By.cssSelector("#paymentAccountNickName");
		public String expectedAccountNickNameText="Account Nickname";
		public String expectedinlineTextforNickName="Nickname (ex: Main Checking)";
		private By cardImage = By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid-pattern.ng-invalid.ng-invalid-required.ng-valid-match > div > div > div:nth-child(2) > img");
	
				
		public WebElement WelcomeMessage,  Next, WelcomeHeader,Back,PaymentHelpIcon,PaymentAccountInfoHelpIcon,Cancel,
		Step2,RoutingNumber,RoutingNumberLabel,AccountNumberLabel,AccountNumber,ReenterAccountNumber,ReenterAccountNumberLabel,
		AccountNickNameLabel,AccountNickName,CardImage;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public AddPaymentAccountInfo() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				Back = driver.findElement(back);				
				Step2=driver.findElement(step2);
				Next = driver.findElement(next);
				Cancel = driver.findElement(cancel);
				PaymentHelpIcon=driver.findElement(addpaymenthelpIcon);
				PaymentAccountInfoHelpIcon=driver.findElement(paymentsaccounthelpIcon);
				RoutingNumber=driver.findElement(routingNumber);
				RoutingNumberLabel=driver.findElement(routingNumberLabel);
				AccountNumberLabel=driver.findElement(accountNumberLabel);
				AccountNumber=driver.findElement(accountNumber);
				ReenterAccountNumber=driver.findElement(reenterAccountNumber);
				ReenterAccountNumberLabel=driver.findElement(reenterAccountNumberlabel);
				AccountNickName=driver.findElement(accountNickName);
				AccountNickNameLabel=driver.findElement(accountNickNameLabel);
				CardImage=driver.findElement(cardImage);
				test.pass("Navigated to add Payment account Step 2 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Navigated to add Payment account step 2 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
		
		public String getErrorMessage(String fieldName) {
			String errorMessage = null;
			if(fieldName.equals("RoutingNumber")) {
				errorMessage = driver.findElement(By.xpath("//*[@id='paymentAccountEdit']/article/div/div[2]/div/div[2]/div[1]/div[1]/div/div[2]")).getText();
			//return errorMessage;
			}
			else if(fieldName.equals("Re-EnterAccountNumber")) {
				errorMessage = driver.findElement(By.xpath("//*[@id='paymentAccountEdit']/article/div/div[2]/div/div[2]/div[1]/div[3]/div/div[2]")).getText();
				//return errorMessage;
			}
			else if(fieldName.equals("AccountNickName")) {
				errorMessage = driver.findElement(By.xpath("//*[@id='paymentAccountEdit']/article/div/div[2]/div/div[2]/div[1]/div[4]/div/div[2]")).getText();
				//return errorMessage;
			}
			return errorMessage;		
	}
	}
	public class ManagePaymentAccountReview {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		public static final String expectedWelcomeMessage = "Add a Payment Account";
		private By paymenthelpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
		private By paymentreviewHelpIcon = By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		
		private By cancel = By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-left-xs > div > button");
		private By back=By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(4) > button");
		private By addPaymentAccount= By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(6) > button:nth-child(1)");
		private By step3=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public String expectedstep3Text="Step 3 of 4: Verify your information";
		
		private By accounType=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(3)");
		private By financialInstitution = By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(4)");
		private By accountNumber=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(5)");
		private By routingNumber=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(6)");
		private By accountNickName=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(7)");
		private By errorMessage=By.xpath("//*[@id='app']/body/div[1]/div[2]/div[1]/div/div/div");
		public String expectederrorMessageForDuplicateNickName="Payment account could not save because of a duplicate nickname.";
		private By closeIconforErrorMessage = By.cssSelector("body > div.main-container.shell-wrapper > div.page-wrapper > div:nth-child(1) > div > span > span > span.icon-cancel-circled");
		
		public WebElement WelcomeMessage,WelcomeHeader,PaymenthelpIcon,PaymentReviewhelpIcon,
		Cancel,Back,AddPaymentAccount,Step3,AccountType,FinancialInstitution,AccountNumber,RoutingNumber,AccountNickName;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public ManagePaymentAccountReview() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				PaymenthelpIcon=driver.findElement(paymenthelpIcon);
				PaymentReviewhelpIcon=driver.findElement(paymentreviewHelpIcon);
				Cancel=driver.findElement(cancel);
				Back=driver.findElement(back);
				AddPaymentAccount=driver.findElement(addPaymentAccount);
				Step3=driver.findElement(step3);
				AccountType=driver.findElement(accounType);
				FinancialInstitution=driver.findElement(financialInstitution);
				AccountNumber=driver.findElement(accountNumber);
				RoutingNumber=driver.findElement(routingNumber);
				AccountNickName=driver.findElement(accountNickName);
				test.pass("Navigated to  add Payment account Step 3 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" add Payment account Step 3 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
		public String getErrorMessage() {
			String error = driver.findElement(errorMessage).getText().trim();
			//driver.findElement(closeIconforErrorMessage).click();
			return error;
		}
		
		public WebElement getCloseIconOnErrorMessage() {
			return driver.findElement(closeIconforErrorMessage);
			
		}
	}
	
	public class ManagePaymentAccountConfirmation {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		public static final String expectedWelcomeMessage = "Add a Payment Account";
		private By paymenthelpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
		private By paymentconfirmationHelpIcon = By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		
		private By close = By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(1) > button");
		private By makeontimepayment=By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(2) > a");
		private By manageautopay= By.cssSelector("#paymentAccountEdit > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(3) > a");
		private By step4=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public String expectedstep4Text="Step 4 of 4: Your Account Has Been Added";
		
		private By accounType=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(3)");
		private By financialInstitution = By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(4)");
		private By accountNumber=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(5)");
		private By routingNumber=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(6)");
		private By accountNickName=By.cssSelector("#paymentAccountEdit > article > div > div.clearfix.basic-animation > div > p:nth-child(7)");
		
		public WebElement WelcomeMessage,WelcomeHeader,PaymenthelpIcon,PaymentReviewhelpIcon,
		Close,MakeOneTimePayment,ManageAutoPay,Step4,AccountType,FinancialInstitution,AccountNumber,RoutingNumber,AccountNickName;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public ManagePaymentAccountConfirmation() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				PaymenthelpIcon=driver.findElement(paymenthelpIcon);
				PaymentReviewhelpIcon=driver.findElement(paymentconfirmationHelpIcon);
				MakeOneTimePayment=driver.findElement(makeontimepayment);
				Close=driver.findElement(close);
				ManageAutoPay=driver.findElement(manageautopay);
				Step4=driver.findElement(step4);
				AccountType=driver.findElement(accounType);
				FinancialInstitution=driver.findElement(financialInstitution);
				AccountNumber=driver.findElement(accountNumber);
				RoutingNumber=driver.findElement(routingNumber);
				AccountNickName=driver.findElement(accountNickName);
				test.pass("Navigated to add Payment account Step 4Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("  add Payment account Page 4Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}	
}