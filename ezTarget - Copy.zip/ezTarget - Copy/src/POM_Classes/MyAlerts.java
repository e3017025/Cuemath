package POM_Classes;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class MyAlerts extends BaseClass{
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");
	private By addNewAlert = By.id("addNewAlert");
	private By viewCardDropdown = By.id("alertAccounts");
	private By alertsettingsBanner = By
			.cssSelector("#main > div.col-65 > section > div:nth-child(2) > section > div > ul");
	private By alertsettings = By
			.cssSelector("#main > div.col-65 > section > div:nth-child(2) > section > div > ul > li:nth-child(1) > a");
	private By alertHistory = By.xpath(
			"//*[@id='main']/div[2]/section/div[2]/section/div/ul/li[2]/a");
	private By toggleOn = By.cssSelector(
			"#alert-settings > ul:nth-child(2) > li:nth-child(1) > div.col-c-70 > span.toggle.toggle-modern > span > div > div > div.toggle-off");
	private By toggleOff = By.cssSelector(
			"#alert-settings > ul:nth-child(2) > li:nth-child(1) > div.col-c-70 > span.toggle.toggle-modern > span > div > div > div.toggle-on.active");
	private By listofAlerts = By.cssSelector("//*[@id='alert-settings']/ul[1]/li");
	private By alertType = By.xpath("//*[@id='toggle-']");
	private By editAlert = By.xpath("//*[@id='alert-settings']/ul[1]/li/div[3]/button");
	private By lookingforSomethingBlock=By.cssSelector("#main > div.col-35 > div");
	private By helpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
	private By faqs=By.xpath("//*[@id='main']/div[3]/div/a[1]");
	private By settingandhelp=By.xpath("//*[@id='main']/div[3]/div/a[2]");

	public WebElement WelcomeMessage, WelcomeHeader, AddNewAlert, ViewCardDropDown, AlertSettingsBanner, AlertSettings,
			AlertHistory, ToggleOn, ToggleOff, ListofAlerts, EditAlert,LookingForSomething,HelpIcon,FAQs,SettingsAndHelpLink;
	

	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public MyAlerts() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			wait.until(ExpectedConditions.visibilityOfElementLocated(addNewAlert));
			wait.until(ExpectedConditions.visibilityOfElementLocated(viewCardDropdown));
			WelcomeHeader = driver.findElement(welcomeHeader);
			WelcomeMessage = driver.findElement(welcomeMessage);
			AddNewAlert = driver.findElement(addNewAlert);
			ViewCardDropDown = driver.findElement(viewCardDropdown);
			AlertSettingsBanner = driver.findElement(alertsettingsBanner);
			AlertSettings = driver.findElement(alertsettings);
			AlertHistory = driver.findElement(alertHistory);
			LookingForSomething =driver.findElement(lookingforSomethingBlock);
			HelpIcon=driver.findElement(helpIcon);	
			FAQs=driver.findElement(faqs);
			SettingsAndHelpLink=driver.findElement(settingandhelp);
			// ToggleOff=driver.findElement(toggleOff);
			// ToggleOn=driver.findElement(toggleOn);
			// ListofAlerts=driver.findElement(listofAlerts);
			// EditAlert=driver.findElement(editAlert);
			test.pass("Navigated to My Alerts Page",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());

		} catch (Exception e) {
			test.fail("My Alerts Page Error **********"+ExceptionUtils.getStackTrace(e), MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	public void clickEditAlert() throws InterruptedException {
		// Edit Alert click is NOT working so directly using this.
		driver.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li/div[3]/button")).click();
		Thread.sleep(2000);
	}

	public void ClickToggleOff(int i) throws InterruptedException {
		// Edit Alert click is NOT working so directly using this.

		ToggleOff = driver.findElement(
				By.xpath("//*[@id='alert-settings']/ul[1]/li[" + i + "]/div[1]/span[1]/span/div/div/div[2]"));
		ToggleOff.click();
	}

	public void ClickToggleOn(int i) throws InterruptedException {
		// Edit Alert click is NOT working so directly using this.
		ToggleOn = driver.findElement(
				By.xpath("//*[@id='alert-settings']/ul[1]/li[" + i + "]/div[1]/span[1]/span/div/div/div[2]"));
		ToggleOn.click();
	}

	public List<String> returnIcon(int i) throws InterruptedException {
		List<String> listofIcons = new ArrayList();
		int numberofelements = driver.findElements(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + i + "]/div[1]/span[3]/span/span")).size();				
		for(int j=1;j<=numberofelements;j++)
		{
			String icon = driver
					.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + i + "]/div[1]/span[3]/span/span["+j+"]/span[1]"))
					.getAttribute("class");			 
			System.out.println("icon: " + icon);
			listofIcons.add(icon);			
		}
		System.out.println(listofIcons);
		return listofIcons;
	}

	public int numberofAlerts() {
		int numberofAlerts = driver.findElements(By.xpath("//*[@id='alert-settings']/ul[1]/li")).size();
		return numberofAlerts;
	}

	public boolean checkalertIsActive(String text) {
		int numberofAlerts = driver.findElements(By.xpath("//*[@id='alert-settings']/ul[1]/li")).size();
		boolean flag = false;
		for (int i = 0; i < numberofAlerts; i++) {
			WebElement alertText = driver
					.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + (i + 1) + "]/div[1]/span[2]"));
			System.out.println(alertText.getText().toString());
			if (alertText.getText().toString().equalsIgnoreCase(text)) {
				String alertActive = driver
						.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + (i + 1) + "]/div[1]/span[1]"))
						.getAttribute("aria-checked");
				if (alertActive.equals("true")) {
					flag = true;
					System.out.println(text + "alert is " + flag);
					return flag;
				}
				if (alertActive.equals("false")) {
					flag = false;
					System.out.println(text + "alert is " + flag);
					return flag;
				}
			}
		}
		return flag;
	}

	public int returnalertindex(String text) {
		int numberofAlerts = driver.findElements(By.xpath("//*[@id='alert-settings']/ul[1]/li")).size();
		int flag = -1;
		for (int i = 0; i < numberofAlerts; i++) {
			WebElement alertText = driver
					.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + (i + 1) + "]/div[1]/span[2]"));
			System.out.println(alertText.getText().toString());
			if (alertText.getText().toString().equalsIgnoreCase(text)) {
				String alertActive = driver
						.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + (i + 1) + "]/div[1]/span[1]"))
						.getAttribute("aria-checked");
				flag = i + 1;
				System.out.println(text + "alert is " + flag);
				return flag;
			}
		}
		return flag;
	}
	
	public String returnCardName(int i) {
		String cardName = driver.findElement(
				By.xpath("//*[@id='alert-settings']/ul[1]/li[" + i + "]/div[2]/span")).getText();
		return cardName;
	}

	public String returnChannelName(int i) {
		
		//*[@id='alert-settings']/ul[1]/li/div[2]/span
		String cardName = driver.findElement(
				By.xpath("//*[@id='alert-settings']/ul[1]/li[" + i + "]/div[1]/span[3]/span/span/span[1]")).getAttribute("title");
		return cardName;
	}

	public void EditAlertWhichIsJustCreated(String text) {
		int numberofAlerts = driver.findElements(By.xpath("//*[@id='alert-settings']/ul[1]/li")).size();
		boolean flag = false;
		for (int i = 0; i < numberofAlerts; i++) {
			WebElement alertText = driver
					.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + (i + 1) + "]/div[1]/span[2]"));
			System.out.println(alertText.getText().toString());
			if (alertText.getText().toString().equalsIgnoreCase(text)) {
				String alertActive = driver
						.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + (i + 1) + "]/div[1]/span[1]"))
						.getAttribute("aria-checked");
				if (alertActive.equals("true")) {
					flag = true;
					System.out.println(text + "alert is " + flag);
					driver.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[" + (i + 1) + "]/div[3]/button"))
							.click();					
				}
			}
		}
	}
	
	public void verifyAlertHistoryTab() throws IOException {
	boolean alerthistorygrid = driver.findElement(By.id("alert-history")).isDisplayed();
	AssertVerify(alerthistorygrid, true);
	List<WebElement> numberofElements = driver.findElements(By.xpath("//*[@id='alert-history']/ul/li"));
		for(int i=0;i<numberofElements.size();i++) {
			int sizeofdivs = driver.findElements(By.xpath("//*[@id='alert-history']/ul/li["+(i+1)+"]/div")).size();
			System.out.println("sizeofdiv: "+sizeofdivs);
			AssertVerify(sizeofdivs>0,true);
			int sizeofspan = driver.findElements(By.xpath("//*[@id='alert-history']/ul/li["+(i+1)+"]/div[1]/span")).size();
			System.out.println("sizeofspan: "+sizeofspan);
			AssertVerify(sizeofspan>0,true);
		}	
	}
	
	public void clearAllAlerts() throws IOException, InterruptedException {	
	List<WebElement> numberofElements = driver.findElements(By.xpath("//*[@id='alert-settings']/ul[1]/li"));
	if(numberofElements.size()>0) {
		for(int i=1;i<=numberofElements.size();i++) {
			MyAlerts myAlerts = new MyAlerts();
			WebElement element = driver.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li[1]/div[3]/button"));
			element.click();
			Thread.sleep(2000);
			EditExistingAlert edit = new EditExistingAlert();
			edit.DeleteAlert.click();
			Thread.sleep(5000);			
		}	
		}
	}

	public class AddNewAlert {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By addNewAlertSideRight = By
				.cssSelector("body > div.aside.right.am-slide-right > div.aside-dialog > div");
		private By alertMeWhen = By.id("alertType");
		private By condition = By.id("condition");
		private By sendAlertVia = By
				.xpath("id('alertForm')/div[@class='field']/fieldset[1]/div[@class='checkboxes']/button[1]");
		private By sendAlertFor = By
				.xpath("//*[@id='alertForm']/div[@data-ct-help='Sendalertfor']/fieldset/div/div/button");
		private By manageemailaddresses = By
				.xpath("id('alertForm')/div[@class='field']/fieldset[1]/div[@class='text-right']/a");

		private By saveAlert = By.xpath("//*[@data-ct-help='SaveAlert']");
		private By cancelAlert = By.xpath("//*[@data-ct-help='Cancel']");

		public WebElement CloseIcon, AddNewAlertSideRight, AlertMeWhen, Condition, SendAlertVia, SendAlertFor,
				ManageEmailAddresses, SaveAlert, CancelAlert;

		public AddNewAlert() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(addNewAlertSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(alertMeWhen));
				CloseIcon = driver.findElement(closeIcon);
				AddNewAlertSideRight = driver.findElement(addNewAlertSideRight);
				AlertMeWhen = driver.findElement(alertMeWhen);
				SendAlertVia = driver.findElement(sendAlertVia);
				SendAlertFor = driver.findElement(sendAlertFor);
				ManageEmailAddresses = driver.findElement(manageemailaddresses);
				SaveAlert = driver.findElement(saveAlert);
				CancelAlert = driver.findElement(cancelAlert);
				test.pass("Navigated to Add New Alert Side Bar",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Add New Alert Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}

		public void createNewAlert(String alertMeWhen, String Condition) throws InterruptedException, IOException {
			//AddNewAlert addnewalert = new AddNewAlert();
			Thread.sleep(1000);
			AlertMeWhen.click();
			selectDropDownByVisibleText(AlertMeWhen, alertMeWhen);			
			try {
				driver.findElement(condition).clear();;
				driver.findElement(condition).sendKeys(Condition);
			} catch (Exception e) {
				System.out.println("No Condition is displayed for this Alert Type");
			}
			if(!SendAlertVia.getAttribute("aria-checked").equals("true")) {
			SendAlertVia.click();
			}
			if(!SendAlertFor.getAttribute("aria-checked").equals("true")) {
			SendAlertFor.click();
			}
			if(!SaveAlert.isEnabled()) {
				test.fail("Could not able to create alert",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
			SaveAlert.click();
			Thread.sleep(10000);			
		}
		
		public void createNewAlertForAllCardsAndAllChannels(String alertMeWhen, String Condition) throws InterruptedException, IOException {
			//AddNewAlert addnewalert = new AddNewAlert();
			AlertMeWhen.click();
			selectDropDownByVisibleText(AlertMeWhen, alertMeWhen);			
			try {
				driver.findElement(condition).clear();;
				driver.findElement(condition).sendKeys(Condition);
			} catch (Exception e) {
				System.out.println("No Condition is displayed for this Alert Type");
			}
			SendAlertVia.click();
			driver.findElement(By.xpath("id('alertForm')/div[@class='field']/fieldset[1]/div[@class='checkboxes']/button[2]")).click();
			SendAlertFor.click();
			driver.findElement(By.xpath("//*[@id='alertForm']/div[@data-ct-help='Sendalertfor']/fieldset/div/div/button[2]")).click();
			SaveAlert.click();
			Thread.sleep(10000);
		}
	}

	
	
	public class EditExistingAlert {

		private By closeIcon = By.cssSelector(
				"body > div.aside.right.am-slide-right > div.aside-dialog > div > div.aside-header > button > span:nth-child(1)");
		private By addNewAlertSideRight = By
				.cssSelector("body > div.aside.right.am-slide-right > div.aside-dialog > div");
		private By alertMeWhen = By.id("alertType");
		public By condition = By.id("condition");
		private By sendAlertVia = By
				.xpath("id('alertForm')/div[@class='field']/fieldset[1]/div[@class='checkboxes']/button[1]");
		private By manageemailaddresses = By
				.xpath("id('alertForm')/div[@class='field']/fieldset[1]/div[@class='text-right']/a");

		private By saveAlert = By.xpath("//*[@data-ct-help='SaveAlert']");
		private By cancelAlert = By.xpath("//*[@data-ct-help='Cancel']");
		private By deleteAlert = By.xpath("//*[@data-ct-help='Delete']");
		public WebElement CloseIcon, AddNewAlertSideRight, AlertMeWhen, Condition, SendAlertVia, SendAlertFor,
				ManageEmailAddresses, SaveAlert, CancelAlert, DeleteAlert;

		public EditExistingAlert() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(addNewAlertSideRight));
				wait.until(ExpectedConditions.visibilityOfElementLocated(alertMeWhen));
				CloseIcon = driver.findElement(closeIcon);
				AddNewAlertSideRight = driver.findElement(addNewAlertSideRight);
				AlertMeWhen = driver.findElement(alertMeWhen);
				SendAlertVia = driver.findElement(sendAlertVia);
				ManageEmailAddresses = driver.findElement(manageemailaddresses);
				SaveAlert = driver.findElement(saveAlert);
				CancelAlert = driver.findElement(cancelAlert);
				DeleteAlert = driver.findElement(deleteAlert);
				test.pass("Navigated to Edit Alert Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("Edit Alert Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}

		}

	}
	
	public class DuplicateAlertModal{
		// Duplicate Alert
		private By modalTitle = By.xpath("//*[@id='dialogTitle' and @class='modal-title']");
		private By modalDescription = By.cssSelector("#dialogDesc");
		private By ok = By
				.cssSelector("body > div.modal.no-print.top.am-fade > form > div > div > div.modal-footer > button");
		private By closeIconforduplicateModal = By.cssSelector(
				"body > div.modal.no-print.top.am-fade > form > div > div > div.modal-header > button > span:nth-child(1)");
		
		public String ExpectedModalTitle = "Duplicate Alert"; 
		public String ExpectedModalDescription = "An alert with the same parameters already exists.";
		
		public WebElement ModalTitle, ModalDescription, OK, CloseIcon;
		
		public DuplicateAlertModal() throws IOException {
			try {
			ModalTitle = driver.findElement(modalTitle);
			ModalDescription = driver.findElement(modalDescription);
			OK = driver.findElement(ok);
			CloseIcon=driver.findElement(closeIconforduplicateModal);
			}
			catch(Exception e) {
				test.fail("Duplicate Alert Page Error",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	public class HelpModal {
		
		private By helpgrid = By.xpath("//section[@class='module module-dark introjs-showElement introjs-relativePosition']");
		private By done=By.xpath("//*[@id='app']/body/div[5]/div/div[5]/button");
		private By helpText = By.xpath("id('app')/body[1]/div[@class='introjs-tooltipReferenceLayer']/div[@class='introjs-tooltip']/div[@class='introjs-tooltiptext']");
		public final By modalNumber = By.xpath("//*[@id='app']/body/div[5]/span"); 
		
		public String expectedHelpText="Create and manage alerts to notify you when selected events or transactions occur."; 
		public WebElement HelpGrid, DoneButton,HelpText,ModalNumber;

		public HelpModal() throws IOException {
			try {
				HelpGrid = driver.findElement(helpgrid);
				DoneButton = driver.findElement(done);
				HelpText=driver.findElement(helpText);
				ModalNumber= driver.findElement(modalNumber);
				test.pass("Help Modal is displayed",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
				
			} catch (Exception e) {
				test.fail("HelpModal Error in Security Question Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}

		}
	}
	
	public boolean ListOfAlertTypes() throws IOException {	
		boolean flag= false;		
		List<WebElement> allelement = driver.findElements(By.xpath("//*[@id='alertType']/option"));
		for(int i=0;i<allelement.size();i++) {
		    String option = driver.findElement(By.xpath("//*[@id='alertType']/option["+(i+1)+"]")).getText();
		    System.out.println(option);
		    System.out.println(expectedalertTypes.get(i).toString());
		    if(!option.equalsIgnoreCase(expectedalertTypes.get(i).toString()))
		    {
		    	return false;
		    }
		}
		return true;
	}
	
	public boolean VerifyCardDetailsOnDropDown(String CardName) throws IOException {	
		boolean flag= false;		
		List<WebElement> allelement = driver.findElements(By.xpath("//*[@id='alert-settings']/ul[1]/li"));
		for(int i=1;i<=allelement.size();i++) {
		    String option = driver.findElement(By.xpath("//*[@id='alert-settings']/ul[1]/li["+i+"]/div[2]/span")).getText().toString().trim();
		    System.out.println("Card Name: "+option);		    
		    if(option.equalsIgnoreCase(CardName))
		    {
		    	flag = true;
		    	return flag;
		    }
		}
		return flag;
	}
}