package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

public class HomePage extends BaseClass {
	// Locators for Login Page
	private By welcomeHeader = By
			.cssSelector("body > div.main-container.shell-wrapper > div.page-wrapper > header > div > div > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");
	public By scorecardImage1= By.xpath("id('main')/div[1]/article[1]/div[@class='module text-center module-clear']/a[1]");
	public By scorecardImage2=By.xpath("id('main')/div[2]/div[@class='grid']/article[@class='col-50']/div[@class='module text-center module-clear']/div[@class='carousel']/div[@class='carousel-inner']/div[@class='item active']/div[@class='text-center']/a[1]");
	private By home = By.cssSelector("#n_step1 > a");
	private By transactions = By.xpath("//*[@id='n_step2']/a");
	private By transactionBlock = By.xpath("id('n_step2')");
	public static By searchTransaction = By.xpath("//*[@id='n_step2']/div/ul/li[1]");
	public static By spendAnalyzer = By.xpath("//*[@id='n_step2']/div/ul/li[2]");
	private By statements = By.cssSelector("#n_step3 > button");
	private static By statementSummaries=By.xpath("//*[@id='n_step3']/div/ul/li[1]/a");
	private By payments = By.xpath("id('n_step4')");
	public By paymentsSummary=By.xpath("//*[@id='n_step4']/div/ul/li[1]/a");
	public By makeOneTimePayment=By.xpath("//*[@id='n_step4']/div/ul/li[2]/a");
	public By managePaymentAccounts=By.xpath("//*[@id='n_step4']/div/ul/li[3]/a");
	public By manageautopay=By.xpath("//*[@id='n_step4']/div/ul/li[4]/a");	
	private By myalerts = By.cssSelector("#n_step5 > a");
	private By settingsandhelp = By.cssSelector("#n_step6 > a");
	private By logout = By.xpath("//button[@type='button' and @class='btn btn-link btn-sm text-uppercase text-right']");
	private By paynow = By.id("PayBillButton");
	private By fullTransactionHistory = By.id("GoToTransactionsHistory");
	private By lastStatementBalance = By.xpath("//*[@id='StatementBalance']/span");
	private By lastPayment =By.xpath("//*[@id='LastPayment']/span[2]");
	private By errorMessage = By.xpath("//div[@data-ct-helpselect='headerError']");
	public String expectedsessionExpiredMessage = "Your session has expired or you were not authorized to use this functionality. Please log in to continue";
	private By currentBalance =By.xpath("//*[@id='CurrentBalance']/span[2]");
	private By minimumPayment =By.xpath("//*[@id='MinimumPayment']/span");
	private By paymentDueDate = By.xpath("//*[@id='Due']/span/span");
	private By recentTransactionsTab = By.xpath("//*[@id='RecentTransactionsTab']/a");
	private By spendSnapshotTab = By.xpath("//*[@id='SpendSnapshotTab']/a");
	private By recentTransactionsLabel = By.xpath("//*[@id='tabPanel0']/div/div/header/h2");
	private By searchInputBox=By.xpath("//*[@id='tabPanel0']/div/div/header/div/div/form/input");
	private By searchButton = By.xpath("//*[@id='tabPanel0']/div/div/header/div/div/form/span/button[2]");
	private By transactionLabel = By.xpath("//*[@id='transactionLabel']");
	public By messageIcon = By.xpath("//*[@id='main']/div[2]/div[1]/article/div/a/span[1]");
	public By numberofMessages =By.xpath("//*[@id='main']/div[2]/div[1]/article/div/a/span[2]");
	private By lastLoginDate=By.xpath("//*[@id='LastLogin']/span");
	private By accountIdentificationNumber = By.xpath("//*[@id='PastDueAmount']/span");
	private By statementDeliveryMethod=By.xpath("//*[@id='PaperSuppressionEnrolled']/span");
	private By autoPay=By.xpath("//*[@id='RecurringPaymentEnrolled']/span");
	private By totalCreditLimit = By.xpath("//*[@id='CreditLimit']/span");
	
	
	public WebElement Home, Transactions,TransactionsLink, Statements, Payments, MyAlerts, SettingsNHelp, WelcomeHeader, WelcomeMessage,Logout,FullTransactionHistory,PayNow,LastStatementBalance,LastPayment,MinimumAmountDue,CurrentBalance,PaymentDue,
	RecentTransactionsTab,SpendSnapShotTab,RecentTransactionLabel,SearchInputBox,SearchButton,TransactionLabel,
	LastLoginDate,AccountIdentificationNumber,StatementDeliveryMethod,AutoPay,TotalCreditLimit;
	
	public static WebElement ErrorMessage;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public HomePage() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			WelcomeHeader = driver.findElement(welcomeHeader);
			WelcomeMessage=driver.findElement(welcomeMessage);
			Home = driver.findElement(home);
			//Transactions = driver.findElement(transactions);
			TransactionsLink = driver.findElement(transactionBlock);			
			MyAlerts = driver.findElement(myalerts);
			SettingsNHelp = driver.findElement(settingsandhelp);
			Logout = driver.findElement(logout);
			StatementDeliveryMethod=driver.findElement(statementDeliveryMethod);
			LastLoginDate=driver.findElement(lastLoginDate);
			AccountIdentificationNumber=driver.findElement(accountIdentificationNumber);
			test.pass("Navigated to HomePage", MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			try {
				Statements = driver.findElement(statements);
				Payments = driver.findElement(payments);
				PayNow = driver.findElement(paynow);
				LastStatementBalance = driver.findElement(lastStatementBalance);
				LastPayment=driver.findElement(lastPayment);
				MinimumAmountDue=driver.findElement(minimumPayment);
				PaymentDue=driver.findElement(paymentDueDate);
				CurrentBalance = driver.findElement(currentBalance);
				RecentTransactionsTab=driver.findElement(recentTransactionsTab);
				SpendSnapShotTab =driver.findElement(spendSnapshotTab); 
				RecentTransactionLabel = driver.findElement(recentTransactionsLabel);
				SearchInputBox = driver.findElement(searchInputBox);
				SearchButton = driver.findElement(searchButton);
				TransactionLabel=driver.findElement(transactionLabel);				
				AutoPay=driver.findElement(autoPay);
				TotalCreditLimit=driver.findElement(totalCreditLimit);
			}
			catch(Exception e) {
				System.out.println("Debit Card does not have the Payment Options");
			}
		} catch (Exception e) {
			test.fail("HomePage Error *************" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}

	public void Click(WebElement element) throws InterruptedException {
		element.click();
		Thread.sleep(5000);
	}

	public String ErrorMessage() {
		ErrorMessage=driver.findElement(errorMessage);				
		return ErrorMessage.getText().toString();		
	}
	
	public int numberofAccount() {
			int numberofAccounts = driver.findElements(By.xpath("//*[@id='main']/div[2]/div[1]/article/div/div/div/div/div[1]/button")).size();
			return numberofAccounts;
	}
	
	public void clickSearchTransaction() throws InterruptedException {
		WebElement searchTransactionElement = driver.findElement(HomePage.searchTransaction);
		Actions action = new Actions(driver);
		action.moveToElement(searchTransactionElement);
		action.click().build().perform();
		Thread.sleep(15000);
		boolean flag = false;
		while (flag != true) {
			try {
				driver.findElement(POM_Classes.Transactions.savedsearchExpanderButton);
				flag = true;
			} catch (NoSuchElementException e) {
				action.moveToElement(searchTransactionElement);
				action.click().build().perform();
				Thread.sleep(15000);
			}
		}
	}

	public void clickSpendAnalyzer() throws InterruptedException {
		// TODO Auto-generated method stub
		WebElement spendAnalyzerElement = driver.findElement(HomePage.spendAnalyzer);
		Actions action = new Actions(driver);
		action.moveToElement(spendAnalyzerElement);
		action.click().build().perform();
		Thread.sleep(15000);
		/*boolean flag = false;
		while (flag != true) {
			try {
				driver.findElement(POM_Classes.SpendAnalyzer.savedsearchExpanderButton);
				flag = true;
			} catch (NoSuchElementException e) {
				action.moveToElement(spendAnalyzerElement);
				action.click().build().perform();
				Thread.sleep(15000);
			}
		}*/
	}
	
	
	public void clickStatementSummaries() throws InterruptedException {
		// TODO Auto-generated method stub
		WebElement statmentsummariesElement = driver.findElement(HomePage.statementSummaries);
		Actions action = new Actions(driver);
		action.moveToElement(statmentsummariesElement);
		action.click().build().perform();
		Thread.sleep(15000);
	}
}