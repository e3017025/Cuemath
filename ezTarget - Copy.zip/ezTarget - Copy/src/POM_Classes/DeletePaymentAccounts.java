package POM_Classes;

import java.io.IOException;

import org.apache.commons.lang3.exception.ExceptionUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.aventstack.extentreports.MediaEntityBuilder;

import POM_Classes.CurrentAutoPay.CancelAutoPayModal;

public class DeletePaymentAccounts extends BaseClass {
	//private static final String ManageAutoPay = null;
	// Locators for Login Page
	private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
	private By welcomeMessage = By.cssSelector("#mainHeading");
	public static String expectedWelcomeMessage = "Delete Payment Account";
	private By managepaymentaccounthelpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
	private By step1=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid > div > h3 > strong");
	private By step1helpIcon = By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid > div > h3 > button > span.icon-info-circled");
	public String expectedStep1Text="Step 1 of 3: Verify pending payments";
	private By prexTextforAutoPay=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid > div > div.col-100.clearfix.text-small");
	public String expectedPreTextForAutoPay="You cannot delete this payment account because you have assigned it as the payment account for Auto Pay. If you wish to delete this payment account, select �Manage Auto Pay� to cancel your current Auto Pay Plan.";
	
	//AutoPay Alone
	public By currentAutoPay=By.xpath("//*[@id='paymentAccountDelete']/article/div/div[2]/div/div[2]");
	public By planType=By.xpath("//*[@id='paymentAccountDelete']/article/div/div[2]/div/div[2]/div");
	
	//AutoPay Alone
	//public By currentAutoPay=By.xpath("//*[@id='paymentAccountDelete']/article/div/div[2]/div/div[3]");
	//public By planType=By.xpath("//*[@id='paymentAccountDelete']/article/div/div[2]/div/div[3]/div");
	
	private By pendingStep=By.xpath("//*[@id='deleteStep1']/span");
	private By reviewStep=By.xpath("//*[@id='deleteStep2']/span");
	private By confirmationStep=By.xpath("//*[@id='deleteStep3']/span");
	
	private By preTextforNotassociatedwithanyPayment=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation.ng-pristine.ng-valid > div > div");
	private By cancel=By.cssSelector("#paymentAccountDelete > article > div > div.actions.clearfix > div.pull-left-xs > div > button");
	public By next=By.cssSelector("#paymentAccountDelete > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(3) > button");
	public By manageAutoPay=By.xpath("//*[@id='paymentAccountDelete']/article/div/div[3]/div[2]/div/a");
	public String expectedPreTextforNotassociatedwithanyPayment="You do not have any pending payments associated with this account";
	
	public WebElement WelcomeMessage,WelcomeHeader,ManagepaymentaccounthelpIcon,Step1,Step1helpIcon,PreText,Cancel,Next,
	PendingStep,ReviewStep,ConfirmationStep;

	/*
	 * This constructor will be loaded when object is created for the class. The
	 * list of web elements will be available when we call the call.
	 */

	public DeletePaymentAccounts() throws IOException {
		try {
			WebDriverWait wait = new WebDriverWait(driver, 90);
			wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
			//wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
			WelcomeHeader = driver.findElement(welcomeHeader);
			ManagepaymentaccounthelpIcon=driver.findElement(managepaymentaccounthelpIcon);
			Step1helpIcon=driver.findElement(step1helpIcon);
			Step1=driver.findElement(step1);
			//PreText=driver.findElement(preTextforNotassociatedwithanyPayment);
			Cancel=driver.findElement(cancel);
			//Next=driver.findElement(next);
			PendingStep=driver.findElement(pendingStep);
			ReviewStep=driver.findElement(reviewStep);
			ConfirmationStep=driver.findElement(confirmationStep);
			test.pass("Delete Payment accunt Screen",
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		} catch (Exception e) {
			test.fail("Delete Payment Page Error ********" + ExceptionUtils.getStackTrace(e),
					MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
		}
	}
	
	public String getCurrentAutoPay() {
		String currentautopay;
		try {
			WebElement element=driver.findElement(currentAutoPay);
			currentautopay= element.getText().trim();			
		}
		catch(Exception e) {
			WebElement element=driver.findElement(By.xpath("//*[@id='paymentAccountDelete']/article/div/div[2]/div/div[3]"));
			currentautopay= element.getText().trim();
		}
		return currentautopay;
	}
	
	public String getPlanType() {
		String plantype;
		try {
			WebElement element=driver.findElement(planType);
			plantype= element.getText().trim();			
		}
		catch(Exception e) {
			WebElement element=driver.findElement(By.xpath("//*[@id='paymentAccountDelete']/article/div/div[2]/div/div[1]"));
			plantype= element.getText().trim();
		}
		return plantype;
	}
	
	
	public String getWarningText() {
		String warningText;
		try {
			WebElement element=driver.findElement(prexTextforAutoPay);
			warningText= element.getText().trim();			
		}
		catch(Exception e) {
			WebElement element=driver.findElement(By.xpath("//*[@id='paymentAccountDelete']/article/div/div[2]/div/div[3]/span"));
			warningText= element.getText().trim();
		}
		return warningText;
	}
	
	
	public class ManagePaymentAccountReview {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		public static final String expectedWelcomeMessage = "Delete Payment Account";
		private By paymenthelpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
		private By paymentreviewHelpIcon = By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		
		private By cancel = By.cssSelector("#paymentAccountDelete > article > div > div.actions.clearfix > div.pull-left-xs > div > button");
		private By back=By.cssSelector("#paymentAccountDelete > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(2) > button");
		private By removeAccount= By.cssSelector("#paymentAccountDelete > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(4) > button");
		private By step2=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public String expectedstep3Text="Step 2 of 3: Verify removal of account";
		
		private By accounType=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > div:nth-child(3)");
		private By financialInstitution = By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(4)");
		private By accountNumber=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(5)");
		private By routingNumber=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(6)");
		private By accountNickName=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(7)");
		
		public WebElement WelcomeMessage,WelcomeHeader,PaymenthelpIcon,PaymentReviewhelpIcon,
		Cancel,Back,RemoveAccount,Step2,AccountType,FinancialInstitution,AccountNumber,RoutingNumber,AccountNickName;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public ManagePaymentAccountReview() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				PaymenthelpIcon=driver.findElement(paymenthelpIcon);
				PaymentReviewhelpIcon=driver.findElement(paymentreviewHelpIcon);
				Cancel=driver.findElement(cancel);
				Back=driver.findElement(back);
				RemoveAccount=driver.findElement(removeAccount);
				Step2=driver.findElement(step2);
				AccountType=driver.findElement(accounType);
				FinancialInstitution=driver.findElement(financialInstitution);
				AccountNumber=driver.findElement(accountNumber);
				RoutingNumber=driver.findElement(routingNumber);
				AccountNickName=driver.findElement(accountNickName);
				test.pass("Navigated to  delete Payment account Step 3 Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail(" delete Payment account Step 3 Page Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}
	
	public class ManagePaymentAccountConfirmation {
		// Locators for Login Page
		private By welcomeHeader = By.cssSelector("body > div > div > header > div > div.header-branding > a > img");
		private By welcomeMessage = By.cssSelector("#mainHeading");
		public static final String expectedWelcomeMessage = "Add a Payment Account";
		private By paymenthelpIcon = By.cssSelector("#main > div.page-header > button > span.icon-info-circled");
		private By paymentconfirmationHelpIcon = By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > h3 > button > span.icon-info-circled");
		
		private By close = By.cssSelector("#paymentAccountDelete > article > div > div.actions.clearfix > div.pull-right-xs > div:nth-child(1) > button");
		private By step3=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > h3 > strong");
		public String expectedstep4Text="Step 3 of 3: Your account has been removed";
		
		private By accounType=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(2) > span");
		private By financialInstitution = By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(3) > span");
		private By accountNumber=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(4) > span");
		private By routingNumber=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(5) > span");
		private By accountNickName=By.cssSelector("#paymentAccountDelete > article > div > div.clearfix.basic-animation > div > p:nth-child(6) > span");
		
		public WebElement WelcomeMessage,WelcomeHeader,PaymenthelpIcon,PaymentReviewhelpIcon,
		Close,MakeOneTimePayment,ManageAutoPay,Step3,AccountType,FinancialInstitution,AccountNumber,RoutingNumber,AccountNickName;
		
		/*
		 * This constructor will be loaded when object is created for the class. The
		 * list of web elements will be available when we call the call.
		 */

		public ManagePaymentAccountConfirmation() throws IOException {
			try {
				WebDriverWait wait = new WebDriverWait(driver, 90);
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeHeader));
				wait.until(ExpectedConditions.visibilityOfElementLocated(welcomeMessage));
				WelcomeHeader = driver.findElement(welcomeHeader);			
				WelcomeMessage = driver.findElement(welcomeMessage);
				PaymenthelpIcon=driver.findElement(paymenthelpIcon);
				PaymentReviewhelpIcon=driver.findElement(paymentconfirmationHelpIcon);	
				Close=driver.findElement(close);				
				Step3=driver.findElement(step3);
				AccountType=driver.findElement(accounType);
				FinancialInstitution=driver.findElement(financialInstitution);
				AccountNumber=driver.findElement(accountNumber);
				RoutingNumber=driver.findElement(routingNumber);
				AccountNickName=driver.findElement(accountNickName);
				test.pass("Navigated to add Payment account Step 4Page",
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			} catch (Exception e) {
				test.fail("  add Payment account Page 4Error ********" + ExceptionUtils.getStackTrace(e),
						MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		}
	}	
}