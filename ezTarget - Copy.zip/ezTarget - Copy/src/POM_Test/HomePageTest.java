package POM_Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Reporter;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testrail.connection.APIException;

import POM_Classes.Agreements;
import POM_Classes.BaseClass;
import POM_Classes.ChangeContactInformation;
import POM_Classes.ChangePassword;
import POM_Classes.ChangeSecurityQuestionPage;
import POM_Classes.HomePage;
import POM_Classes.MakeOneTimePayment;
import POM_Classes.MyAlerts;
import POM_Classes.PasswordPage;
import POM_Classes.SettingsAndHelp;
import POM_Classes.SpendAnalyzer;
import POM_Classes.Statements;
import POM_Classes.Transactions;
import POM_Classes.UserNamePage;
import POM_Classes.MakeOneTimePayment.MakeOneTimePaymentAmountSelection;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class HomePageTest extends BaseClass {

	/*@BeforeSuite
	public void reports() {
		clearreports();
	}*/

	@BeforeTest
	public void initializestatus() {
		TestCaseStatus = "FAILED";
		record = null;
	}

	@Test(priority = 0, enabled = true)
	public void C2410949_VerifyNicknameIsCorrectlyDisplayedOnHomePage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		String actualNickName = homePage.WelcomeMessage.getText().toString().replaceAll("hello,", "").trim();		
		homePage.SettingsNHelp.click();
		Thread.sleep(15000);
		SettingsAndHelp settingandhelp = new SettingsAndHelp();
		settingandhelp.Click(settingandhelp.ChangeContactInformation);		
		ChangeContactInformation changeContactInformation = new ChangeContactInformation();		
		String expecteduserNickName = changeContactInformation.UserNickName.getText().toString() + "!";
		System.out.println(expecteduserNickName);
		System.out.println(actualNickName);
		AssertVerify(actualNickName, expecteduserNickName);
		homePage.Logout.click();
		TestCaseStatus = "Passed";	
	}
	@Test(priority = 1, enabled = true)
	public void ChangeNickName() throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		String actualNickName = homePage.WelcomeMessage.getText().toString().replaceAll("hello,", "").trim();		
		homePage.SettingsNHelp.click();
		Thread.sleep(15000);
		SettingsAndHelp settingandhelp = new SettingsAndHelp();
		settingandhelp.ChangeContactInformation.click();		
		ChangeContactInformation changeContactInformation = new ChangeContactInformation();
		String expecteduserNickName = changeContactInformation.UserNickName.getText().toString() + "!";
		System.out.println(expecteduserNickName);
		AssertVerify(actualNickName, expecteduserNickName);
		String newNickName = "Test Nick Name";
		changeContactInformation.EditNickName(newNickName);
		homePage.Home.click();
		homePage = new HomePage();
		String changedNickName = homePage.WelcomeMessage.getText().toString().replaceAll("hello,", "").trim();
		System.out.println("Actual Nick Name After Change:" + changedNickName);
		AssertVerify(changedNickName, newNickName + "!");
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}	
	@Test(priority =2, enabled = true)
	public void C2410954_NavigateToMyAlertsFromHomePage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.Click(homePage.MyAlerts);
		MyAlerts myalerts = new MyAlerts();
		homePage.Home.click();
		homePage = new HomePage();		
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	@Test(priority = 3, enabled = true)
	public void C2410945_ClickGoToFullTransactionHistory()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		ScrollToElement(homePage.FullTransactionHistory);
		homePage.FullTransactionHistory.click();
		Transactions transactions = new Transactions();	
		homePage.Logout.click();
	}
	
	@Test(priority = 4, enabled = true)
	public void C2410958_ClickSearchTransactionNavigatedToTransactionsPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		homePage.Logout.click();
	}
	
	@Test(priority = 5, enabled = true)
	public void C2410959_ClickSpendAnalyzerNavigatedToSpendAnalyzerPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSpendAnalyzer();		
		SpendAnalyzer spendAnalyzer= new SpendAnalyzer();
		homePage.Logout.click();
	}
	
	@Test(priority =6, enabled = true)
	public void C2410955_NavigateToSettings()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.Click(homePage.MyAlerts);
		MyAlerts myalerts = new MyAlerts();
		homePage.Home.click();
		homePage = new HomePage();	
		homePage.SettingsNHelp.click();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}

	@Test(priority = 7, enabled = true)
	public void C2410963_LastStatementBalanceOnHomePageAndMakePaymentPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		String lastStatementBalanceOnHomePage = homePage.LastStatementBalance.getText();
		System.out.println(lastStatementBalanceOnHomePage);
		ScrollToElement(homePage.LastPayment);
		homePage.PayNow.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amount = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		String lastStatementBalance = amount.LastStatementBalanceAmount.getText();
		System.out.println(lastStatementBalance);		
		AssertVerify(lastStatementBalanceOnHomePage, lastStatementBalance);		
	}
	
	@Test(priority = 8, enabled = true)
	public void C2410971_ClickTargetHomeToNavigateToHomePage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		homePage.WelcomeHeader.click();
		AssertVerify(homePage.WelcomeMessage.isDisplayed(), true);
	}
	
	
	@Test(priority = 9, enabled = true)
	public void C2410964_LastPaymentOnHomePageAndMakePaymentPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		String lastPaymentOnHomePage = homePage.LastPayment.getText();
		System.out.println(lastPaymentOnHomePage);
		ScrollToElement(homePage.LastPayment);
		homePage.PayNow.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amount = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		String lastPayment = amount.LastPaymentAmount.getText();
		System.out.println(lastPayment);		
		AssertVerify(lastPaymentOnHomePage, lastPayment);		
	}
	
	@Test(priority = 10, enabled = true)
	public void C2410966_MinimumDueAmountOnHomePageAndMakePaymentPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		String minimumAmountDueonHomePage = homePage.MinimumAmountDue.getText();
		System.out.println(minimumAmountDueonHomePage);
		ScrollToElement(homePage.LastPayment);
		homePage.PayNow.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amount = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		String minimumAmountDue = amount.MinimumDueAmount.getText();
		System.out.println(minimumAmountDue);		
		AssertVerify(minimumAmountDueonHomePage, minimumAmountDue);		
	}
	
	
	@Test(priority = 11, enabled = true)
	public void C2410967_CurrentBalanceOnHomePageAndMakePaymentPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		String currentBalanceonHomePage = homePage.CurrentBalance.getText();
		System.out.println(currentBalanceonHomePage);
		ScrollToElement(homePage.LastPayment);
		homePage.PayNow.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amount = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		String remainingBalanceAmount = amount.RemainingBalanceAmount.getText();
		System.out.println(remainingBalanceAmount);		
		AssertVerify(currentBalanceonHomePage, remainingBalanceAmount);		
	}
	
	@Test(priority = 13, enabled = true)
	public void C2410964_PendingBalanceOnHomePageAndMakePaymentPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		String currentBalanceonHomePage = homePage.CurrentBalance.getText();
		System.out.println(currentBalanceonHomePage);
		ScrollToElement(homePage.LastPayment);
		homePage.PayNow.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amount = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		String remainingBalanceAmount = amount.RemainingBalanceAmount.getText();
		System.out.println(remainingBalanceAmount);		
		AssertVerify(currentBalanceonHomePage, remainingBalanceAmount);			
	}
	
	@Test(priority = 14, enabled = true)
	public void C2410944_ClickPayNowButtonTakesToPaymentPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		String currentBalanceonHomePage = homePage.CurrentBalance.getText();
		System.out.println(currentBalanceonHomePage);
		ScrollToElement(homePage.LastPayment);
		homePage.PayNow.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();			
	}
	
	@Test(priority = 15, enabled = true)
	public void C2410947_HomePageValidation()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		AssertVerify(homePage.RecentTransactionsTab.isDisplayed(),true);
		AssertVerify(homePage.SpendSnapShotTab.isDisplayed(),true);
		AssertVerify(homePage.RecentTransactionLabel.isDisplayed(),true);
		AssertVerify(homePage.TransactionLabel.isDisplayed(),true);
		AssertVerify(homePage.SearchInputBox.isDisplayed(),true);
		AssertVerify(homePage.SearchButton.isDisplayed(),true);
		AssertVerify(homePage.SearchButton.isDisplayed(),true);
	
	}
	
	@Test(priority = 16, enabled = true)
	public void C2410957_StatementsNavigatedToStatementPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);		
		HomePage homePage = new HomePage();
		homePage.Statements.click();
		homePage.clickStatementSummaries();
		Statements statements = new Statements();
	}
	
	@Test(priority = 17, enabled = true)
	public void C2410973_MessageIconValidation()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		CreateMessage();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		WebElement messageIcon = driver.findElement(homePage.messageIcon);
		WebElement numberofMessage = driver.findElement(homePage.numberofMessages);
		System.out.println("NumberofMessages:"+ numberofMessage.getText());
		AssertVerify(messageIcon.isDisplayed(), true);
		AssertVerify(numberofMessage.isDisplayed(), true);
		messageIcon.click();
		Thread.sleep(15000);
		homePage.Logout.click();
		TestCaseStatus = "Passed";		
	}
	
	@Test(priority = 17, enabled = true)
	public void C2410946_AccountDetailsVerificationOnHomePage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication("TARGETACH25294", "Target22##");	
		HomePage homePage = new HomePage();
		homePage.Logout.click();
		driver.quit();
		launchUrl();
		LoginApplication(transactionusername, transactionuserpassword);
		homePage = new HomePage();
		homePage.Logout.click();	
	}
	
	@Test(priority = 18, enabled = true)
	public void C2410970_AgreementsAndWelcomePageVerification()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
	DisableOnlineAccessandEnrollNow("target4349");
	TestCaseId = "8789740";
	record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
	record.start();		
	launchUrl();
	startResult();
	startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
	UserNamePage username= new UserNamePage();
	username.EnterUsername("Target4349");
	PasswordPage password = new PasswordPage();
	password.Password.sendKeys("TargetTemp22##");
	password.SignInButton.click();
	Thread.sleep(60000);
	ChangeSecurityQuestionPage changeSecurityQuestionPage= new ChangeSecurityQuestionPage();
	changeSecurityQuestionPage.ChangeSecurityQuestion();
	ChangePassword changePassword= new ChangePassword();
	changePassword.NewPassword.sendKeys("Target111##");
	changePassword.ConfirmPassword.sendKeys("Target111##");
	changePassword.Submit.click();
	Agreements agreements = new Agreements();
	ScrollToElement(agreements.AgreeAndContinue);
	agreements.AgreeAndContinue.click();
	Agreements.NextAgreement next = agreements.new NextAgreement();
	next.AgreeAndContinue.click();
	Thread.sleep(15000);
	Agreements.WelcomePage welcome=agreements.new WelcomePage();
	welcome.Next.click();
	Thread.sleep(15000);
	Agreements.ActivateCard activate = agreements.new ActivateCard();	
	activate.Skip.click();
	Thread.sleep(10000);
	Agreements.StatementDelivery statementdelivery = agreements.new StatementDelivery();
	statementdelivery.Agree.click();
	Agreements.confirmDeliveryMethod confirmDeliveryMethod = agreements.new confirmDeliveryMethod();
	confirmDeliveryMethod.Confirm.click();
	Thread.sleep(10000);
	Agreements.GettingStarted gettingstarted = agreements.new GettingStarted();
	gettingstarted.Complete.click();
	Thread.sleep(60000);
	HomePage homePage = new HomePage();
	}
	
	@Test(priority = 19, enabled = true)
	public void C2410948_VerifyNewWindowOnClickOfScoreCardImageIsAvailable()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		Thread.sleep(60000);
		AssertVerify(driver.findElement(homePage.scorecardImage1).isDisplayed(), true);
		AssertVerify(driver.findElement(homePage.scorecardImage2).isDisplayed(), true);
		String ActualTextOnCardEndingNumber = driver.findElement(By.xpath("//*[@id='CardImageText']/div[3]/span")).getText().trim();
		ActualTextOnCardEndingNumber = ActualTextOnCardEndingNumber.replaceAll("\\n", "");
		ActualTextOnCardEndingNumber = ActualTextOnCardEndingNumber.replaceAll("\\r", " ");
		String ActualAmountSaved = driver.findElement(By.xpath("//*[@id='YouSaveAmount']")).getText().trim();
		ActualAmountSaved = ActualAmountSaved.replaceAll("\\n", "");
		ActualAmountSaved = ActualAmountSaved.replaceAll("\\r", "");
		System.out.println(ActualTextOnCardEndingNumber);
		System.out.println(ActualAmountSaved);
		AssertVerify(ActualTextOnCardEndingNumber,"Target REDcardEnding in 7303");		
		AssertVerify(ActualAmountSaved,"$0.00  REDcard Savings This Year");
	}
	
	@Test(priority = 19, enabled = true)
	public void C2410968_VerifyScoreCardImageIsAvailable()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		boolean flag = false;
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		Thread.sleep(60000);
		driver.findElement(homePage.scorecardImage2).click();
		Thread.sleep(10000);
		ArrayList<String> newWindow1 = getWindowHandles();
		if(newWindow1.get(0).toString().equalsIgnoreCase("Savings On Baby Subscriptions : Target") || newWindow1.get(0).equalsIgnoreCase("Download Target App � Now with Cartwheel : Target") || newWindow1.get(0).equalsIgnoreCase("REDcard Exclusive Extras & Early Access : Target")) 
		{
		flag = true;
		}
		AssertVerify(flag, true);
		driver.quit();
		launchUrl();
		LoginApplication(username, password);		
		homePage = new HomePage();
		Thread.sleep(60000);
		driver.findElement(homePage.scorecardImage1).click();
		Thread.sleep(10000);
		ArrayList<String> newWindow2 = getWindowHandles();		
		AssertVerify(newWindow2.get(0).toString(), "REDcard : Target");
		driver.quit();
	}
	
	
	@AfterMethod
	public void afterMethod() throws ATUTestRecorderException, MalformedURLException, IOException, APIException {		
		endTestcase();
		endResult();
		record.stop();
		//updateResults(TestCaseId, TestCaseStatus);
		closeBrowsers();	
	}
}
