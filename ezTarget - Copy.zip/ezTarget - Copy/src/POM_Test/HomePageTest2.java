package POM_Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testrail.connection.APIException;

import POM_Classes.BaseClass;
import POM_Classes.HomePage;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class HomePageTest2 extends BaseClass {

	@BeforeSuite
	public void reports() {
		clearreports();
	}

	@BeforeTest
	public void initializestatus() {
		TestCaseStatus = "FAILED";
		record = null;
	}

	@Test(priority = 19, enabled = true)
	public void C2410948_VerifyScoreCardImageIsAvailable()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		boolean flag = false;
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);		
		HomePage homePage = new HomePage();
		Thread.sleep(60000);
		driver.findElement(homePage.scorecardImage2).click();
		Thread.sleep(10000);
		ArrayList<String> newWindow1 = getWindowHandles();
		if(newWindow1.get(0).toString().equalsIgnoreCase("Savings On Baby Subscriptions : Target") || newWindow1.get(0).equalsIgnoreCase("Download Target App � Now with Cartwheel : Target") || newWindow1.get(0).equalsIgnoreCase("REDcard Exclusive Extras & Early Access : Target")) 
		{
		flag = true;
		}
		AssertVerify(flag, true);
		driver.quit();
		launchUrl();
		LoginApplication(username, password);		
		homePage = new HomePage();
		Thread.sleep(60000);
		driver.findElement(homePage.scorecardImage1).click();
		Thread.sleep(10000);
		ArrayList<String> newWindow2 = getWindowHandles();		
		AssertVerify(newWindow2.get(0).toString(), "REDcard : Target");
		driver.quit();
	}
	
	
	@AfterMethod
	public void afterMethod() throws ATUTestRecorderException, MalformedURLException, IOException, APIException {		
		endTestcase();
		endResult();
		record.stop();
		//updateResults(TestCaseId, TestCaeStatus);
		closeBrowsers();	
	}
}
