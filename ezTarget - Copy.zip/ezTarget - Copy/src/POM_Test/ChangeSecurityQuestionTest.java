package POM_Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.List;

import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testrail.connection.APIException;

import POM_Classes.BaseClass;
import POM_Classes.ChangeSecurityQuestionPage;
import POM_Classes.HomePage;
import POM_Classes.SettingsAndHelp;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class ChangeSecurityQuestionTest extends BaseClass {

	/*@BeforeSuite
	public void reports() {
		clearreports();
	}

	@BeforeTest
	public void initializestatus() {
		TestCaseStatus = "FAILED";
		record = null;
	}*/


	/*@Test(priority = 0, enabled = true)
	public void C2410869_ChangeSecurityQuestion()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Select Settings and Help -> Select Change Security Question Page -> Change Security Questions and Submit -> Verify Success message");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.SettingsNHelp.click();
		SettingsAndHelp settingsAndHelp= new SettingsAndHelp();
		settingsAndHelp.ChangeSecurityQuestion.click();
		ChangeSecurityQuestionPage changeSecurityQuestionPage= new ChangeSecurityQuestionPage();
		String Successmessage = changeSecurityQuestionPage.ChangeSecurityQuestion();
		AssertVerify(Successmessage, changeSecurityQuestionPage.expectedSuccessMessage);
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	/*@Test(priority = 1, enabled = true)
	public void C2410869_AnswerCanNotBeSameForSecurityQuestion()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Select Settings and Help -> Select Change Security Question Page -> Give Same Answer for Seurity Questions and Submit -> Verify Error message");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.SettingsNHelp.click();
		SettingsAndHelp settingsAndHelp= new SettingsAndHelp();
		settingsAndHelp.ChangeSecurityQuestion.click();
		ChangeSecurityQuestionPage changeSecurityQuestionPage= new ChangeSecurityQuestionPage();
		selectDropDownByIndex(changeSecurityQuestionPage.Question1, 1);		
		changeSecurityQuestionPage.Answer1.sendKeys("SameAnswer");
		selectDropDownByIndex(changeSecurityQuestionPage.Question2, 1);
		changeSecurityQuestionPage.Answer2.sendKeys("SameAnswer");
		selectDropDownByIndex(changeSecurityQuestionPage.Question3, 1);
		changeSecurityQuestionPage.Answer3.sendKeys("Back");
		selectDropDownByIndex(changeSecurityQuestionPage.Question4, 1);
		changeSecurityQuestionPage.Answer4.sendKeys("Next");
		changeSecurityQuestionPage.Submit.click();
		AssertVerify(changeSecurityQuestionPage.expectedSecurityQuestionErrorMessageOnSameAnswer, changeSecurityQuestionPage.ErrorMessage());
		WebElement CloseIcon= driver.findElement(ChangeSecurityQuestionPage.closeIcon);
		CloseIcon.click();		
		homePage.Logout.click();
		TestCaseStatus = "Passed";
		}
	
	@Test(priority = 2, enabled = true)
	public void C2410869_UpdateFailedOnLessThanNumberOfCharactersRequired()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Select Settings and Help -> Select Change Security Question Page -> Give Same Answer for Seurity Questions and Submit -> Verify Error message");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.SettingsNHelp.click();
		SettingsAndHelp settingsAndHelp= new SettingsAndHelp();
		settingsAndHelp.ChangeSecurityQuestion.click();
		ChangeSecurityQuestionPage changeSecurityQuestionPage= new ChangeSecurityQuestionPage();
		selectDropDownByIndex(changeSecurityQuestionPage.Question1, 1);		
		changeSecurityQuestionPage.Answer1.sendKeys("ab");
		selectDropDownByIndex(changeSecurityQuestionPage.Question2, 1);
		changeSecurityQuestionPage.Answer2.sendKeys("cd");
		selectDropDownByIndex(changeSecurityQuestionPage.Question3, 1);
		changeSecurityQuestionPage.Answer3.sendKeys("ef");
		selectDropDownByIndex(changeSecurityQuestionPage.Question4, 1);
		changeSecurityQuestionPage.Answer4.sendKeys("gh");
		changeSecurityQuestionPage.Submit.click();
		AssertVerify(changeSecurityQuestionPage.expectedSecurityQuestionErrorMessageOnLengthValidation, changeSecurityQuestionPage.ErrorMessage());		
		WebElement CloseIcon= driver.findElement(ChangeSecurityQuestionPage.closeIcon);
		CloseIcon.click();		
		homePage.Logout.click();
		TestCaseStatus = "Passed";
		}
	
	
	@Test(priority = 2, enabled = true)
	public void C2410869_SecurityAnswerIsEmpty()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Select Settings and Help -> Select Change Security Question Page -> Give Same Answer for Seurity Questions and Submit -> Verify Error message");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.SettingsNHelp.click();
		SettingsAndHelp settingsAndHelp= new SettingsAndHelp();
		settingsAndHelp.ChangeSecurityQuestion.click();
		ChangeSecurityQuestionPage changeSecurityQuestionPage= new ChangeSecurityQuestionPage();
		selectDropDownByIndex(changeSecurityQuestionPage.Question1, 1);		
		selectDropDownByIndex(changeSecurityQuestionPage.Question2, 1);
		selectDropDownByIndex(changeSecurityQuestionPage.Question3, 1);
		selectDropDownByIndex(changeSecurityQuestionPage.Question4, 1);
		changeSecurityQuestionPage.Submit.click();
		List<WebElement> ErrorMessage = driver.findElements(changeSecurityQuestionPage.tooltip);
		AssertVerify(changeSecurityQuestionPage.expectedSecurityQuestionErrorMessageOnLengthIsEmpty, ErrorMessage.get(0).getText().toString());
		homePage.Logout.click();
		TestCaseStatus = "Passed";
		}
	
	@Test(priority = 3,enabled = true)
	public void ChangeUsername() throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		//String TestCaseId = "8789740";
		ATUTestRecorder record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.SettingsNHelp.click();		
		SettingsAndHelp settingandhelp = new SettingsAndHelp();
		settingandhelp.ChangeUsername.click();
		SettingsAndHelp.ChangeUserName changeusername = settingandhelp.new ChangeUserName();
		String newuserName = "TargetNewUser";
		String successMessage = changeusername.changeusername(newuserName);
		AssertVerify(successMessage, changeusername.expectedsuccessMessage);
		homePage.Home.click();
		homePage.Logout.click();
		driver.quit();
		launchUrl();
		//Login with changed username
		LoginApplication(newuserName, password);
		homePage = new HomePage();
		homePage.SettingsNHelp.click();		
		settingandhelp = new SettingsAndHelp();
		//Reverting back to original username 
		settingandhelp.ChangeUsername.click();
		changeusername = settingandhelp.new ChangeUserName();		
		String successMessageagain = changeusername.changeusername(username);		
		homePage.Logout.click();
		TestCaseStatus = "Passed";

	}*/
	
	/*@AfterMethod
	public void afterMethod() throws ATUTestRecorderException {		
		record.stop();
		endTestcase();
		endResult();
		closeBrowsers();
	}*/
}
