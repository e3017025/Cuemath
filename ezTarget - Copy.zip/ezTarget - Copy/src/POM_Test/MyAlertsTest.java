package POM_Test;

import java.io.IOException;
import java.net.MalformedURLException;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testrail.connection.APIException;

import POM_Classes.BaseClass;
import POM_Classes.ChangeContactInformation;
import POM_Classes.ChangeSecurityQuestionPage;
import POM_Classes.HomePage;
import POM_Classes.MyAlerts;
import POM_Classes.SettingsAndHelp;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class MyAlertsTest extends BaseClass {

	/*@BeforeSuite
	public void reports() {
		clearreports();
	}*/

	@BeforeTest
	public void initializestatus() {
		TestCaseStatus = "FAILED";
		record = null;
	}

	@Test(priority = 0, enabled = true)
	public void C2410961_NavigateToMyAlertsAndAddNewAlerts()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Verify that the added alert is Active for the same card and channel.");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.clearAllAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();		
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		String selectedcardName = addnewalert.SendAlertFor.getAttribute("aria-label").toString();
		String selectedChannel = addnewalert.SendAlertVia.getAttribute("aria-label").toString();
		addnewalert.createNewAlert(AlertMeConstants.CreditLimitreached, "5000");
		int numberofalertsafteradding = myalerts.numberofAlerts();
		boolean flag = myalerts.checkalertIsActive(AlertMeConstants.CreditLimitreached);		
		AssertVerify(flag, true);
		int index = myalerts.returnalertindex(AlertMeConstants.CreditLimitreached);		
		String cardNameOnMyAlertsPage = myalerts.returnCardName(index);
		AssertVerify(selectedcardName, cardNameOnMyAlertsPage);		
		AssertVerify(selectedChannel, myalerts.returnChannelName(index));
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}

	@Test(priority = 1, enabled = true)
	public void C2410867_NavigateToMyAlertsAndDeleteAlerts()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Verify that the added alert is Active -> Select Edit -> Navigated to Edit Alert Screen -> Select Delete -> Verify that the deleted alerts is not exists");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		System.out.println(numberofalertsbeforeadding);
		myalerts.AddNewAlert.click();
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.createNewAlert(AlertMeConstants.SetamountTransactionsmadeinasingleday, "5");
		int numberofalertsafteradding = myalerts.numberofAlerts();
		boolean flag = myalerts.checkalertIsActive(AlertMeConstants.SetamountTransactionsmadeinasingleday);
		System.out.println("Flag Value:" + flag);
		AssertVerify(flag, true);
		myalerts = new MyAlerts();
		myalerts.EditAlertWhichIsJustCreated(AlertMeConstants.SetamountTransactionsmadeinasingleday);
		MyAlerts.EditExistingAlert editAlert = myalerts.new EditExistingAlert();
		editAlert.DeleteAlert.click();
		myalerts = new MyAlerts();
		Thread.sleep(10000);
		System.out.println(myalerts.returnalertindex(AlertMeConstants.SetamountTransactionsmadeinasingleday));
		AssertVerify(myalerts.returnalertindex(AlertMeConstants.SetamountTransactionsmadeinasingleday),-1);
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}

	@Test(priority = 2, enabled = true)
	public void C2410861_ToggleOffActiveAlerts()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Verify that the added alert is Active -> Verify that user is able to Toggle Off the active alerts");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		System.out.println(numberofalertsbeforeadding);
		myalerts.AddNewAlert.click();
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.createNewAlert(AlertMeConstants.Singlepurchaseexceedssetamount, "5000");
		int numberofalertsafteradding = myalerts.numberofAlerts();
		int flag = myalerts.returnalertindex(AlertMeConstants.Singlepurchaseexceedssetamount);
		System.out.println("Flag Value:" + flag);
		myalerts = new MyAlerts();
		myalerts.ClickToggleOff(flag);
		Thread.sleep(5000);
		boolean active = myalerts.checkalertIsActive(AlertMeConstants.Singlepurchaseexceedssetamount);
		AssertVerify(active, false);
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}

	@Test(priority = 3, enabled = true)
	public void C2410868_ToggleOnInActiveAlertsAndVerifyMobileIcon()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {

		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Verify that the added alert is Active -> Toggle Off Alert -> Verify that user is able to Toggle On the inactive alerts");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		System.out.println(numberofalertsbeforeadding);
		myalerts.AddNewAlert.click();
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.createNewAlert(AlertMeConstants.Paymentpostedtomyaccount, "500");
		int numberofalertsafteradding = myalerts.numberofAlerts();
		int flag = myalerts.returnalertindex(AlertMeConstants.Paymentpostedtomyaccount);
		System.out.println("Flag Value:" + flag);
		myalerts = new MyAlerts();
		//java.util.List<String> icon = myalerts.returnIcon(flag);		
		//AssertVerify(icon.get(0).toString(), "icon-mobile");
		myalerts.ClickToggleOff(flag);
		Thread.sleep(5000);
		boolean active = myalerts.checkalertIsActive(AlertMeConstants.Paymentpostedtomyaccount);
		AssertVerify(active, false);
		Thread.sleep(5000);
		myalerts.ClickToggleOn(flag);
		Thread.sleep(5000);
		boolean active1 = myalerts.checkalertIsActive(AlertMeConstants.Paymentpostedtomyaccount);
		AssertVerify(active1, true);
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}

	@Test(priority = 4, enabled = true)
	public void C2410957_DuplicateAlert()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {

		TestCaseId="8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Add the same alert Again -> Verify that Dupicate alert is displayed");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();		
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.createNewAlert(AlertMeConstants.Availablebalancedropsbelow, "500");
		myalerts = new MyAlerts();
		myalerts.AddNewAlert.click();
		MyAlerts.AddNewAlert addnewalertagain = myalerts.new AddNewAlert();
		addnewalertagain.createNewAlert(AlertMeConstants.Availablebalancedropsbelow, "500");
		MyAlerts.DuplicateAlertModal duplicateAlertModal = myalerts.new DuplicateAlertModal();
		AssertVerify(duplicateAlertModal.ModalTitle.getText().toString(), duplicateAlertModal.ExpectedModalTitle);
		AssertVerify(duplicateAlertModal.ModalDescription.getText().toString(),
				duplicateAlertModal.ExpectedModalDescription);
		duplicateAlertModal.OK.click();		
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 5, enabled = true)
	public void C2410852_ValidateHelpOptionInAlertsPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Select Help Icon and Verify the details of Help Page");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.HelpIcon.click();
		Thread.sleep(2000);
		MyAlerts.HelpModal helpmodal = myalerts.new HelpModal();
	    AssertVerify(helpmodal.HelpText.getText().toString(), helpmodal.expectedHelpText);
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.createNewAlert(AlertMeConstants.ACreditotherthanpaymentpoststomyaccount, "5000");
		int numberofalertsafteradding = myalerts.numberofAlerts();
		boolean flag = myalerts.checkalertIsActive(AlertMeConstants.ACreditotherthanpaymentpoststomyaccount);
		System.out.println("Flag Value:" + flag);
		AssertVerify(flag, true);
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 6, enabled = true)
	public void C2410855_ValidateDoneButtonInHelpOptionInAlertsPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Select Help Icon and Verify that Done Closes the Help Icon");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.HelpIcon.click();
		Thread.sleep(2000);
		MyAlerts.HelpModal helpmodal = myalerts.new HelpModal();
	    AssertVerify(helpmodal.HelpText.getText().toString(), helpmodal.expectedHelpText);
		helpmodal.DoneButton.click();
		Thread.sleep(2000);		
		myalerts = new MyAlerts();
		AssertVerify(VerifyElementIsDispalyed(helpmodal.ModalNumber),false);
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 7, enabled = true)
	public void C2410860_ClickAddNewAlertTwice()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId="8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Click Add New Alert again -> Verify that add new alert side bar is closed");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();	
		Thread.sleep(2000);
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		myalerts.AddNewAlert.click();
		Thread.sleep(2000);
		AssertVerify(VerifyElementIsDispalyed(addnewalert.AlertMeWhen),false);
		myalerts = new MyAlerts();		
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	
	@Test(priority = 8, enabled = true)
	public void C2410965_ClickEditAlertTwice()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Click Edit Alert -> Click Edit New Alert again -> Verify that edit alert side bar is closed");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.clearAllAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.createNewAlert(AlertMeConstants.PaymentReturned, "5000");
		int numberofalertsafteradding = myalerts.numberofAlerts();
		boolean flag = myalerts.checkalertIsActive(AlertMeConstants.PaymentReturned);
		System.out.println("Flag Value:" + flag);
		AssertVerify(flag, true);
		myalerts = new MyAlerts();
		myalerts.EditAlertWhichIsJustCreated(AlertMeConstants.PaymentReturned);
		Thread.sleep(2000);
		MyAlerts.EditExistingAlert editAlert = myalerts.new EditExistingAlert();
		myalerts.EditAlertWhichIsJustCreated(AlertMeConstants.PaymentReturned);
		Thread.sleep(2000);
		AssertVerify(VerifyElementIsDispalyed(editAlert.AlertMeWhen),false);
		TestCaseStatus = "Passed";
	}

	
	@Test(priority = 9, enabled = true)
	public void C2410866_NavigateToMyAlertsAndEditAlert()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Click Edit Alert -> verify that user is able to update the alert");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		System.out.println(numberofalertsbeforeadding);
		myalerts.AddNewAlert.click();
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.createNewAlert(AlertMeConstants.PaymentDueReminder, "5");
		int numberofalertsafteradding = myalerts.numberofAlerts();
		boolean flag = myalerts.checkalertIsActive(AlertMeConstants.PaymentDueReminder);
		System.out.println("Flag Value:" + flag);
		AssertVerify(flag, true);
		myalerts = new MyAlerts();
		// myalerts.clickEditAlert();
		myalerts.EditAlertWhichIsJustCreated(AlertMeConstants.PaymentDueReminder);
		MyAlerts.EditExistingAlert editAlert = myalerts.new EditExistingAlert();
		WebElement condition = driver.findElement(editAlert.condition);
		driver.findElement(editAlert.condition).clear();
		condition.sendKeys("15");
		editAlert.SaveAlert.click();
		Thread.sleep(3000);
		myalerts = new MyAlerts();
		Thread.sleep(3000);
		myalerts.EditAlertWhichIsJustCreated(AlertMeConstants.PaymentDueReminder);
		editAlert = myalerts.new EditExistingAlert();
		AssertVerify(driver.findElement(editAlert.condition).getAttribute("value").toString(), "15");
		Thread.sleep(10000);
		editAlert.CloseIcon.click();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 10, enabled = true)
	public void C2410864_ClickCloseIconInAddNewAlertScreen()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId="8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Verify that Click X icon closes the add new alert side bar");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();		
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.CloseIcon.click();
		Thread.sleep(3000);
		AssertVerify(VerifyElementIsDispalyed(addnewalert.AlertMeWhen),false);
		myalerts = new MyAlerts();		
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 11, enabled = true)
	public void C2410863_SaveButtonDisabledValidationInAddNewAlertScreen()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId="8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Verify that Save Button is disabled when all the mandatory field is not provided");
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();		
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.AlertMeWhen.sendKeys(AlertMeConstants.AccountPastDue);		
		AssertVerify(addnewalert.SaveAlert.isEnabled(),false);
		myalerts = new MyAlerts();		
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 12, enabled = true)
	public void C2410862_ClickCancelInAddNewAlertScreen()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId="8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Add New Alert -> Verify that Cancel Button closes Add New Alert Side Bar");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();		
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		//myalerts.AddNewAlert.click();
		addnewalert.CancelAlert.click();
		AssertVerify(VerifyElementIsDispalyed(addnewalert.AlertMeWhen),false);
		myalerts = new MyAlerts();		
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 13, enabled = true)
	public void C2410950_ValidateMyAlertsPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Validate My Alerts Page");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.AlertHistory.click();
		Thread.sleep(2000);
		myalerts.AlertSettings.click();
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 14, enabled = true)
	public void C2410858_VerifyListOfAlertsType()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId="8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Select Add New Alert -> Validate List Of Alerts Types");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();		
		boolean flag = myalerts.ListOfAlertTypes();
		AssertVerify(flag, true);
		myalerts = new MyAlerts();		
		//homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}	
	@Test(priority = 15, enabled = true)
	public void C2410859_ManageEmailAddressInAlertsPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId="8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Select Add New Alert -> Select Manage Email Address is Navigated to Change Contact Information Page");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.AddNewAlert.click();		
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.ManageEmailAddresses.click();
		Thread.sleep(2000);		
		ChangeContactInformation changecontactinformation = new ChangeContactInformation(); 
		AssertVerify(VerifyElementIsDispalyed(changecontactinformation.BusinessPhone),true);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 16, enabled = true)
	public void C2410859_FilterAlertsByCard()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId="8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Select Add New Alert -> Add New Alert -> Filter Alerts By Selected Card");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.clearAllAlerts();
		myalerts.AddNewAlert.click();		
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();
		addnewalert.AlertMeWhen.sendKeys(AlertMeConstants.Balancewithinsetamountofcreditlimit);
		addnewalert.SendAlertVia.click();
		String sendAlertVia = addnewalert.SendAlertVia.getAttribute("id");		
		addnewalert.SendAlertFor.click();
		String sendAlertFor = addnewalert.SendAlertFor.getAttribute("aria-label");
		addnewalert.SaveAlert.click();
		Thread.sleep(5000);
		selectDropDownByVisibleText(myalerts.ViewCardDropDown, sendAlertFor);
	    myalerts.VerifyCardDetailsOnDropDown(sendAlertFor);	
	}
	
	@Test(priority = 17, enabled = true)
	public void C2410868_CreateNewAlertForAllCardsAndAllChannels()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {

		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Select Add New Alert -> Add New Alert -> Create Alerts for all cards and all channel -> Verify that channel icon is displayed correctly");
		LoginApplication("TargetMCP368671", password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		int numberofalertsbeforeadding = myalerts.numberofAlerts();
		myalerts.clearAllAlerts();
		System.out.println(numberofalertsbeforeadding);
		myalerts.AddNewAlert.click();
		MyAlerts.AddNewAlert addnewalert = myalerts.new AddNewAlert();		
		addnewalert.createNewAlertForAllCardsAndAllChannels(AlertMeConstants.Balanceexceeds, "500");
		int numberofalertsafteradding = myalerts.numberofAlerts();
		int flag = myalerts.returnalertindex(AlertMeConstants.Balanceexceeds);
		System.out.println("Flag Value:" + flag);
		myalerts = new MyAlerts();
		java.util.List<String> icon = myalerts.returnIcon(flag);		
		AssertVerify(icon.get(0).toString(), "icon-mobile");				
		AssertVerify(icon.get(1).toString(), "icon-mail");
		selectDropDownByIndex(myalerts.ViewCardDropDown, 1);
		String element = driver.findElement(By.xpath("//*[@id='alertAccounts']/option[1]")).getText();
		boolean result = myalerts.VerifyCardDetailsOnDropDown(element);	
		AssertVerify(result, true);
		selectDropDownByIndex(myalerts.ViewCardDropDown, 2);
		String element1 = driver.findElement(By.xpath("//*[@id='alertAccounts']/option[2]")).getText();
		boolean result1 = myalerts.VerifyCardDetailsOnDropDown(element1);
		AssertVerify(result1, true);
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	

	@Test(priority = 18, enabled = true)
	public void C2410868_AlertHistory()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {

		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Select Alert History -> Validate Alert History Page ");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.AlertHistory.click();
		Thread.sleep(2000);
		myalerts.verifyAlertHistoryTab();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 19, enabled = true)
	public void C2410868_NoAlertsDisplayedOnClearingAllAlerts()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {

		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video", Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Clear All alerts -> Verify that You have no alerts is displayed");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.clearAllAlerts();
		Thread.sleep(2000);
		AssertVerify(driver.findElement(By.xpath("//*[@id='alert-settings']/div/h3")).getText().toString(), "You have no alerts");
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 20, enabled = true)
	public void C2410867_ClickFAQOnMyAlertsPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Click FAQs");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.FAQs.click();		
		Thread.sleep(5000);
		WebElement element = driver.findElement(By.xpath("//*[@id='header']"));		
		AssertVerify(element.getText().toString(), "Frequently Asked Questions");
	}
	
	@Test(priority = 21, enabled = true)
	public void C2410867_ClickSettingsOnMyAlertsPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Click Settings and Help");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		myalerts.SettingsAndHelpLink.click();
		Thread.sleep(5000);
		SettingsAndHelp settings = new SettingsAndHelp();
	}
	
	@Test(priority = 22, enabled = true)
	public void C2410869_BrokenLinks()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Verify All the Links");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.MyAlerts.click();
		MyAlerts myalerts = new MyAlerts();
		brokenLink();
	}
	
	/*@Test(priority = 23, enabled = true)
	public void C2410869_ChangeSecurityQuestion()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click My Alerts On Home Page -> Navigated to My Alerts Page -> Verify All the Links");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.Click(homePage.SettingsNHelp);
		SettingsAndHelp settingsAndHelp= new SettingsAndHelp();
		settingsAndHelp.Click(settingsAndHelp.ChangeSecurityQuestion);
		ChangeSecurityQuestionPage changeSecurityQuestionPage= new ChangeSecurityQuestionPage();
		String Successmessage = changeSecurityQuestionPage.ChangeSecurityQuestion();
		AssertVerify(Successmessage, changeSecurityQuestionPage.expectedSuccessMessage);
	}*/
	@Test(priority = 24, enabled = true)
	public void C2410961_NavigateToMyAlertsOnClickOfNotificationPreferences()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		test.info("Flow: Login Application -> Navigated to Home Page -> Click Settings And Help -> Select Notification Preferences -> Navigated to My Alerts Page");
		LoginApplication(username, password);
		HomePage homePage = new HomePage();
		homePage.SettingsNHelp.click();
		SettingsAndHelp settingsandhelp = new SettingsAndHelp();
		settingsandhelp.NotificationPreferences.click();
		MyAlerts myalerts = new MyAlerts();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";		
	}
	@AfterMethod
	public void afterMethod() throws ATUTestRecorderException {
		record.stop();
		endTestcase();
		endResult();
		closeBrowsers();	
	}

	/*@AfterTest
	public void AfterTestTearDown() throws ATUTestRecorderException, MalformedURLException, IOException, APIException {
		//updateResults(TestCaseId, TestCaseStatus);
		
	}*/
}
