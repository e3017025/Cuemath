package POM_Test;

import java.awt.AWTException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testrail.connection.APIException;

import POM_Classes.BaseClass;
import POM_Classes.HomePage;
import POM_Classes.SpendAnalyzer;
import POM_Classes.Transactions;
import POM_Classes.BaseClass.CardTypes;
import POM_Classes.BaseClass.GetInputData;
import POM_Classes.BaseClass.ReportTypes;
import POM_Classes.SpendAnalyzer.SaveThisSearchConfirmModal;
import POM_Classes.SpendAnalyzer.TimePeriod;
import POM_Classes.Transactions.AddTimeLabel;
import POM_Classes.Transactions.Categories;
import POM_Classes.Transactions.CustomDateRangeForTime;
import POM_Classes.Transactions.EditModal;
import POM_Classes.Transactions.ExportModal;
import POM_Classes.Transactions.OrderBy;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class ATransactionTest extends BaseClass {

	@BeforeSuite
	public void reports() {
		clearreports();
	}

	@BeforeTest
	public void initializestatus() {
		TestCaseStatus = "FAILED";
		record = null;
	}
	
	@Test(priority = 0, enabled = true)
	public void C2411168_VerifyListOfTransactoinBasedOnMerchant()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		String MerchantName = transactions.getDataForSearchInput(GetInputData.GetMerchantName);
		transactions.SearchInput.sendKeys(MerchantName);
		transactions.SearchButton.click();
		Thread.sleep(5000);
		transactions.VerifySearchInputBySearchTextBox(MerchantName);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";	
	}
	
	@Test(priority = 1, enabled = true)
	public void C2411169_VerifyListOfTransactoinBasedOnCategory()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		String Category = transactions.getDataForSearchInput(GetInputData.GetCategory);
		System.out.println(Category);
		transactions.SearchInput.sendKeys(Category);
		transactions.SearchButton.click();
		Thread.sleep(5000);
		transactions.VerifySearchInputBySearchTextBox(Category);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 2, enabled = true)
	public void C2411170_TransactionSinceLastStatment()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.SinceLastStatement.click();		
		addTimeLabel.Apply.click();	
		//need more information to do the verification
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 3, enabled = true)
	public void C2411171_TransactionsCustomRangeDate()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
				
		//ToDate
		String toDate = transactions.getDataForSearchInput("GetTransactionDate");
		String[] splitdata = toDate.split(",");
		System.out.println(DateValue(toDate));
		String year =splitdata[splitdata.length-1].trim();
		String month = splitdata[splitdata.length-2].split(" ")[0].trim();
		String date=splitdata[splitdata.length-2].split(" ")[1].trim();
		System.out.println(year);
		System.out.println(month);
		System.out.println(date);
		if(date.startsWith("0") == true) {
			date = date.replace("0","");
		}
		
		//FromDate
		String fromDate = transactions.getDataForSearchInputforspecificRow("GetTransactionDate",2);
		System.out.println(fromDate);
		String[] splitfromdata = fromDate.split(",");
		System.out.println(DateValue(fromDate));
		String fromyear =splitfromdata[splitfromdata.length-1].trim();
		String frommonth = splitfromdata[splitfromdata.length-2].split(" ")[0].trim();
		String fromdate=splitfromdata[splitfromdata.length-2].split(" ")[1].trim();
		System.out.println(fromyear);
		System.out.println(frommonth);
		System.out.println(fromdate);
		if(fromdate.startsWith("0") == true) {
				fromdate = fromdate.replace("0","");
		}
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.CustomDateRangeOption.click();
		Transactions.CustomDateRangeForTime customdateRange=transactions.new CustomDateRangeForTime();
		selectDropDownByVisibleText(customdateRange.FromYear, fromyear);		
		selectDropDownByVisibleText(customdateRange.FromMonth, getFullMonth(frommonth));		
		selectDropDownByVisibleText(customdateRange.FromDay, fromdate);
		selectDropDownByVisibleText(customdateRange.ToYear, year);		
		selectDropDownByVisibleText(customdateRange.ToMonth, getFullMonth(month));		
		selectDropDownByVisibleText(customdateRange.ToDay, date);
		customdateRange.Apply.click();
		Thread.sleep(2000);
		addTimeLabel.Apply.click();
		Thread.sleep(3000);
		AssertVerify(transactions.verifyDateIsWithinRange(fromDate, toDate),true);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 4, enabled = true)
	public void C2411172_VerifyListOfTransactoinBasedOnSingleCategory()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);		
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.CategoriesOption);
		transactions.CategoriesOption.click();
		Transactions.Categories categories = transactions.new Categories();
		categories.ClearAll.click();
		WebElement categoryElement=driver.findElement(categories.selectcategory);
		categoryElement.click();
		String CateogoryName = categoryElement.getAttribute("title");
		categories.Apply.click();		
		Thread.sleep(5000);
		System.out.println(driver.findElement(transactions.filter1).isDisplayed());
		System.out.println(driver.findElement(transactions.filter1).getText());
		//AssertVerify(driver.findElement(transactions.filter1).getText().toString(),CateogoryName);
		transactions.VerifyInputDataForAllTransactions(GetInputData.GetCategory, CateogoryName);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 5, enabled = true)
	public void C2411173_MultipleCategorySelection()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();
		addTimeLabel.Apply.click();		
		ArrayList<String> cat = transactions.SelectMultipleCategory(3);
		System.out.println(cat);
		System.out.println(transactions.verifyMultipleCategoryResult(cat));
		AssertVerify(transactions.verifyMultipleCategoryResult(cat), true);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 6, enabled = true)
	public void C2411174_VerifyListOfTransactoinBasedOnAmount()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		String Amount = transactions.getDataForSearchInput(GetInputData.GetAmount);
		transactions.SearchInput.sendKeys(Amount);
		transactions.SearchButton.click();
		Thread.sleep(5000);
		transactions.VerifyInputDataForAllTransactions(GetInputData.GetAmount, Amount);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 7, enabled = true)
	public void C2411174_TransactionBasedOnAmountAnyToSpecifiedValue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		String lRange="";
		String uRange="10";
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys(lRange);
		amount.ToAmount.sendKeys(uRange);
		amount.Apply.click();		
		transactions = new Transactions();
		transactions.verifyAmountIsWithInTheRange(lRange, uRange);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 8, enabled = true)
	public void C2411175_TransactionBasedOnAmountSpecifiedToAnyValue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		String lRange="60";
		String uRange="";
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys(lRange);
		amount.ToAmount.sendKeys(uRange);
		amount.Apply.click();		
		transactions = new Transactions();
		transactions.verifyAmountIsWithInTheRange(lRange, uRange);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	@Test(priority = 9, enabled = true)
	public void C2411175_TransactionBasedOnAmountNegativeValues()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		String lRange="-10";
		String uRange="-10";
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys(lRange);
		amount.ToAmount.sendKeys(uRange);
		amount.Apply.click();		
		transactions = new Transactions();
		transactions.verifyAmountIsWithInTheRange(lRange, uRange);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 10, enabled = true)
	public void C2411176_TransactionBasedOnAmountSpecifiedToSpecifiedValue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		String lRange="60";
		String uRange="80";
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys(lRange);
		amount.ToAmount.sendKeys(uRange);
		amount.Apply.click();		
		transactions = new Transactions();
		transactions.verifyAmountIsWithInTheRange(lRange, uRange);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 11, enabled = true)
	public void C2411177_TransactionOrderByDateAscending()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.OrderByoption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.DateAscending.click();
		orderBy.Apply.click();
		boolean ascendingorderflag = transactions.verifyDateAscendingOrder();
		AssertVerify(ascendingorderflag,true);		
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 12, enabled = true)
	public void C2411178_TransactionOrderByDateDescending()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.OrderByoption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.DateDescending.click();
		orderBy.Apply.click();		
		boolean descendingorderflag = transactions.verifyDateDescendingOrder();
		AssertVerify(descendingorderflag,true);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 13, enabled = true)
	public void C2411179_TransactionOrderByName()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.OrderByoption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.Name.click();
		orderBy.Apply.click();	
		boolean ascendingorderflag = transactions.verifyAscendingOrderForName();
		AssertVerify(ascendingorderflag,true);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 14, enabled = true)
	public void C2411180_TransactionOrderByAmount()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.Amount.click();
		orderBy.Apply.click();		
		boolean ascendingorderflag = transactions.verifyAscendingOrderForAmount();
		AssertVerify(ascendingorderflag,true);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 15, enabled = true)
	public void C2411181_ClearAllCategories()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.CategoriesOption);
		transactions.CategoriesOption.click();
		Transactions.Categories categories=transactions.new Categories();
		categories.SelectAll.click();
		categories.Apply.click();
		AssertVerify(transactions.CategoriesOption.getText().trim(),"Categories Selected (33)");
		WebElement ClearAll = driver.findElement(transactions.clearAllButton);
		ClearAll.click();
		AssertVerify(transactions.CategoriesOption.getText().trim(),"No Category Filter Set");	
		AssertVerify(VerifyLocatorIsDispalyed(transactions.filter1),false);		
		TestCaseStatus = "Passed";
	}
	

	@Test(priority = 16, enabled = true)
	public void C2411182_ClearAllCategories()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.CategoriesOption);
		transactions.CategoriesOption.click();
		Transactions.Categories categories=transactions.new Categories();
		categories.SelectAll.click();
		categories.Apply.click();
		Thread.sleep(2000);
		AssertVerify(transactions.CategoriesOption.getText().trim(),"Categories Selected (33)");
		WebElement clearAllSearch = driver.findElement(transactions.clearAllSearch);
		ScrollToElement(clearAllSearch);
		clearAllSearch.click();
		Thread.sleep(5000);
		AssertVerify(transactions.CategoriesOption.getText().trim(),"No Category Filter Set");
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 17, enabled = true)
	public void C2411182_SaveThisSearch()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		transactions.clearSavedSearch();
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys("-100");
		amount.ToAmount.sendKeys("100");
		amount.Apply.click();		
		transactions = new Transactions();
		String searchName = transactions.SaveThisSearch();
		System.out.println(searchName);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 18, enabled = true)
	public void C2411183_GroupByCategory()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		Thread.sleep(1000);
		ArrayList<HashMap> tableData = transactions.getnumberofRowsandamount();
		homePage.Logout.click();
		driver.quit();
		launchUrl();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage1 = new HomePage();		
		homePage1.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage1.clickSearchTransaction();		
		Transactions transactions1= new Transactions();
		transactions1.GroupResultsByCategory.click();		
		transactions1.verifyGroupByCategory(tableData);
		TestCaseStatus = "Passed";
	}	
	
	@Test(priority = 19, enabled = true)
	public void C2411184_EditCategory()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();			
		transactions.EditRow();
		Transactions.EditModal editModal = transactions.new EditModal();
		editModal.NewCategory.click();
		selectDropDownByVisibleText(editModal.NewCategory, "Adjustment");
		editModal.MemoInputField.sendKeys("Changing Category");
		editModal.Submit.click();		
		Thread.sleep(5000);
		String newCategory = driver.findElement(By.xpath("//*[@id='collapsible-txns']/div[1]/div[1]/div[1]/div[2]/span")).getText();
		AssertVerify(newCategory, "ADJUSTMENT");
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 20, enabled = true)
	public void C2411185_ExportTransactionsInCSVFormat()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		transactions.ExportOption.click();
		Transactions.ExportModal exportModal = transactions.new ExportModal();				
		Thread.sleep(5000);		
		ScrollToElement(exportModal.CSVFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/csv.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.CSVFormat), true);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 21, enabled = true)
	public void C2411186_ExportTransactionsInQBOFormat()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		transactions.ExportOption.click();
		Transactions.ExportModal exportModal = transactions.new ExportModal();
		//DownloadAndSaveReport(ReportTypes.QBOFormat);		
		Thread.sleep(5000);	
		ScrollToElement(exportModal.CSVFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/qbo.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.QBOFormat), true);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 22, enabled = true)
	public void C2411187_ExportTransactionsInQFXFormat()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		transactions.ExportOption.click();
		Transactions.ExportModal exportModal = transactions.new ExportModal();
		//DownloadAndSaveReport(ReportTypes.QFXFormat);		
		Thread.sleep(5000);		
		ScrollToElement(exportModal.CSVFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/qfx.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.QFXFormat), true);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 23, enabled = true)
	public void C2411188_ExportTransactionsInTabFormat()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		transactions.ExportOption.click();
		Transactions.ExportModal exportModal = transactions.new ExportModal();
		//DownloadAndSaveReport(ReportTypes.TabFormat);		
		Thread.sleep(5000);		
		ScrollToElement(exportModal.CSVFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/tab.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.TabFormat), true);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 24, enabled = true)
	public void C2411189_TransactionPageVerificationForCreditAndDebitCard()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimelabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		driver.quit();
		launchUrl();
		LoginApplication("TARGETACH25294", "Target22##");
		HomePage homePage1 = new HomePage();		
		homePage1.TransactionsLink.click();
		Thread.sleep(3000);			
		Transactions transactions1= new Transactions();
		WebElement transactionDescription = driver.findElement(transactions1.transactionDescription);
		AssertVerify(transactionDescription.isDisplayed(),true);
		AssertVerify(transactionDescription.getText(), Transactions.expectedtransacrtionDescription);
		ScrollToElement(transactions1.TimePeriodOption);
		transactions1.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimelabel2=transactions1.new AddTimeLabel(CardTypes.DebitCard);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 25, enabled = true)
	public void C2411190_NavigateToSpendAnalyzerFromTransactionPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();			
		transactions.SpendAnalyzer.click();
		Thread.sleep(5000);
		AssertVerify(driver.getCurrentUrl().contains("SpendAnalyzer"), true);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 26, enabled = true)
	public void C2411191_ExpectedListOfCategoriesAreDisplayedUnderCategoryList()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.CategoriesOption);
		transactions.CategoriesOption.click();
		Transactions.Categories categories = transactions.new Categories();
		ArrayList<String> actualListofCategories = transactions.getAllCategories();
		AssertVerify(actualListofCategories.size(), transactions.expectedListofCategories.size());
		AssertVerify(actualListofCategories.containsAll(transactions.expectedListofCategories), true);	
		TestCaseStatus = "Passed";
	}
	
	
	@Test(priority = 27, enabled = true)
	public void C2411192_FromDateIsGreaterThanToDate()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		String transactionDate = transactions.getDataForSearchInput("GetTransactionDate");
		String[] splitdata = transactionDate.split(",");
		System.out.println(DateValue(transactionDate));
		String year =splitdata[splitdata.length-1].trim();
		String month = splitdata[splitdata.length-2].split(" ")[0].trim();
		String date=splitdata[splitdata.length-2].split(" ")[1].trim();
		System.out.println(year);
		System.out.println(month);
		System.out.println(date);
		if(date.startsWith("0") == true) {
			date = date.replace("0","");
		}
		int ToDate=Integer.parseInt(date)-1;
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.CustomDateRangeOption.click();
		Transactions.CustomDateRangeForTime customdateRange=transactions.new CustomDateRangeForTime();		
		selectDropDownByVisibleText(customdateRange.FromYear, year);		
		selectDropDownByVisibleText(customdateRange.FromMonth, getFullMonth(month));		
		selectDropDownByVisibleText(customdateRange.FromDay, date);		
		selectDropDownByVisibleText(customdateRange.ToYear, year);		
		selectDropDownByVisibleText(customdateRange.ToMonth, getFullMonth(month));		
		selectDropDownByVisibleText(customdateRange.ToDay, String.valueOf(ToDate));
		customdateRange.Apply.click();
		Thread.sleep(2000);
		addTimeLabel.Apply.click();
		Thread.sleep(3000);
		AssertVerify(transactions.numberofTransactions(),0);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 28, enabled = true)
	public void C2411193_TransactionsFromDefaultToSpecificValue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		String transactionDate = transactions.getDataForSearchInput("GetTransactionDate");
		String[] splitdata = transactionDate.split(",");
		System.out.println(DateValue(transactionDate));
		String year =splitdata[splitdata.length-1].trim();
		String month = splitdata[splitdata.length-2].split(" ")[0].trim();
		String date=splitdata[splitdata.length-2].split(" ")[1].trim();
		System.out.println(year);
		System.out.println(month);
		System.out.println(date);
		if(date.startsWith("0") == true) {
			date = date.replace("0","");
		}		
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.CustomDateRangeOption.click();
		Transactions.CustomDateRangeForTime customdateRange=transactions.new CustomDateRangeForTime();		
		selectDropDownByVisibleText(customdateRange.ToYear, year);		
		selectDropDownByVisibleText(customdateRange.ToMonth, getFullMonth(month));		
		selectDropDownByVisibleText(customdateRange.ToDay, date);
		customdateRange.Apply.click();
		Thread.sleep(2000);
		addTimeLabel.Apply.click();
		Thread.sleep(3000);
		transactions.verifyDateIsWithinRange("", transactionDate);
		TestCaseStatus = "Passed";
	}
	

	
	
	
	
	@Test(priority = 29, enabled = true)
	public void C2411194_TransactionsCustomDateRange()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		String transactionDate = transactions.getDataForSearchInput("GetTransactionDate");
		String[] splitdata = transactionDate.split(",");
		System.out.println(DateValue(transactionDate));
		String year =splitdata[splitdata.length-1].trim();
		String month = splitdata[splitdata.length-2].split(" ")[0].trim();
		String date=splitdata[splitdata.length-2].split(" ")[1].trim();
		System.out.println(year);
		System.out.println(month);
		System.out.println(date);
		if(date.startsWith("0") == true) {
			date = date.replace("0","");
		}
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.CustomDateRangeOption.click();
		Transactions.CustomDateRangeForTime customdateRange=transactions.new CustomDateRangeForTime();		
		selectDropDownByVisibleText(customdateRange.FromYear, year);		
		selectDropDownByVisibleText(customdateRange.FromMonth, getFullMonth(month));		
		selectDropDownByVisibleText(customdateRange.FromDay, date);		
		customdateRange.Apply.click();
		Thread.sleep(2000);
		addTimeLabel.Apply.click();
		Thread.sleep(3000);
		transactions.verifyDateIsWithinRange(transactionDate, "");	
		TestCaseStatus = "Passed";
	}
	
	
	@Test(priority = 30, enabled = true)
	public void C2411196_TransactionFromAmountIsPositiveToAmountIsNegative()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys("100");
		amount.ToAmount.sendKeys("-100");
		amount.Apply.click();
		transactions = new Transactions();
		AssertVerify(transactions.numberofTransactions(), 0);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 31, enabled = true)
	public void C2411198_TransactionFromAmountIsGreatherThanToAmount()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys("100");
		amount.ToAmount.sendKeys("0");
		amount.Apply.click();
		transactions = new Transactions();
		AssertVerify(transactions.numberofTransactions(), 0);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 32, enabled = true)
	public void C2411199_TransactionFromAmountNonNumeric()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		//ScrollToElement(transactions.TimePeriodOption);
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys("abc");
		amount.ToAmount.sendKeys("xyz");
		AssertVerify(amount.FromAmount.getText().length(),0);		
		AssertVerify(amount.ToAmount.getText().length(),0);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 33, enabled = true)
	public void C2411214_DeleteTheSavedSearch()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		transactions.clearSavedSearch();
		transactions.TimePeriodOption.click();
		Transactions.AddTimeLabel addTimeLabel=transactions.new AddTimeLabel(CardTypes.CreditCard);
		addTimeLabel.AllHistory.click();		
		addTimeLabel.Apply.click();		
		ScrollToElement(transactions.AmountOption);
		transactions.AmountOption.click();
		Transactions.Amount amount = transactions.new Amount();
		amount.FromAmount.sendKeys("-100");
		amount.ToAmount.sendKeys("100");
		amount.Apply.click();		
		transactions = new Transactions();
		String searchName = transactions.SaveThisSearch();
		System.out.println(searchName);
		transactions.DeleThisSearch();
		VerifyLocatorIsDispalyed(transactions.savedSearchName);
		homePage.Home.click();
		homePage = new HomePage();
		homePage.Logout.click();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 34, enabled = true)
	public void C2411216_ExpandAndHideFunctionOnSavedSearch()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);		
		homePage.clickSearchTransaction();
		Transactions transactions= new Transactions();
		String attributeopen = transactions.TransactionResultsAttribute.getAttribute("class").toString();
		AssertVerify(attributeopen, "navicon-button plus open");
		transactions.TransactionsResultsexpander.click();	
		String attributeclose = transactions.TransactionResultsAttribute.getAttribute("class").toString();
		AssertVerify(attributeclose, "navicon-button plus");
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 35, enabled = true)
	public void C2411217_ExpandAndHideFunctionOnFilters()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);		
		homePage.clickSearchTransaction();
		Transactions transactions= new Transactions();
		String attributeopen = transactions.SavedSearchExpanderAttribute.getAttribute("class").toString();
		AssertVerify(attributeopen, "navicon-button plus open");
		transactions.SavedSearchExpanderButton.click();	
		String attributeclose = transactions.SavedSearchExpanderAttribute.getAttribute("class").toString();
		AssertVerify(attributeclose, "navicon-button plus");
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 36, enabled = true)
	public void C2411218_ExpandAndHideFunctionOnTransactionResults()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);		
		homePage.clickSearchTransaction();
		Transactions transactions= new Transactions();
		String attributeopen = transactions.FiltersExpanderAttribute.getAttribute("class").toString();
		AssertVerify(attributeopen, "navicon-button plus open");
		transactions.FiltersExpanderButton.click();	
		String attributeclose = transactions.FiltersExpanderAttribute.getAttribute("class").toString();
		AssertVerify(attributeclose, "navicon-button plus");
		TestCaseStatus = "Passed";
	}
	
	
	@Test(priority = 37, enabled = true)
	public void C2411201_SortByDateDescendingAndVerifyExportOrder()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.OrderByoption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.DateDescending.click();
		orderBy.Apply.click();
		ArrayList<LinkedHashMap> uiData = transactions.returnDatasToVerifyExportRecord();
		System.out.println(uiData);
		ScrollToElement(transactions.ExportOption);
		transactions.ExportOption.click();		
		Transactions.ExportModal exportModal = transactions.new ExportModal();				
		Thread.sleep(5000);		
		ScrollToElement(exportModal.TabFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/tab.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		ArrayList<LinkedHashMap> exportData = ReadFiles("	", FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.TabFormat), true);
		compareUIAndExportData(exportData, uiData);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 38, enabled = true)
	public void C2411202_SortByDateDescendingAndVerifyExportOrder()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.OrderByoption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.DateAscending.click();
		orderBy.Apply.click();
		ArrayList<LinkedHashMap> uiData = transactions.returnDatasToVerifyExportRecord();
		System.out.println(uiData);
		ScrollToElement(transactions.ExportOption);
		transactions.ExportOption.click();		
		Transactions.ExportModal exportModal = transactions.new ExportModal();				
		Thread.sleep(5000);		
		ScrollToElement(exportModal.TabFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/tab.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		ArrayList<LinkedHashMap> exportData = ReadFiles("	", FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.TabFormat), true);
		compareUIAndExportData(exportData, uiData);
		TestCaseStatus = "Passed";
	}
	

	@Test(priority = 39, enabled = true)
	public void C2411203_SortByDateDescendingAndVerifyExportOrder()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.OrderByoption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.Amount.click();
		orderBy.Apply.click();
		ArrayList<LinkedHashMap> uiData = transactions.returnDatasToVerifyExportRecord();
		System.out.println(uiData);
		ScrollToElement(transactions.ExportOption);
		transactions.ExportOption.click();		
		Transactions.ExportModal exportModal = transactions.new ExportModal();				
		Thread.sleep(5000);		
		ScrollToElement(exportModal.TabFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/tab.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		ArrayList<LinkedHashMap> exportData = ReadFiles("	", FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.TabFormat), true);
		compareUIAndExportData(exportData, uiData);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 40, enabled = true)
	public void C2411204_SortByNameAndVerifyExportOrder()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.OrderByoption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.Name.click();
		orderBy.Apply.click();
		ArrayList<LinkedHashMap> uiData = transactions.returnDatasToVerifyExportRecord();
		System.out.println(uiData);
		ScrollToElement(transactions.ExportOption);
		transactions.ExportOption.click();		
		Transactions.ExportModal exportModal = transactions.new ExportModal();				
		Thread.sleep(5000);		
		ScrollToElement(exportModal.TabFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/tab.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		ArrayList<LinkedHashMap> exportData = ReadFiles("	", FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.TabFormat), true);
		compareUIAndExportData(exportData, uiData);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 41, enabled = true)
	public void C2411225_CheckExportResultsInCSV()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		clearExportFiles();
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();		
		Transactions transactions= new Transactions();
		ScrollToElement(transactions.OrderByoption);
		transactions.OrderByoption.click();
		Transactions.OrderBy orderBy=transactions.new OrderBy();
		orderBy.Name.click();
		orderBy.Apply.click();
		ArrayList<LinkedHashMap> uiData = transactions.returnDatasToVerifyExportRecord();
		System.out.println(uiData);
		ScrollToElement(transactions.ExportOption);
		transactions.ExportOption.click();		
		Transactions.ExportModal exportModal = transactions.new ExportModal();				
		Thread.sleep(5000);		
		ScrollToElement(exportModal.CSVFormat);
		Thread.sleep(5000);		
		Runtime.getRuntime().exec("./libs/csv.exe");
		String FileName = getLatestFilefromDir();	
		System.out.println(FileName);
		ArrayList<LinkedHashMap> exportData = ReadFiles(",", FileName);
		AssertVerify(FileName.startsWith("Transactions_"),true);
		AssertVerify(FileName.endsWith(ReportTypes.CSVFormat), true);
		compareUIAndExportData(exportData, uiData);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 42, enabled = true)
	public void C2411210_TimePeriodForSpendAnalyzer()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();
		Transactions transactions = new Transactions();
		transactions.SpendAnalyzer.click();
		SpendAnalyzer spendAnalyzer = new SpendAnalyzer();
		spendAnalyzer.TimePeriodButton.click();
		SpendAnalyzer.TimePeriod timePeriod =spendAnalyzer.new TimePeriod();
		timePeriod.FullHistory.click();
		timePeriod.Apply.click();
		spendAnalyzer = new SpendAnalyzer();
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 43, enabled = true)
	public void C2411221_FullHistorySearchCanNotBeDeleted()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSearchTransaction();
		Transactions transactions = new Transactions();
		transactions.SpendAnalyzer.click();
		SpendAnalyzer spendAnalyzer = new SpendAnalyzer();
		AssertVerify(spendAnalyzer.LockIcon.isDisplayed(), true);
		AssertVerify(spendAnalyzer.LockText.getText(), "Locked");		
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 44, enabled = true)
	public void C2411213_SaveSearchOnSpendAnalyzerPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSpendAnalyzer();
		SpendAnalyzer spendAnalyzer = new SpendAnalyzer();
		spendAnalyzer.CategoriesOption.click();
		SpendAnalyzer.Categories categories = spendAnalyzer.new Categories();
		categories.ClearAll.click();
		categories.Apply.click();
		AssertVerify(spendAnalyzer.CategoriesOption.getText().trim(),"No Category Filter Set");
		spendAnalyzer.BarChart.click();
		AssertVerify(spendAnalyzer.errorMessage(),spendAnalyzer.errorMessageOnNoCategoriesSelection);
		spendAnalyzer.PieChart.click();
		AssertVerify(spendAnalyzer.errorMessage(),spendAnalyzer.errorMessageOnNoCategoriesSelection);
		TestCaseStatus = "Passed";
	}
	
	@Test(priority = 43, enabled = true)
	public void C2411220_VerifySpendAnalyzerPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSpendAnalyzer();
		SpendAnalyzer spendAnalyzer = new SpendAnalyzer();
		AssertVerify(spendAnalyzer.SavedSearchName.getText(), "Full History");
		spendAnalyzer.CategoriesOption.click();
		SpendAnalyzer.Categories categories = spendAnalyzer.new Categories();
		ArrayList<String> listofCategories = spendAnalyzer.SelectAvailableCategories();
		Thread.sleep(2000);
		spendAnalyzer.TimePeriodButton.click();
		SpendAnalyzer.TimePeriod timePeriod =spendAnalyzer.new TimePeriod();
		timePeriod.FullHistory.click();
		timePeriod.Apply.click();
		AssertVerify(spendAnalyzer.PieChart.isDisplayed(), true);
		AssertVerify(spendAnalyzer.BarChart.isDisplayed(), true);
		WebElement element = driver.findElement(spendAnalyzer.chartArea);
		AssertVerify(element.isDisplayed(),true);
		WebElement element1 = driver.findElement(spendAnalyzer.transactionArea);
		AssertVerify(element1.isDisplayed(),true);
		ArrayList<LinkedHashMap> uiData = spendAnalyzer.returnDatasToVerifyExportRecord();
		ArrayList<LinkedHashMap> finalData = spendAnalyzer.verifyChartData(uiData, listofCategories);
		System.out.println(finalData);
		spendAnalyzer.topspendingsingraph(finalData);
		TestCaseStatus = "Passed";
	}

	@Test(priority = 44, enabled = true)
	public void C2411213_SaveSearchAndDeleteSearch()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.TransactionsLink.click();
		Thread.sleep(3000);			
		homePage.clickSpendAnalyzer();
		SpendAnalyzer spendAnalyzer = new SpendAnalyzer();
		AssertVerify(spendAnalyzer.SavedSearchName.getText(), "Full History");
		spendAnalyzer.CategoriesOption.click();
		SpendAnalyzer.Categories categories = spendAnalyzer.new Categories();
		ArrayList<String> listofCategories = spendAnalyzer.SelectAvailableCategories();
		Thread.sleep(2000);
		spendAnalyzer.TimePeriodButton.click();
		SpendAnalyzer.TimePeriod timePeriod =spendAnalyzer.new TimePeriod();
		timePeriod.Last6Months.click();
		timePeriod.Apply.click();
		ScrollToElement(spendAnalyzer.SavedSearchExpanderButton);
		spendAnalyzer.SaveThisSearch.click();
		SpendAnalyzer.SaveThisSearchConfirmModal savesearch = spendAnalyzer.new SaveThisSearchConfirmModal();
		savesearch.SaveSearchName.sendKeys("Last6Months");
		savesearch.Save.click();
		Thread.sleep(10000);
		AssertVerify(driver.findElement(spendAnalyzer.customsearchName).getText(), "Last6Months");
		String numberofsearches = driver.findElement(spendAnalyzer.numberofSavedSearches).getText();
		AssertVerify(numberofsearches, "(2)");
		WebElement deleteButton=driver.findElement(spendAnalyzer.deleteCustomSearch);
		deleteButton.click();
		Thread.sleep(5000);
		AssertVerify(VerifyElementIsDispalyed(deleteButton),false);
		TestCaseStatus = "Passed";		
	}
	
	@AfterMethod
	public void afterMethod() throws ATUTestRecorderException {		
		endTestcase();
		endResult();
		record.stop();
		closeBrowsers();
	}

}
