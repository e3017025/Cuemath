package POM_Test;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.HashMap;

import org.openqa.selenium.browserlaunchers.Sleeper;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.MediaEntityBuilder;
import com.testrail.connection.APIException;

import POM_Classes.BaseClass;
import POM_Classes.EnrollNowPage;
import POM_Classes.ForgotUserName;
import POM_Classes.HomePage;
import POM_Classes.PasswordPage;
import POM_Classes.SecurityQustionPage;
import POM_Classes.UserNamePage;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class LoginTest extends BaseClass {
	
	/*@BeforeSuite
	public void reports() {
		clearreports();
	}*/

	@BeforeTest
	public void initializestatus() {
		TestCaseStatus = "FAILED";
		record = null;
	}
	
	@Test(priority = 0,enabled = true)
	public void C2410975_TC0001_Login_UserName_All_Uppercase() throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		//String TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());		
		LoginApplication(username.toUpperCase(), password);
		HomePage homePage = new HomePage();		
		homePage.Click(homePage.Logout);
	}
	
	@Test(priority = 1,enabled = true)
	public void C2410976_LOGIN_TC0002_Login_Username_All_Lowercase() throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		//String TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(username.toLowerCase(), password);
		HomePage homePage = new HomePage();		
		homePage.Click(homePage.Logout);		
	}

	@Test(priority = 2,enabled = true)
	public void C2410977_LOGIN_TC0003_Login_username_upper_and_lowercase() throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		//String TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(username, password);
		HomePage homePage = new HomePage();		
		homePage.Click(homePage.Logout);		
	}
	
	
	/*@Test(priority = 3,enabled = true)
	public void C2411692_Enroll_Account_Which_IS_Already_Enrolled() throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		//String TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		UserNamePage usernamePage = new UserNamePage();
	    usernamePage.EnrollNowButton.click();
	    HashMap<String,String> testdata =ReadExcel("Sheet1", 1);
	    ForgotUserName forgotusername = new ForgotUserName();	    
	    forgotusername.EnterCardNumber(testdata.get("CardNumber"));
	    EnrollNowPage enrollNowPage = new EnrollNowPage();
	    enrollNowPage.NameOnCard.sendKeys(testdata.get("Name On Card"));
	    enrollNowPage.Last4DigitsOfSSN.sendKeys(testdata.get("SSN"));
	    enrollNowPage.CVV.sendKeys(testdata.get("CVV"));
	    enrollNowPage.CardHolderSince.sendKeys(testdata.get("Card Holder Since"));
	    enrollNowPage.Next.click();
	    Thread.sleep(5000);
	    AssertVerify(enrollNowPage.ErrorMessage().toString(),"Account Number is currently enrolled.");
				
	}*/
	
	/*@Test(priority = 4,enabled = true)
	public void C2411699_SessionExpired() throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		//String TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		LoginApplication(username, password);				
		HomePage homePage = new HomePage();		
		Sleeper sleep = new Sleeper();
		sleep.sleepTightInSeconds(1500);
		homePage.Click(homePage.MyAlerts);
		AssertVerify(homePage.ErrorMessage().toString(),
				homePage.expectedsessionExpiredMessage.toString());		
	}*/
	
	@Test(priority = 5,enabled = true)
	public void C2411701_LoginWithInvalidUsername() throws IOException, InterruptedException, ATUTestRecorderException {
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(unsuccessfulusername);
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		securityquestionPage.errorMessage();
		AssertVerify(securityquestionPage.actualerrorMessage.toString(),
				securityquestionPage.expectederrorMessage.toString());		
	}

	@Test(priority = 6, enabled = true)
	public void C2411702_SaveUserNameOnLogin() throws IOException, InterruptedException, ATUTestRecorderException {
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.SaveUsername(BaseClass.username);
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		securityquestionPage.securityAnswerValidator();
		PasswordPage passwordPage = new PasswordPage();
		passwordPage.passwordValidator(BaseClass.password);
		HomePage homePage = new HomePage();		
		homePage.Logout.click();
		Thread.sleep(15000);
		usernamePage = new UserNamePage();
		usernamePage.SignInButton.click();
		securityquestionPage = new SecurityQustionPage();
		securityquestionPage.securityAnswerValidator();
		passwordPage = new PasswordPage();
		passwordPage.passwordValidator(BaseClass.password);
		homePage = new HomePage();		
		homePage.Logout.click();
	}
	
	
	@Test(priority = 7, enabled = true)
	public void C2411708_InvalidPassword() throws IOException, InterruptedException, ATUTestRecorderException {
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(username);
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();		
		securityquestionPage.securityAnswerValidator();
		PasswordPage passwordPage = new PasswordPage();
		passwordPage.Password.sendKeys("InvalidPassword");
		passwordPage.SignInButton.click();
		Thread.sleep(5000);
		AssertVerify(passwordPage.ErrorMessage().toString(),
				passwordPage.invalidpasswordexpectederrorMessage.toString());	
	}
	
	@Test(priority = 8, enabled = true)
	public void C2411705_RSAFlowOnPrivateDevice() throws IOException, InterruptedException, ATUTestRecorderException {
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(BaseClass.username);
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		securityquestionPage.PrivateDeviceYesIndicator.click();
		securityquestionPage.securityAnswerValidator();
		PasswordPage passwordPage = new PasswordPage();
		passwordPage.passwordValidator(BaseClass.password);
		HomePage homePage = new HomePage();		
		homePage.Logout.click();
		Thread.sleep(15000);
		usernamePage = new UserNamePage();
		usernamePage.UserName.sendKeys(username);
		usernamePage.SignInButton.click();
		passwordPage = new PasswordPage();
		Thread.sleep(10000);		
		usernamePage.EnterUsername(BaseClass.username);		
		if(driver.getCurrentUrl().contains("Security")) {
			test.fail("Navigated to Security Question Page on Private Device Login", MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			}
		if(driver.getCurrentUrl().contains("Password")) {
			test.pass("Not Navigated to Security Question Page on Private Device Login", MediaEntityBuilder.createScreenCaptureFromPath(captureScreen()).build());
			passwordPage.passwordValidator(BaseClass.password);
		}		
	}

	
	
	
	/*
	 * C2411709_EnrollNow_Secondary_Account is returning Internal Server Error 500.
	 */
	/*
	@Test(priority = 9, enabled = true)
	public void C2411709_EnrollNow_Secondary_Account() throws IOException, InterruptedException, ATUTestRecorderException {
		ATUTestRecorder record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnrollNowButton.click();
		ForgotUserName forgotusername = new ForgotUserName();	    
		forgotusername.EnterCardNumber("5859750001268169");
		forgotusername.BeginForgotUserName.click();		
		Thread.sleep(5000);
		AssertVerify(forgotusername.ErrorMessage().toString(),
				forgotusername.expectedErrorMessageforSecondAccountEnrollment);	
	}

	@Test(priority = 0,enabled = true)
	public void ChangeUsername() throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		//String TestCaseId = "8789740";
		ATUTestRecorder record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(BaseClass.username.toUpperCase());
		//SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		//securityquestionPage.securityAnswerValidator();
		PasswordPage passwordPage = new PasswordPage();
		passwordPage.passwordValidator(BaseClass.password);
		Thread.sleep(30000);
		HomePage homePage = new HomePage();
		homePage.ClickSettingsAndHelp();
		Thread.sleep(15000);
		SettingsAndHelp settingandhelp = new SettingsAndHelp();
		settingandhelp.Click(settingandhelp.ChangeUsername);
		SettingsAndHelp.ChangeUserName changeusername = settingandhelp.new ChangeUserName();
		String successMessage = changeusername.changeusername(username);
		AssertVerify(successMessage, changeusername.expectedsuccessMessage);
		homePage.Logout();

	}*/
	

	/*
	@Test(priority = 11)
	public void LoginWithSavedUserName() throws IOException, InterruptedException, ATUTestRecorderException {
		ATUTestRecorder record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), true);
		record.start();
		launchUrl();
		startResult();		
		startTestCase("Login application with Saved UserName");
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.ValidateSavedUsername();
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		securityquestionPage.securityAnswerValidator();
		PasswordPage passwordPage = new PasswordPage();
		passwordPage.passwordValidator(BaseClass.password);
		HomePage homePage = new HomePage();
		homePage.ClickMyAlerts();
		homePage.ClickSettingsAndHelp();
		homePage.Logout();
	}	

	@Test(priority = 4)
	public void ForgotPassword() throws ATUTestRecorderException, IOException, InterruptedException {
		ATUTestRecorder record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();
		launchUrl();
		startResult();		
		startTestCase("Click Forgot Password and Retrieve Password");
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(username);
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		securityquestionPage.securityAnswerValidator();
		PasswordPage passwordPage = new PasswordPage();
		passwordPage.ForgotPassword.click();
		PasswordPage.PasswordConfirmationModal passwordconfirmationModal = passwordPage.new PasswordConfirmationModal();
		passwordconfirmationModal.CancelButton.click();
		
	}

	@Test(priority = 5)
	public void ClickHelpIconAndEnterSecurityAnswerAndPassword()
			throws IOException, InterruptedException, ATUTestRecorderException {
		ATUTestRecorder record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), true);
		record.start();
		launchUrl();
		startResult();		
		startTestCase("ClickHelpIconAndEnterSecurityAnswerAndPassword");
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(username);
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		securityquestionPage.SecurityQuestionHelpIcon.click();
		SecurityQustionPage.HelpModal securityquestionhelpModal = securityquestionPage.new HelpModal();
		Thread.sleep(2000);
		securityquestionPage.securityAnswerValidator();
		PasswordPage passwordPage = new PasswordPage();
		passwordPage.PasswordHelpIcon.click();
		PasswordPage.HelpModal passwordhelpModal = passwordPage.new HelpModal();
		Thread.sleep(2000);
		passwordPage.passwordValidator(BaseClass.password);
		HomePage homePage = new HomePage();
		homePage.ClickMyAlerts();
		homePage.ClickSettingsAndHelp();
		homePage.Logout();
		
	}

	@Test(priority = 6)
	public void BrokenLinkOnUserNamePage() throws IOException, InterruptedException, ATUTestRecorderException {
		launchUrl();
		startResult();		
		startTestCase("Broken Link Test on UserName Page");
		brokenLink();		
	}

	@Test(priority = 7)
	public void BrokenLinkOnSecurityQuestionPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		launchUrl();
		startResult();		
		startTestCase("Broken Link Test on SecurityQuestion Page");
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(BaseClass.username);
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		brokenLink();
	}

	@Test(priority = 8)
	public void BrokenLinkOnPasswordPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException {
		launchUrl();
		startResult();		
		startTestCase("Broken Link Test on Password Page");
		UserNamePage usernamePage = new UserNamePage();
		usernamePage.EnterUsername(BaseClass.username);
		SecurityQustionPage securityquestionPage = new SecurityQustionPage();
		securityquestionPage.securityAnswerValidator();
		PasswordPage passwordPage = new PasswordPage();
		brokenLink();
	}*/
	
	
	
	@AfterMethod
	public void afterMethod() throws ATUTestRecorderException {		
		endTestcase();
		endResult();
		record.stop();
		closeBrowsers();
	}

}
