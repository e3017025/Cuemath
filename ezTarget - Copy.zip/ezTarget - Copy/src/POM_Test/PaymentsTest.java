package POM_Test;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testrail.connection.APIException;

import POM_Classes.BaseClass;
import POM_Classes.CurrentAutoPay;
import POM_Classes.DeletePaymentAccounts;
import POM_Classes.HomePage;
import POM_Classes.MakeOneTimePayment;
import POM_Classes.ManageAutoPay;
import POM_Classes.ManagePaymentAccounts;
import POM_Classes.Payments;
import POM_Classes.Payments.CancelPayment;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class PaymentsTest extends BaseClass {

	@BeforeSuite
	public void reports() {
		clearreports();
	}

	@BeforeTest
	public void initializestatus() {
		TestCaseStatus = "FAILED";
		record = null;
	}
	
	@Test(priority = 0, enabled = false)
	public void C2410978_VerifyListOfOptionsAvailableUnderPaymentsTab()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.Payments.click();
		AssertVerify(driver.findElement(homePage.paymentsSummary).getAttribute("title"),"Payment Summary");
		AssertVerify(driver.findElement(homePage.makeOneTimePayment).getAttribute("title"),"Make a One-Time Payment");
		AssertVerify(driver.findElement(homePage.managePaymentAccounts).getAttribute("title"),"Manage Payment Accounts");
		AssertVerify(driver.findElement(homePage.manageautopay).getAttribute("title"),"Manage Auto Pay");
		TestCaseStatus = "Passed";	
	}
	
	@Test(priority = 1, enabled = false)
	public void C2410979_VerifyListOfOptionsInPaymentSummaryPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Payments payments= new Payments();
		AssertVerify(payments.LookingForSomething.isDisplayed(), true);
		AssertVerify(payments.ModifyAutoPay.isDisplayed(), true);
		AssertVerify(payments.MakeOneTimePayment.isDisplayed(), true);
	}
	
	@Test(priority = 2, enabled = false)
	public void C2410980_VerifyListOfFilterOptionOptionsInPaymentSummaryPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Payments payments= new Payments();
		AssertVerify(payments.FiltersExpanderButton.isDisplayed(),true);
		AssertVerify(payments.FiltersTitle.isDisplayed(),true);
		AssertVerify(payments.FiltersHelpIcon.isDisplayed(),true);
		AssertVerify(payments.DateLabel.isDisplayed(),true);
		AssertVerify(payments.DateOption.isDisplayed(),true);
		AssertVerify(payments.AmountLabel.isDisplayed(),true);
		AssertVerify(payments.AmountOption.isDisplayed(),true);
		AssertVerify(payments.OrderBylabel.isDisplayed(),true);
		AssertVerify(payments.OrderByoption.isDisplayed(),true);
		AssertVerify(payments.PaymentStatusLabel.isDisplayed(),true);
		AssertVerify(payments.PaymentStatusOption.isDisplayed(),true);
	
	}
	
	@Test(priority = 3, enabled = false)
	public void C2410981_VerifyListOfFilterOptionOptionsInPaymentSummaryPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Payments payments= new Payments();
		ScrollToElement(payments.DateOption);
		payments.PaymentStatusOption.click();
		Payments.PaymentStatus paymentStatus = payments.new PaymentStatus();
		ArrayList<String> actualListofPaymentStatus = payments.listofPaymentStatus();
		System.out.println(actualListofPaymentStatus);
		AssertVerify(actualListofPaymentStatus.size(),payments.expectedListofPaymentStatus.size());
		AssertVerify(actualListofPaymentStatus.containsAll(payments.expectedListofPaymentStatus),true);
	}
	
	@Test(priority = 4, enabled = false)
	public void C2411020_CancelOnMakePaymentStep1()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus = homePage.AutoPay.getText();		
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		AssertVerify(makeonetimePayment.Step1.getText(),makeonetimePayment.expectedStep1Text);
		if(autoPayStatus.equalsIgnoreCase("Enrolled")) {
			AssertVerify(makeonetimePayment.AutoPayEnabledWarningText.getText().trim(),makeonetimePayment.ExpectedAutoPayWarningText);
		}
		makeonetimePayment.Cancel.click();
		payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 5, enabled = false)
	public void C2411021_CancelOnMakePaymentStep2()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();		
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();		
		AssertVerify(amountselection.Step2.getText(),amountselection.expectedStep2Text);
		AssertVerify(amountselection.AmountPreText.getText().trim(),amountselection.expectedPreText);
		amountselection.Cancel.click();
		payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 6, enabled = false)
	public void C2411022_CancelOnMakePaymentStep3()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		//AssertVerify(dateSelection.PaymentPreText.getText(),dateSelection.expectedPreText);
		AssertVerify(dateSelection.PaymentPreText.getText(),dateSelection.expectedPreText);
		Calendar now = Calendar.getInstance();
		Select selectedYear= new Select(dateSelection.Year);
		Select selectedMonth= new Select(dateSelection.Month);
		Select selectedDay= new Select(dateSelection.Day);
		AssertVerify(dateSelection.Step3.getText(),dateSelection.expectedStep3Text);
		AssertVerify(selectedYear.getFirstSelectedOption().getText().toString(), Integer.toString((now.get(Calendar.YEAR))));
		AssertVerify(selectedMonth.getFirstSelectedOption().getText().toString(), new SimpleDateFormat("MMMM").format(now.getTime()));
		AssertVerify(selectedDay.getFirstSelectedOption().getText().toString(), Integer.toString((now.get(Calendar.DATE))));
		dateSelection.Cancel.click();
		payments= new Payments();
		homePage.Logout.click();
	}

	
	@Test(priority = 7, enabled = false)
	public void C2411023_CancelOnMakePaymentStep4()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		AssertVerify(dateSelection.PaymentPreText.getText(),dateSelection.expectedPreText);
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		//String Month = "September";
		//String Day = "1";
		payonFuture =getFutureDate(payonFuture, 20);
		String Month=payonFuture.split("-")[0];
		String Day=payonFuture.split("-")[1];
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		selectedDay= new Select(dateSelection.Day);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		System.out.println("Month:"+selectedMonth.getFirstSelectedOption().getText());
		System.out.println("Day:"+selectedDay.getFirstSelectedOption().getText());
		AssertVerify(dateSelection.Step3.getText(),dateSelection.expectedStep3Text);
		AssertVerify(selectedYear.getFirstSelectedOption().getText().toString(), Integer.toString((now.get(Calendar.YEAR))));
		AssertVerify(selectedMonth.getFirstSelectedOption().getText().toString(), Month);
		AssertVerify(selectedDay.getFirstSelectedOption().getText().toString(), Day);
		//String PayOn=new SimpleDateFormat("MMM").format(now.getTime())+" "+(Integer.toString((now.get(Calendar.DATE)-1)))+", "+(Integer.toString((now.get(Calendar.YEAR))));
		System.out.println("PayOn: "+PayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	    //System.out.println(CardNumber.substring(CardNumber.length()-(CardNumber.length()-3),CardNumber.length()-7));
		String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.Cancel.click();
		payments= new Payments();
		homePage.Logout.click();
	}
	
	
	@Test(priority = 8, enabled = false)
	public void C2411046_CreateRecurringPlanWithAmountZero()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);
		manageAutoPay.Next.click();
		ManageAutoPay.ManageAutoPayAmountSelection amountSelection = manageAutoPay.new ManageAutoPayAmountSelection();
		amountSelection.FixedAmountRadioButton.click();
		WebElement FixedAmountInputText = amountSelection.getFixedAmount();
		FixedAmountInputText.clear();
		FixedAmountInputText.sendKeys("0");	
		AssertVerify(amountSelection.Next.isEnabled(),false);		
		homePage.Logout.click();
	}
	
	@Test(priority = 9, enabled = false)
	public void C2411036_CreateRecurringPlanWithAmountNegative()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);
		manageAutoPay.Next.click();
		ManageAutoPay.ManageAutoPayAmountSelection amountSelection = manageAutoPay.new ManageAutoPayAmountSelection();
		amountSelection.FixedAmountRadioButton.click();
		WebElement FixedAmountInputText = amountSelection.getFixedAmount();
		FixedAmountInputText.clear();
		FixedAmountInputText.sendKeys("-34");	
		AssertVerify(amountSelection.Next.isEnabled(),false);		
		homePage.Logout.click();
	}
	
	@Test(priority = 10, enabled = false)
	public void C2411031_CancelRecurringOnStep1()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);
		AssertVerify(manageAutoPay.PaymentInformationTitle.getText(), manageAutoPay.expectedPaymentInformationTitle);
		String PaymentInformationNote = manageAutoPay.PaymentInformationNote.getText().trim().replaceAll("\\n", "");
		PaymentInformationNote = PaymentInformationNote.replaceAll("\\r", "");
		System.out.println(PaymentInformationNote);
		AssertVerify(PaymentInformationNote, manageAutoPay.expectedPaymentInformationNote);
		AssertVerify(manageAutoPay.AutoPayPreText.getText(), manageAutoPay.ExpectedAutoPayPreText);
		AssertVerify(manageAutoPay.Step1.getText().toString().trim(), manageAutoPay.expectedStep1Text);
		manageAutoPay.ReturnPaymentSummary.click();
		Payments payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 11, enabled = false)
	public void C2411032_CancelRecurringOnStep2()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);
		manageAutoPay.Next.click();
		ManageAutoPay.ManageAutoPayAmountSelection amountSelection = manageAutoPay.new ManageAutoPayAmountSelection();
		AssertVerify(amountSelection.Step2.getText().toString().trim(), amountSelection.expectedStep2Text);
		amountSelection.FixedAmountRadioButton.click();
		WebElement FixedAmountInputText = amountSelection.getFixedAmount();
		FixedAmountInputText.clear();
		FixedAmountInputText.sendKeys("4");
		amountSelection.ReturnPaymentSummary.click();
		Payments payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 12, enabled = false)
	public void C2411033_CancelRecurringOnStep3()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);
		manageAutoPay.Next.click();
		ManageAutoPay.ManageAutoPayAmountSelection amountSelection = manageAutoPay.new ManageAutoPayAmountSelection();
		amountSelection.FixedAmountRadioButton.click();
		WebElement FixedAmountInputText = amountSelection.getFixedAmount();
		FixedAmountInputText.clear();
		FixedAmountInputText.sendKeys("4");
		amountSelection.Next.click();
		ManageAutoPay.ManageAutoPayDateSelection manageAutoPayDateSelection = manageAutoPay.new ManageAutoPayDateSelection();
		AssertVerify(manageAutoPayDateSelection.Step3.getText().toString().trim(), manageAutoPayDateSelection.expectedStep3Text);
		AssertVerify(manageAutoPayDateSelection.PaymentDueDate.getText().toString().trim(), "Payment Due Date: "+PaymentDue);
		AssertVerify(manageAutoPayDateSelection.PaymentPreText.getText().toString().trim(), manageAutoPayDateSelection.expectedPreText);
		manageAutoPayDateSelection.ReturnPaymentSummary.click();
		Payments payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 13, enabled = false)
	public void C2411034_CancelRecurringOnStep4()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);
		manageAutoPay.Next.click();
		ManageAutoPay.ManageAutoPayAmountSelection amountSelection = manageAutoPay.new ManageAutoPayAmountSelection();
		amountSelection.FixedAmountRadioButton.click();
		WebElement FixedAmountInputText = amountSelection.getFixedAmount();
		FixedAmountInputText.clear();
		FixedAmountInputText.sendKeys("4");
		amountSelection.Next.click();
		ManageAutoPay.ManageAutoPayDateSelection manageAutoPayDateSelection = manageAutoPay.new ManageAutoPayDateSelection();
		manageAutoPayDateSelection.Next.click();
		ManageAutoPay.ManageAutoPayReview manageAutoPayReviewSelection = manageAutoPay.new ManageAutoPayReview();
		manageAutoPayReviewSelection.ReturnPaymentSummary.click();
		Payments payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 14, enabled = false)
	public void C2410986_CancelRecurringOnStep4()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);
		Select selectedAccount=new Select(manageAutoPay.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();	
		manageAutoPay.Next.click();
		ManageAutoPay.ManageAutoPayAmountSelection amountSelection = manageAutoPay.new ManageAutoPayAmountSelection();
		amountSelection.FixedAmountRadioButton.click();
		WebElement FixedAmountInputText = amountSelection.getFixedAmount();
		FixedAmountInputText.clear();
		String paymentamount="4";
		FixedAmountInputText.sendKeys(paymentamount);
		amountSelection.Next.click();
		ManageAutoPay.ManageAutoPayDateSelection manageAutoPayDateSelection = manageAutoPay.new ManageAutoPayDateSelection();
		manageAutoPayDateSelection.Next.click();
		ManageAutoPay.ManageAutoPayReview manageAutoPayReviewSelection = manageAutoPay.new ManageAutoPayReview();
		System.out.println(driver.findElement(manageAutoPayReviewSelection.cardendingDigit).getText().trim());
		String enddigit=driver.findElement(manageAutoPayReviewSelection.cardendingDigit).getText().trim();
		String last4digits = enddigit.substring(enddigit.length()-4, enddigit.length());
		System.out.println(last4digits);
		AssertVerify(manageAutoPayReviewSelection.CardNumber.getText(), "Card: XXXX-XXXX-XXXX-"+last4digits);
		AssertVerify(manageAutoPayReviewSelection.PayFromAccount.getText(),"Pay From: "+payFrom);
		AssertVerify(manageAutoPayReviewSelection.PaymentAmount.getText().trim(),"$"+paymentamount+".00");
		AssertVerify(manageAutoPayReviewSelection.PlanTypeValue.getText(),"Plan Type: Fixed Monthly");
		AssertVerify(manageAutoPayReviewSelection.PaymentDueDate.getText().toString().trim(), "Payment Due Date: "+PaymentDue);
		AssertVerify(manageAutoPayReviewSelection.RecurringpaymentPreText.getText().toString().trim(),manageAutoPayReviewSelection.expectedRecurringPaymentPreText);
	    String expectedRecurringPaymentPreTextFixed = "Your payment will either be the fixed payment amount, or the minimum payment due as indicated on your monthly statement, whichever is greater, regardless of other payments made during the month. If the fixed payment you�ve scheduled is less than your minimum due, we�ll automatically process a payment for the minimum due. If your account is past due, you may be responsible for making an additional payment to bring the account current. If your current balance is less than the fixed payment amount at the time the payment is made, only the current balance will be withdrawn. By selecting �Save Auto Pay�, you authorize us to automatically transfer your monthly amount from your \""+payFrom+"\" bank account as a payment to your REDcard account ending in "+last4digits+".  These transfers will be automatically processed each month on your payment due date until you cancel this authorization.  You may cancel this authorization in the Manage Auto Pay section of this website, by calling us at 1-800-394-1829, or by writing to us at Target Card Services, P.O. Box 673, Minneapolis, MN 55440-9285. You should print a copy of this authorization for your records.";
	    //String expectedRecurringPaymentPreTextOthers="By selecting �Save Auto Pay�, you authorize us to automatically transfer your monthly amount from your "+"\""+payFrom+"\" bank account as a payment to your REDcard account ending in "+last4digits+".  These transfers will be automatically processed each month on your payment due date until you cancel this authorization.  You may cancel this authorization in the Manage Auto Pay section of this website, by calling us at 1-800-394-1829, or by writing to us at Target Card Services, P.O. Box 673, Minneapolis, MN 55440-9285. You should print a copy of this authorization for your records.";
	    String ReviewPreText=manageAutoPayReviewSelection.ReviewPreText.getText().trim();
	    ReviewPreText = ReviewPreText.replaceAll("\\r", "");
	    ReviewPreText = ReviewPreText.replaceAll("\\n", "");
		AssertVerify(ReviewPreText,expectedRecurringPaymentPreTextFixed);
		manageAutoPayReviewSelection.ReturnPaymentSummary.click();
		Payments payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 15, enabled = false)
	public void C2411000_NavigateToAutoPay()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);		
		homePage.Logout.click();
	}

	
	@Test(priority = 16, enabled = false)
	public void C2410999_NavigateToOnetimePayment()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.makeOneTimePayment).click();
		Thread.sleep(10000);
		MakeOneTimePayment makeOneTimePayment = new MakeOneTimePayment();		
		homePage.Logout.click();
	}
	
	@Test(priority = 17, enabled = false)
	public void C2410986_FromAmountIsGreaterThanToAmount()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Payments payments= new Payments();
		payments.AmountOption.click();
		Payments.Amount amount = payments.new Amount();
		String fromAmount= driver.findElement(By.xpath("id('main')/div[@class='col-65']/div[@class='module module-dark']/article[@class='module-light module-border accordion']/div[1]/div[@class='grid list-item']/div[@class='col-40']/h4[@class='text-bold']")).getText().replace("$", "").replace(".00","");
		int ToAmount=Integer.parseInt(fromAmount)-1;
		amount.FromAmount.sendKeys(fromAmount);
		amount.ToAmount.sendKeys(Integer.toString(ToAmount));
		amount.Apply.click();
		AssertVerify(payments.getNoRecords(), "There are no payments at this time.");
	}

	
	@Test(priority = 18, enabled = false)
	public void C2410987_AmountIsNonNumeric()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Payments payments= new Payments();
		payments.AmountOption.click();
		Payments.Amount amount = payments.new Amount();
		//String fromAmount= driver.findElement(By.xpath("id('main')/div[@class='col-65']/div[@class='module module-dark']/article[@class='module-light module-border accordion']/div[1]/div[@class='grid list-item']/div[@class='col-40']/h4[@class='text-bold']")).getText().replace("$", "").replace(".00","");
		//int ToAmount=Integer.parseInt(fromAmount)-1;
		amount.FromAmount.sendKeys("a$");
		amount.ToAmount.sendKeys("$%");		
		AssertVerify(amount.FromAmount.getText().length(), 0);
		AssertVerify(amount.ToAmount.getText().length(), 0);
	}
	
	@Test(priority = 19, enabled = false)
	public void C2410991_FromDateIsGreaterThanToDate()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);	
		Calendar now = Calendar.getInstance();
		String year = Integer.toString((now.get(Calendar.YEAR)));
		String month= new SimpleDateFormat("MMMM").format(now.getTime());
		String date = Integer.toString((now.get(Calendar.DATE)));	
		String yesterYear = Integer.toString((now.get(Calendar.YEAR))-1);
		Payments payments= new Payments();
		payments.DateOption.click();
		Payments.CustomDateRangeForPayments customdateRange = payments.new CustomDateRangeForPayments();
		selectDropDownByVisibleText(customdateRange.FromYear, year);		
		selectDropDownByVisibleText(customdateRange.FromMonth, month);		
		selectDropDownByVisibleText(customdateRange.FromDay, date);		
		selectDropDownByVisibleText(customdateRange.ToYear, yesterYear);		
		selectDropDownByVisibleText(customdateRange.ToMonth, month);		
		selectDropDownByVisibleText(customdateRange.ToDay, date);
		customdateRange.Apply.click();
		AssertVerify(payments.getNoRecords(), "There are no payments at this time.");
	}
	
	@Test(priority = 20, enabled = false)
	public void C2410992_OrderByDescending()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		payments.OrderByoption.click();
		Payments.OrderBy orderBy = payments.new OrderBy();
		orderBy.DescendingOrder.click();
		orderBy.Apply.click();
		AssertVerify(payments.verifyDateDescendingOrder(),true);		
	}
	

	@Test(priority = 21, enabled = false)
	public void C2410992_OrderByAscending()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		payments.OrderByoption.click();
		Payments.OrderBy orderBy = payments.new OrderBy();
		orderBy.AscendingOrder.click();
		orderBy.Apply.click();
		AssertVerify(payments.verifyDateAscendingOrder(),true);
	}
	
	
	@Test(priority = 22, enabled = false)
	public void C2411016_MakeOneTimePayment()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		AssertVerify(dateSelection.PaymentPreText.getText(),dateSelection.expectedPreText);
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);		
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		//String Month = "September";
		//String Day = "1";
		payonFuture =getFutureDate(payonFuture, 3);
		String Month=payonFuture.split("-")[0];
		String Day=payonFuture.split("-")[1];
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		selectedDay= new Select(dateSelection.Day);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		System.out.println("Month:"+selectedMonth.getFirstSelectedOption().getText());
		System.out.println("Day:"+selectedDay.getFirstSelectedOption().getText());
		AssertVerify(dateSelection.Step3.getText(),dateSelection.expectedStep3Text);
		AssertVerify(selectedYear.getFirstSelectedOption().getText().toString(), Integer.toString((now.get(Calendar.YEAR))));
		AssertVerify(selectedMonth.getFirstSelectedOption().getText().toString(), Month);
		AssertVerify(selectedDay.getFirstSelectedOption().getText().toString(), Day);
		//String PayOn=new SimpleDateFormat("MMM").format(now.getTime())+" "+(Integer.toString((now.get(Calendar.DATE)-1)))+", "+(Integer.toString((now.get(Calendar.YEAR))));
		System.out.println("PayOn: "+PayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	    //System.out.println(CardNumber.substring(CardNumber.length()-(CardNumber.length()-3),CardNumber.length()-7));
		String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 23, enabled = false)
	public void C2411005_RoutingNumberIsNonNumeric()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.managePaymentAccounts).click();
		Thread.sleep(5000);
		ManagePaymentAccounts managepaymentaccounts = new ManagePaymentAccounts();
		managepaymentaccounts.AddPaymentAccount.click();
		ManagePaymentAccounts.AddPaymentAccountType accountType=managepaymentaccounts.new AddPaymentAccountType();
		selectDropDownByVisibleText(accountType.SelectAccountType, "Checking");
		accountType.Next.click();
		ManagePaymentAccounts.AddPaymentAccountInfo accountinfo=managepaymentaccounts.new AddPaymentAccountInfo();
		AssertVerify(accountinfo.RoutingNumber.getAttribute("placeholder"),accountinfo.expectedinlineTextforRouting);
		AssertVerify(accountinfo.AccountNumber.getAttribute("placeholder"),accountinfo.expectedinlineTextforAccountNumber);
		AssertVerify(accountinfo.ReenterAccountNumber.getAttribute("placeholder"),accountinfo.expectedinlineTextforreenterAccountNumber);
		AssertVerify(accountinfo.AccountNickName.getAttribute("placeholder"),accountinfo.expectedinlineTextforNickName);
		accountinfo.RoutingNumber.sendKeys("abcdefghijkla");
		accountinfo.AccountNumber.sendKeys("8124590366");
		accountinfo.ReenterAccountNumber.sendKeys("8124590366");
		accountinfo.AccountNickName.sendKeys("NewCard");
		accountinfo.Next.click();
		System.out.println(accountinfo.getErrorMessage("RoutingNumber"));
		AssertVerify(accountinfo.getErrorMessage("RoutingNumber"), "Please enter a valid routing number");		
	}
	
	
	@Test(priority = 24, enabled = false)
	public void C2411004_AddCheckingAccount()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.managePaymentAccounts).click();
		Thread.sleep(5000);
		ManagePaymentAccounts managepaymentaccounts = new ManagePaymentAccounts();
		managepaymentaccounts.AddPaymentAccount.click();
		ManagePaymentAccounts.AddPaymentAccountType accountType=managepaymentaccounts.new AddPaymentAccountType();
		AssertVerify(accountType.Step1.getText().trim(), accountType.expectedStep1Text);
		selectDropDownByVisibleText(accountType.SelectAccountType, "Checking");
		accountType.Next.click();
		ManagePaymentAccounts.AddPaymentAccountInfo accountinfo=managepaymentaccounts.new AddPaymentAccountInfo();
		AssertVerify(accountinfo.Step2.getText().trim(), accountinfo.expectedStep2Text);
		String RoutingNumber = "122100024";
		String AccountNumber = "8024599366";
		String FinancialInstitution = "BANK ONE ARIZONA NA BELLEVILLE MI";
		String AccountNickName = "NewCard"+AccountNumber;
		accountinfo.RoutingNumber.sendKeys(RoutingNumber);
		accountinfo.AccountNumber.sendKeys(AccountNumber);
		accountinfo.ReenterAccountNumber.sendKeys(AccountNumber);
		accountinfo.AccountNickName.sendKeys(AccountNickName);
		accountinfo.Next.click();
		ManagePaymentAccounts.ManagePaymentAccountReview review = managepaymentaccounts.new ManagePaymentAccountReview();
		AssertVerify(review.Step3.getText().trim(), review.expectedstep3Text);
		System.out.println(review.AccountType.getText().trim());
		System.out.println(review.AccountNumber.getText().trim());
		System.out.println(review.FinancialInstitution.getText().trim());
		System.out.println(review.AccountNickName.getText().trim());
		System.out.println(review.RoutingNumber.getText().trim());
		String selectaccountType="Checking";
		AssertVerify(review.AccountType.getText().trim(), "Account Type: "+selectaccountType);
		AssertVerify(review.AccountNumber.getText().trim(), "Account Number: "+AccountNumber);
		AssertVerify(review.FinancialInstitution.getText().trim(), "Financial Institution: BANK ONE ARIZONA NA BELLEVILLE MI");
		AssertVerify(review.AccountNickName.getText().trim(), "Account Nickname: "+AccountNickName);
		AssertVerify(review.RoutingNumber.getText().trim(), "Routing Number: "+RoutingNumber);
		review.AddPaymentAccount.click();
		Thread.sleep(5000);
		ManagePaymentAccounts.ManagePaymentAccountConfirmation confirmation = managepaymentaccounts.new ManagePaymentAccountConfirmation();
		AssertVerify(confirmation.Step4.getText().trim(), confirmation.expectedstep4Text);
		AssertVerify(confirmation.AccountType.getText().trim(), "Account Type: "+selectaccountType);
		AssertVerify(confirmation.AccountNumber.getText().trim(), "Account Number: *"+AccountNumber.substring(AccountNumber.length()-4,AccountNumber.length()));
		AssertVerify(confirmation.FinancialInstitution.getText().trim(), "Financial Institution: BANK ONE ARIZONA NA BELLEVILLE MI");
		AssertVerify(confirmation.AccountNickName.getText().trim(), "Account Nickname: "+AccountNickName);
		AssertVerify(confirmation.RoutingNumber.getText().trim(), "Routing Number: "+RoutingNumber);
		confirmation.Close.click();
		managepaymentaccounts = new ManagePaymentAccounts();
		homePage.Logout.click();
		
		
	}
	
	@Test(priority = 25, enabled = false)
	public void C2411003_AddSavingsAccount()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.managePaymentAccounts).click();
		Thread.sleep(5000);
		ManagePaymentAccounts managepaymentaccounts = new ManagePaymentAccounts();
		managepaymentaccounts.AddPaymentAccount.click();
		ManagePaymentAccounts.AddPaymentAccountType accountType=managepaymentaccounts.new AddPaymentAccountType();
		AssertVerify(accountType.Step1.getText().trim(), accountType.expectedStep1Text);
		String selectaccountType="Savings";
		selectDropDownByVisibleText(accountType.SelectAccountType, selectaccountType);
		accountType.Next.click();
		Thread.sleep(5000);
		ManagePaymentAccounts.AddPaymentAccountInfo accountinfo=managepaymentaccounts.new AddPaymentAccountInfo();
		AssertVerify(accountinfo.Step2.getText().trim(), accountinfo.expectedStep2Text);
		String RoutingNumber = "122100024";
		String AccountNumber = "8024599306";
		String FinancialInstitution = "BANK ONE ARIZONA NA BELLEVILLE MI";
		String AccountNickName = "NewCard"+AccountNumber;
		accountinfo.RoutingNumber.sendKeys(RoutingNumber);
		accountinfo.AccountNumber.sendKeys(AccountNumber);
		accountinfo.ReenterAccountNumber.sendKeys(AccountNumber);
		accountinfo.AccountNickName.sendKeys(AccountNickName);
		accountinfo.Next.click();
		Thread.sleep(5000);
		ManagePaymentAccounts.ManagePaymentAccountReview review = managepaymentaccounts.new ManagePaymentAccountReview();
		AssertVerify(review.Step3.getText().trim(), review.expectedstep3Text);
		System.out.println(review.AccountType.getText().trim());
		System.out.println(review.AccountNumber.getText().trim());
		System.out.println(review.FinancialInstitution.getText().trim());
		System.out.println(review.AccountNickName.getText().trim());
		System.out.println(review.RoutingNumber.getText().trim());
		AssertVerify(review.AccountType.getText().trim(), "Account Type: "+selectaccountType);
		AssertVerify(review.AccountNumber.getText().trim(), "Account Number: "+AccountNumber);
		AssertVerify(review.FinancialInstitution.getText().trim(), "Financial Institution: BANK ONE ARIZONA NA BELLEVILLE MI");
		AssertVerify(review.AccountNickName.getText().trim(), "Account Nickname: "+AccountNickName);
		AssertVerify(review.RoutingNumber.getText().trim(), "Routing Number: "+RoutingNumber);
		review.AddPaymentAccount.click();
		Thread.sleep(5000);
		ManagePaymentAccounts.ManagePaymentAccountConfirmation confirmation = managepaymentaccounts.new ManagePaymentAccountConfirmation();
		AssertVerify(confirmation.Step4.getText().trim(), confirmation.expectedstep4Text);
		AssertVerify(confirmation.AccountType.getText().trim(), "Account Type: "+selectaccountType);
		AssertVerify(confirmation.AccountNumber.getText().trim(), "Account Number: *"+AccountNumber.substring(AccountNumber.length()-4,AccountNumber.length()));
		AssertVerify(confirmation.FinancialInstitution.getText().trim(), "Financial Institution: BANK ONE ARIZONA NA BELLEVILLE MI");
		AssertVerify(confirmation.AccountNickName.getText().trim(), "Account Nickname: "+AccountNickName);
		AssertVerify(confirmation.RoutingNumber.getText().trim(), "Routing Number: "+RoutingNumber);
		confirmation.Close.click();
		managepaymentaccounts = new ManagePaymentAccounts();
		homePage.Logout.click();		
	}
	
	@Test(priority = 26, enabled = false)
	public void C2411010_NumberofPaymentAccounts()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.managePaymentAccounts).click();
		Thread.sleep(5000);
		ManagePaymentAccounts managepaymentaccounts = new ManagePaymentAccounts();
		String numberofAccounts = managepaymentaccounts.numberofAccounts();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.makeOneTimePayment).click();
		MakeOneTimePayment makeonetimepayment = new MakeOneTimePayment();
		Select select = new Select(makeonetimepayment.SelectAccount);
		AssertVerify(select.getOptions().size(), Integer.parseInt(numberofAccounts));
				
	}
	
	/*@Test(priority = 27, enabled = false)
	public void C2411010_DeletePaymentAccountWhichIsAssociatedWithPayment()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		AssertVerify(dateSelection.PaymentPreText.getText(),dateSelection.expectedPreText);
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		//String Month = "September";
		//String Day = "1";
		payonFuture =getFutureDate(payonFuture, 4);
		String Month=payonFuture.split("-")[0];
		String Day=payonFuture.split("-")[1];
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		selectedDay= new Select(dateSelection.Day);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		System.out.println("Month:"+selectedMonth.getFirstSelectedOption().getText());
		System.out.println("Day:"+selectedDay.getFirstSelectedOption().getText());
		AssertVerify(dateSelection.Step3.getText(),dateSelection.expectedStep3Text);
		AssertVerify(selectedYear.getFirstSelectedOption().getText().toString(), Integer.toString((now.get(Calendar.YEAR))));
		AssertVerify(selectedMonth.getFirstSelectedOption().getText().toString(), Month);
		AssertVerify(selectedDay.getFirstSelectedOption().getText().toString(), Day);
		//String PayOn=new SimpleDateFormat("MMM").format(now.getTime())+" "+(Integer.toString((now.get(Calendar.DATE)-1)))+", "+(Integer.toString((now.get(Calendar.YEAR))));
		System.out.println("PayOn: "+PayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	    //System.out.println(CardNumber.substring(CardNumber.length()-(CardNumber.length()-3),CardNumber.length()-7));
		String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		payments= new Payments();
		homePage.Logout.click();
				
	}*/
	
	
	

	@Test(priority = 28, enabled = false)
	public void C2410997_FilterPaymentByPending()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 4);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		payments= new Payments();
		payments.PaymentStatusOption.click();
		Payments.PaymentStatus paymentstatus = payments.new PaymentStatus();
		paymentstatus.Pending.click();
		paymentstatus.Apply.click();
		payments.verifyStatus("Pending");
		homePage.Logout.click();				
	}
	
	@Test(priority = 29, enabled = false)
	public void C2410996_FilterPaymentByCanceled()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 13);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumber = confirmation.ConfirmationNumber.getText();
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);
		payments= new Payments();
		payments.PaymentStatusOption.click();
		Payments.PaymentStatus paymentstatus = payments.new PaymentStatus();
		paymentstatus.Pending.click();
		paymentstatus.Apply.click();
		payments.verifyStatus("Pending");
		int index = payments.returnIndex(confirmationNumber);
		System.out.println(index);
		CancelPayment cancelPayment = payments.clickCancel(index);
		AssertVerify(cancelPayment.PaymentAmount.getText().trim(), paymentAmount);
		AssertVerify(cancelPayment.PaymentAmount.getText().trim(), paymentAmount);
		AssertVerify(cancelPayment.ConfrimationText.getText().trim(), cancelPayment.expectedconfirmationText);
		cancelPayment.CancelPayment.click();
		Thread.sleep(15000);
		payments.PaymentStatusOption.click();		
		paymentstatus = payments.new PaymentStatus();
		paymentstatus.Cancelled.click();
		paymentstatus.Apply.click();
		payments.verifyStatus("Canceled");
		homePage.Logout.click();
	}
	
	@Test(priority = 30, enabled = false)
	public void C2410994_FilterPaymentByProcessed()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();;
		payments.PaymentStatusOption.click();
		Payments.PaymentStatus paymentstatus = payments.new PaymentStatus();
		paymentstatus.Processed.click();
		paymentstatus.Apply.click();
		payments.verifyStatus("Processed");
		homePage.Logout.click();
	}
	@Test(priority = 31, enabled = false)
	public void C2410995_FilterPaymentByProcessing()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();;
		payments.PaymentStatusOption.click();
		Payments.PaymentStatus paymentstatus = payments.new PaymentStatus();
		paymentstatus.Processing.click();
		paymentstatus.Apply.click();
		payments.verifyStatus("Processing");
		homePage.Logout.click();
	}
	
	@Test(priority = 32, enabled = false)
	public void C2411002_CanelPayment()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 13);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumber = confirmation.ConfirmationNumber.getText();
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);
		payments= new Payments();
		payments.PaymentStatusOption.click();
		Payments.PaymentStatus paymentstatus = payments.new PaymentStatus();
		paymentstatus.Pending.click();
		paymentstatus.Apply.click();
		payments.verifyStatus("Pending");
		int index = payments.returnIndex(confirmationNumber);
		System.out.println(index);
		CancelPayment cancelPayment = payments.clickCancel(index);
		AssertVerify(cancelPayment.PaymentAmount.getText().trim(), paymentAmount);
		AssertVerify(cancelPayment.PaymentAmount.getText().trim(), paymentAmount);
		AssertVerify(cancelPayment.PaymentDueDate.getText().trim(), "Payment Date: "+PayOn);
		AssertVerify(cancelPayment.ConfrimationText.getText().trim(), cancelPayment.expectedconfirmationText);
		cancelPayment.CancelPayment.click();
		Thread.sleep(15000);
		payments.PaymentStatusOption.click();		
		paymentstatus = payments.new PaymentStatus();
		paymentstatus.Cancelled.click();
		paymentstatus.Apply.click();
		payments.verifyStatus("Canceled");
		homePage.Logout.click();
	}
	
	@Test(priority = 33, enabled = false)
	public void C2411002_PaymentIsMadeMoreThan31Days()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 32);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		AssertVerify(review.getErrorMessage(), review.expectederrorMessageForScheduledMorethan30Days);
		review.getCloseIconOnErrorMessage().click();
		homePage.Logout.click();		
	}
	
	@Test(priority = 34, enabled = false)
	public void C2411005_DuplicateNickNameForAccount()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.managePaymentAccounts).click();
		Thread.sleep(5000);
		ManagePaymentAccounts managepaymentaccounts = new ManagePaymentAccounts();
		String nickName = managepaymentaccounts.getNickNameForAccount(1);
		managepaymentaccounts.AddPaymentAccount.click();
		ManagePaymentAccounts.AddPaymentAccountType accountType=managepaymentaccounts.new AddPaymentAccountType();
		selectDropDownByVisibleText(accountType.SelectAccountType, "Checking");
		accountType.Next.click();
		ManagePaymentAccounts.AddPaymentAccountInfo accountinfo=managepaymentaccounts.new AddPaymentAccountInfo();
		accountinfo.RoutingNumber.sendKeys("122100024");
		accountinfo.AccountNumber.sendKeys("909010992");
		accountinfo.ReenterAccountNumber.sendKeys("909010992");
		accountinfo.AccountNickName.sendKeys(nickName);
		accountinfo.Next.click();
		ManagePaymentAccounts.ManagePaymentAccountReview review = managepaymentaccounts.new ManagePaymentAccountReview();
		review.AddPaymentAccount.click();
		Thread.sleep(10000);
		AssertVerify(review.getErrorMessage(), review.expectederrorMessageForDuplicateNickName);
		review.getCloseIconOnErrorMessage().click();				
	}
	
	
	@Test(priority = 35, enabled = false)
	public void C2411008_VerifyManageAccountsPage()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.managePaymentAccounts).click();
		Thread.sleep(5000);
		ManagePaymentAccounts managepaymentaccounts = new ManagePaymentAccounts();
		AssertVerify(managepaymentaccounts.AddPaymentAccount.isDisplayed(), true);
		AssertVerify(managepaymentaccounts.WelcomeMessage.getText(), managepaymentaccounts.expectedWelcomeMessage);
		AssertVerify(managepaymentaccounts.WelcomeMessage.isDisplayed(), true);
		AssertVerify(managepaymentaccounts.PaymentsAccountsTitle.isDisplayed(), true);
		String numberofAccounts = managepaymentaccounts.numberofAccounts();
		System.out.println(numberofAccounts);
		AssertVerify(managepaymentaccounts.PaymentsAccountsTitle.getText(), managepaymentaccounts.expectedpaymentAccountsTitle +" ("+numberofAccounts+") Start Help");
		//AssertVerify(managepaymentaccounts.PaymentsAccountsTitle.isDisplayed(), true);
		
	}
	
	@Test(priority = 36, enabled = false)
	public void C2411001_EditPayment()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 9);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumber = confirmation.ConfirmationNumber.getText();
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);
		payments= new Payments();
		payments.PaymentStatusOption.click();
		Payments.PaymentStatus paymentstatus = payments.new PaymentStatus();
		paymentstatus.Pending.click();
		paymentstatus.Apply.click();
		payments.verifyStatus("Pending");
		int index = payments.returnIndex(confirmationNumber);
		System.out.println(index);
		payments.clickEdit(index);
		Thread.sleep(15000);
		
		//Edit payments
		makeonetimePayment = new MakeOneTimePayment();
		selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String editpayFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.OtherAmountRadioButton.click();
		String Otheramount="5";
		amountselection.OtherInputText.sendKeys(Otheramount);
		Thread.sleep(3000);
		String editpaymentAmount = amountselection.OtherInputText.getText().trim();
		System.out.println("Edit Payment Amount:"+editpaymentAmount);
		amountselection.Next.click();
		dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		now = Calendar.getInstance();		
		selectedYear= new Select(dateSelection.Year);
		//Select Month
		selectedMonth= new Select(dateSelection.Month);	
		selectedDay= new Select(dateSelection.Day);		
		payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 8);
		System.out.println(payonFuture);
		String EditMonth=payonFuture.split("-")[0];
		System.out.println(EditMonth);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(EditMonth);
		//Select Day
		String EditDay=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(EditDay);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(EditDay);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String editselectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String editPayOn=getPreviousDate(editselectedPayOn);
		String editSendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String editCardNumber = review.NameAndCardDetails.getText().trim();
		//System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		//CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	//String editmaskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),editpayFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),"$"+Otheramount+".00");
		AssertVerify(review.PayOnDate.getText().toString(),editPayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),editSendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText1 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of $"+Otheramount+".00 from your "+"\""+editpayFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText1);
		review.MakePayment.click();
		Thread.sleep(10000);
		confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),editpayFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),"$"+Otheramount+".00");
		AssertVerify(confirmation.PayOnDate.getText().toString(),editPayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumberOnEdit = confirmation.ConfirmationNumber.getText();
		System.out.println(confirmationNumberOnEdit);
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);		
	}
	
	@Test(priority = 37, enabled = false)
	public void C2410982_FilterByAmountFromAnyToFixedValue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		String toamount = payments.getAmount(1);
		payments.AmountOption.click();
		Payments.Amount amount = payments.new Amount();
		amount.ToAmount.sendKeys("");
		amount.ToAmount.sendKeys(toamount);
		amount.Apply.click();
		payments.verifyAmountIsWithInTheRange("", toamount);
	}
	
	@Test(priority = 38, enabled = false)
	public void C2410983_FilterByAmountFromFixedToAnyValue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		String fromamount = payments.getAmount(1);
		payments.AmountOption.click();
		Payments.Amount amount = payments.new Amount();
		amount.FromAmount.sendKeys(fromamount);
		amount.ToAmount.sendKeys("");
		amount.Apply.click();
		payments.verifyAmountIsWithInTheRange(fromamount, "");
	}
	
	@Test(priority = 39, enabled = false)
	public void C2410984FilterByAmountFromFixedToFixedValue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		String fromAmount = payments.getAmount(1);
		String toAmount = Double.toString(Double.parseDouble(fromAmount)+10);
		payments.AmountOption.click();
		Payments.Amount amount = payments.new Amount();
		amount.FromAmount.sendKeys(fromAmount);
		amount.ToAmount.sendKeys(toAmount);
		amount.Apply.click();
		payments.verifyAmountIsWithInTheRange(fromAmount, toAmount);
	}
	
	@Test(priority = 40, enabled = false)
	public void C2410985FilterByAmountFromNegativeToNegativeValue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		String toAmount = payments.getAmount(1);
		String fromAmount = Double.toString(Double.parseDouble(toAmount)*-1);
		payments.AmountOption.click();
		Payments.Amount amount = payments.new Amount();
		amount.FromAmount.sendKeys(fromAmount);
		amount.ToAmount.sendKeys(toAmount);
		amount.Apply.click();
		payments.verifyAmountIsWithInTheRange(fromAmount, toAmount);
	}
	
	@Test(priority = 41, enabled = false)
	public void C2410988FilterByAmountFromSpecificToDefault()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		payments.DateOption.click();
		String toDate = payments.getDate(1);
		
		System.out.println("To Date:"+toDate);
		//FromDate
		String fromDate = payments.getPastDate(toDate, -31);
		String[] splitdata = fromDate.split(",");
		System.out.println("From Date:"+fromDate);
		System.out.println(DateValue(toDate));
		String fromyear =splitdata[splitdata.length-1].trim();
		String frommonth = splitdata[splitdata.length-2].split(" ")[0].trim();
		String fromday=splitdata[splitdata.length-2].split(" ")[1].trim();
		System.out.println(fromday);
		System.out.println(frommonth);
		if(fromday.startsWith("0") == true) {
			fromday = fromday.replace("0","");
		}
		Payments.CustomDateRangeForPayments customdateRange = payments.new CustomDateRangeForPayments();
		selectDropDownByVisibleText(customdateRange.FromYear, fromyear);		
		selectDropDownByVisibleText(customdateRange.FromMonth, getFullMonth(frommonth));
		selectDropDownByVisibleText(customdateRange.FromDay, fromday);
		customdateRange.Apply.click();
		AssertVerify(payments.verifyDateIsWithinRange(fromDate, ""),true);
	}
	
	@Test(priority = 41, enabled = false)
	public void C2410989FilterByAmountFromDefaultToSpecific()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		payments.DateOption.click();
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, yyyy");  
	    LocalDateTime now = LocalDateTime.now();  
		String toDate = dtf.format(now);
		System.out.println("To Date:"+toDate);
		//FromDate
		//String fromDate = payments.getPastDate(toDate, -31);
		String[] splitdata = toDate.split(",");
		System.out.println("From Date:"+toDate);
		System.out.println(DateValue(toDate));
		String toyear =splitdata[splitdata.length-1].trim();
		String tomonth = splitdata[splitdata.length-2].split(" ")[0].trim();
		String today=splitdata[splitdata.length-2].split(" ")[1].trim();
		System.out.println(today);
		System.out.println(tomonth);
		if(today.startsWith("0") == true) {
			today = today.replace("0","");
		}
		Payments.CustomDateRangeForPayments customdateRange = payments.new CustomDateRangeForPayments();
		selectDropDownByVisibleText(customdateRange.ToYear, toyear);		
		selectDropDownByVisibleText(customdateRange.ToMonth, getFullMonth(tomonth));
		selectDropDownByVisibleText(customdateRange.ToDay, today);
		customdateRange.Apply.click();
		AssertVerify(payments.verifyDateIsWithinRange("", toDate),true);
	}
	
	
	@Test(priority = 43, enabled = false)
	public void C2410990FilterByAmountFromSpecificToSpecific()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		payments.DateOption.click();
		String getDate = payments.getDate(1);		
		System.out.println("To Date:"+getDate);		
		//FromDate
		String fromDate = payments.getPastDate(getDate, -31);
		String[] splitdata = fromDate.split(",");
		System.out.println("From Date:"+fromDate);
		System.out.println(DateValue(getDate));
		String fromyear =splitdata[splitdata.length-1].trim();
		String frommonth = splitdata[splitdata.length-2].split(" ")[0].trim();
		String fromday=splitdata[splitdata.length-2].split(" ")[1].trim();
		System.out.println(fromday);
		System.out.println(frommonth);
		if(fromday.startsWith("0") == true) {
			fromday = fromday.replace("0","");
		}		
		//To Date
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, yyyy");  
	    LocalDateTime now = LocalDateTime.now();  
		String toDate = dtf.format(now);
		System.out.println("To Date:"+toDate);
		//FromDate
		//String fromDate = payments.getPastDate(toDate, -31);
		String[] splitdata1 = toDate.split(",");
		System.out.println("From Date:"+toDate);
		System.out.println(DateValue(toDate));
		String toyear =splitdata1[splitdata1.length-1].trim();
		String tomonth = splitdata1[splitdata1.length-2].split(" ")[0].trim();
		String today=splitdata1[splitdata1.length-2].split(" ")[1].trim();
		System.out.println(today);
		System.out.println(tomonth);
		if(today.startsWith("0") == true) {
			today = today.replace("0","");
		}		
		Payments.CustomDateRangeForPayments customdateRange = payments.new CustomDateRangeForPayments();
		selectDropDownByVisibleText(customdateRange.FromYear, fromyear);		
		selectDropDownByVisibleText(customdateRange.FromMonth, getFullMonth(frommonth));
		selectDropDownByVisibleText(customdateRange.FromDay, fromday);
		selectDropDownByVisibleText(customdateRange.ToYear, toyear);		
		selectDropDownByVisibleText(customdateRange.ToMonth, getFullMonth(tomonth));
		selectDropDownByVisibleText(customdateRange.ToDay, today);		
		customdateRange.Apply.click();
		AssertVerify(payments.verifyDateIsWithinRange(fromDate, toDate),true);
	}
	
	@Test(priority = 44, enabled = false)
	public void C2411013_PaymentofMinimumDue()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.MinimumDueRadioButton.click();
		String paymentAmount = amountselection.MinimumDueAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 13);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumber = confirmation.ConfirmationNumber.getText();
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);
		payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 45, enabled = false)
	public void C2411014_PaymentofCurrentBalance()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.CurrentBalanceRadioButton.click();
		String paymentAmount = amountselection.CurrentBalanceAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 13);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumber = confirmation.ConfirmationNumber.getText();
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);
		payments= new Payments();
		homePage.Logout.click();
	}
	
	
	@Test(priority = 46, enabled = false)
	public void C2411015_PaymentofStatementBalance()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.LastStatementBalanceRadioButton.click();
		String paymentAmount = amountselection.LastStatementBalanceRadioButton.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 13);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumber = confirmation.ConfirmationNumber.getText();
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);
		payments= new Payments();
		homePage.Logout.click();
	}
	
	
	@Test(priority = 47, enabled = false)
	public void C2411016_PaymentOfOtherAmount()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.OtherAmountRadioButton.click();
		String otherAmount = "5";
		String paymentAmount = "$"+otherAmount+".00";
		amountselection.OtherInputText.sendKeys(otherAmount);
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 13);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumber = confirmation.ConfirmationNumber.getText();
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);
		payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 48, enabled = false)
	public void C2411017_PaymentofLastPayment()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		homePage.Payments.click();
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(10000);
		Payments payments= new Payments();
		payments.MakeOneTimePayment.click();
		MakeOneTimePayment makeonetimePayment = new MakeOneTimePayment();
		Select selectedAccount=new Select(makeonetimePayment.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();		
		makeonetimePayment.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentAmountSelection amountselection = makeonetimePayment.new MakeOneTimePaymentAmountSelection();
		amountselection.LastPaymentAmount.click();
		String paymentAmount = amountselection.LastPaymentAmount.getText().trim();
		amountselection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentDateSelection dateSelection = makeonetimePayment.new MakeOneTimePaymentDateSelection();
		Calendar now = Calendar.getInstance();		
		Select selectedYear= new Select(dateSelection.Year);
		//Select Month
		Select selectedMonth= new Select(dateSelection.Month);	
		Select selectedDay= new Select(dateSelection.Day);		
		String payonFuture= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		payonFuture =getFutureDate(payonFuture, 13);
		System.out.println(payonFuture);
		String Month=payonFuture.split("-")[0];
		System.out.println(Month);
		dateSelection.Month.click();
		selectedMonth.selectByVisibleText(Month);
		//Select Day
		String Day=payonFuture.split("-")[1];
		if(Day.startsWith("0")) {
			Day=Day.replace("0", "");
		}
		selectedDay= new Select(dateSelection.Day);
		System.out.println(Month);
		dateSelection.Day.click();
		selectedDay.selectByVisibleText(Day);
		dateSelection.Day.click();
		//Re-initialize the date to get the selected Values		
		selectedMonth= new Select(dateSelection.Month);
		selectedDay= new Select(dateSelection.Day);
		String selectedPayOn= selectedYear.getFirstSelectedOption().getText().toString()+"-"+selectedMonth.getFirstSelectedOption().getText().toString()+"-"+selectedDay.getFirstSelectedOption().getText().toString();
		String PayOn=getPreviousDate(selectedPayOn);
		String SendAlertVia =dateSelection.SendAlertTo.getAttribute("id");
		dateSelection.Next.click();
		MakeOneTimePayment.MakeOneTimePaymentReview review=makeonetimePayment.new MakeOneTimePaymentReview();
		AssertVerify(review.Step4.getText().trim(),review.expectedstep4Text);
		String CardNumber = review.NameAndCardDetails.getText();
		System.out.println(CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1));
		CardNumber=CardNumber.substring(CardNumber.length()-5, CardNumber.length()-1);
	   	String maskedCardNumber = "XXXX-XXXX-XXXX-"+CardNumber;
		AssertVerify(review.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(review.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(review.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(review.PayOnDate.getText().toString(),PayOn);
		AssertVerify(review.SendAlertVia.getText().toString(),SendAlertVia);
		//String expectedReviewText2 = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your \"*963\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		String expectedReviewText = "By selecting \"Make A Payment\" you are authorizing us to make an electronic debit in the amount of "+paymentAmount+" from your "+"\""+payFrom+"\" bank account.  This amount will then be applied to your Target REDcard account ending in "+CardNumber+". If you do not wish to authorize this online payment, select \"Cancel\". Please print or retain a copy of this authorization for your records.";
		AssertVerify(review.ReviewPreText.getText().toString(),expectedReviewText);
		review.MakePayment.click();
		Thread.sleep(10000);
		MakeOneTimePayment.MakeOneTimePaymentConfirmation confirmation = makeonetimePayment.new MakeOneTimePaymentConfirmation();
		AssertVerify(confirmation.CardNumber.getText().toString(),maskedCardNumber);
		AssertVerify(confirmation.PayFromAccount.getText().toString(),payFrom);
		AssertVerify(confirmation.PaymentAmount.getText().toString(),paymentAmount);
		AssertVerify(confirmation.PayOnDate.getText().toString(),PayOn);
		System.out.println(confirmation.ConfirmationNumber.getText());
		String confirmationNumber = confirmation.ConfirmationNumber.getText();
		AssertVerify(confirmation.ConfirmationNumber.getText().length()>0,true);
		confirmation.Close.click();
		Thread.sleep(10000);
		payments= new Payments();
		homePage.Logout.click();
	}
	
	@Test(priority = 49, enabled = false)
	public void C2411038_ByDefaultPaymentIsOrderByDescending()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);	
		driver.findElement(homePage.paymentsSummary).click();
		Thread.sleep(5000);
		Payments payments= new Payments();
		AssertVerify(payments.verifyDateDescendingOrder(),true);		
	}
	

	@Test(priority = 50, enabled = true)
	public void C2411007_DeleteAccountWhichIsAlreadyAssociatedWithRecurringPlan()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		TestCaseId = "8789740";
		record = new ATUTestRecorder("./video",
				Thread.currentThread().getStackTrace()[1].getMethodName(), false);
		record.start();		
		launchUrl();
		startResult();
		startTestCase(Thread.currentThread().getStackTrace()[1].getMethodName().toString());	
		//test.info("Flow: Login Application -> Navigated to Home Page -> Click Transaction and Select Search Transactions -> Navigated to Transaction Page -> Enter Merchant Name in the Search Input Box -> select Search -> Verify Merchant Name in each transaction results.");
		LoginApplication(transactionusername, transactionuserpassword);
		HomePage homePage = new HomePage();
		String autoPayStatus=homePage.AutoPay.getText();
		System.out.println(autoPayStatus);
		String PaymentDue=homePage.PaymentDue.getText();
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.manageautopay).click();
		Thread.sleep(10000);
		ManageAutoPay manageAutoPay = ManageAutoPay.NavigateToManageAutoPay(autoPayStatus);
		Select selectedAccount=new Select(manageAutoPay.SelectAccount);
		String payFrom= selectedAccount.getFirstSelectedOption().getText().trim();	
		manageAutoPay.Next.click();
		ManageAutoPay.ManageAutoPayAmountSelection amountSelection = manageAutoPay.new ManageAutoPayAmountSelection();
		amountSelection.FixedAmountRadioButton.click();
		WebElement FixedAmountInputText = amountSelection.getFixedAmount();
		FixedAmountInputText.clear();
		String paymentamount="4";
		FixedAmountInputText.sendKeys(paymentamount);
		amountSelection.Next.click();
		ManageAutoPay.ManageAutoPayDateSelection manageAutoPayDateSelection = manageAutoPay.new ManageAutoPayDateSelection();
		manageAutoPayDateSelection.Next.click();
		ManageAutoPay.ManageAutoPayReview manageAutoPayReviewSelection = manageAutoPay.new ManageAutoPayReview();
		System.out.println(driver.findElement(manageAutoPayReviewSelection.cardendingDigit).getText().trim());
		String enddigit=driver.findElement(manageAutoPayReviewSelection.cardendingDigit).getText().trim();
		String last4digits = enddigit.substring(enddigit.length()-4, enddigit.length());
		System.out.println(last4digits);
		AssertVerify(manageAutoPayReviewSelection.CardNumber.getText(), "Card: XXXX-XXXX-XXXX-"+last4digits);
		AssertVerify(manageAutoPayReviewSelection.PayFromAccount.getText(),"Pay From: "+payFrom);
		AssertVerify(manageAutoPayReviewSelection.PaymentAmount.getText().trim(),"$"+paymentamount+".00");
		AssertVerify(manageAutoPayReviewSelection.PlanTypeValue.getText(),"Plan Type: Fixed Monthly");
		AssertVerify(manageAutoPayReviewSelection.PaymentDueDate.getText().toString().trim(), "Payment Due Date: "+PaymentDue);
		AssertVerify(manageAutoPayReviewSelection.RecurringpaymentPreText.getText().toString().trim(),manageAutoPayReviewSelection.expectedRecurringPaymentPreText);
	    String expectedRecurringPaymentPreTextFixed = "Your payment will either be the fixed payment amount, or the minimum payment due as indicated on your monthly statement, whichever is greater, regardless of other payments made during the month. If the fixed payment you�ve scheduled is less than your minimum due, we�ll automatically process a payment for the minimum due. If your account is past due, you may be responsible for making an additional payment to bring the account current. If your current balance is less than the fixed payment amount at the time the payment is made, only the current balance will be withdrawn. By selecting �Save Auto Pay�, you authorize us to automatically transfer your monthly amount from your \""+payFrom+"\" bank account as a payment to your REDcard account ending in "+last4digits+".  These transfers will be automatically processed each month on your payment due date until you cancel this authorization.  You may cancel this authorization in the Manage Auto Pay section of this website, by calling us at 1-800-394-1829, or by writing to us at Target Card Services, P.O. Box 673, Minneapolis, MN 55440-9285. You should print a copy of this authorization for your records.";
	    //String expectedRecurringPaymentPreTextOthers="By selecting �Save Auto Pay�, you authorize us to automatically transfer your monthly amount from your "+"\""+payFrom+"\" bank account as a payment to your REDcard account ending in "+last4digits+".  These transfers will be automatically processed each month on your payment due date until you cancel this authorization.  You may cancel this authorization in the Manage Auto Pay section of this website, by calling us at 1-800-394-1829, or by writing to us at Target Card Services, P.O. Box 673, Minneapolis, MN 55440-9285. You should print a copy of this authorization for your records.";
	    String ReviewPreText=manageAutoPayReviewSelection.ReviewPreText.getText().trim();
	    ReviewPreText = ReviewPreText.replaceAll("\\r", "");
	    ReviewPreText = ReviewPreText.replaceAll("\\n", "");
		AssertVerify(ReviewPreText,expectedRecurringPaymentPreTextFixed);
		manageAutoPayReviewSelection.SaveAutoPay.click();
		Thread.sleep(10000);
		ManageAutoPay.ManageAutoPayConfirmation confirm =manageAutoPay.new ManageAutoPayConfirmation();
		AssertVerify(confirm.CardNumber.getText(), "Card: XXXX-XXXX-XXXX-"+last4digits);
		AssertVerify(confirm.PayFromAccount.getText(),"Pay From: "+payFrom);
		AssertVerify(confirm.PaymentAmount.getText().trim(),"$"+paymentamount+".00");
		AssertVerify(confirm.PlanTypeValue.getText(),"Plan Type: Fixed Monthly");
		AssertVerify(confirm.Step5.getText(),confirm.expectedStep5Text);
		confirm.ReturnToSummary.click();
		Thread.sleep(10000);
		homePage.Payments.click();
		Thread.sleep(5000);
		driver.findElement(homePage.managePaymentAccounts).click();
		Thread.sleep(10000);
		ManagePaymentAccounts managepaymentaccounts= new ManagePaymentAccounts();
		int index = managepaymentaccounts.getIndexForNickName(payFrom);
		managepaymentaccounts.deleteAccount(index);	
		DeletePaymentAccounts deletepaymentaccount = new DeletePaymentAccounts();
		AssertVerify(deletepaymentaccount.getWarningText(), deletepaymentaccount.expectedPreTextForAutoPay);
		AssertVerify(deletepaymentaccount.getCurrentAutoPay().replace("\\n", ""),"Current Auto Pay Plan Type: Fixed Monthly");
		homePage.Logout.click();
	}
	
	
	@AfterMethod
	public void afterMethod() throws ATUTestRecorderException {		
		endTestcase();
		endResult();
		record.stop();
		closeBrowsers();
	}

}
