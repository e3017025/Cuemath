package POM_Test;

import POM_Classes.BaseClass;

public class AdminPageTest extends BaseClass
{

}
