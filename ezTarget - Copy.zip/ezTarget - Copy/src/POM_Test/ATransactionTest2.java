package POM_Test;

import java.awt.AWTException;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;

import org.junit.rules.DisableOnDebug;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.testrail.connection.APIException;

import POM_Classes.BaseClass;
import POM_Classes.HomePage;
import POM_Classes.MyAlerts;
import POM_Classes.SettingsAndHelp;
import POM_Classes.SpendAnalyzer;
import POM_Classes.Transactions;
import POM_Classes.BaseClass.AlertMeConstants;
import POM_Classes.BaseClass.CardTypes;
import POM_Classes.BaseClass.GetInputData;
import POM_Classes.BaseClass.ReportTypes;
import POM_Classes.MyAlerts.AddNewAlert;
import POM_Classes.MyAlerts.EditExistingAlert;
import POM_Classes.MyAlerts.HelpModal;
import POM_Classes.SpendAnalyzer.SaveThisSearchConfirmModal;
import POM_Classes.SpendAnalyzer.TimePeriod;
import POM_Classes.Statements;
import POM_Classes.Transactions.AddTimeLabel;
import POM_Classes.Transactions.Categories;
import POM_Classes.Transactions.CustomDateRangeForTime;
import POM_Classes.Transactions.EditModal;
import POM_Classes.Transactions.ExportModal;
import POM_Classes.Transactions.OrderBy;
import atu.testrecorder.ATUTestRecorder;
import atu.testrecorder.exceptions.ATUTestRecorderException;

public class ATransactionTest2 extends BaseClass {

	private static final String CardNumber = null;
	@BeforeSuite
	public void reports() {
		clearreports();
	}

	@BeforeTest
	public void initializestatus() {
		TestCaseStatus = "FAILED";
		record = null;
	}
	
	@Test(priority = 1, enabled = true)
	public void C2411169_VerifyListOfTransactoinBasedOnCategory()
			throws IOException, InterruptedException, ATUTestRecorderException, APIException, AWTException, ParseException {
		   DateTimeFormatter dtf = DateTimeFormatter.ofPattern("MMM dd, yyyy");  
		   LocalDateTime now = LocalDateTime.now();  
		   String toDate = dtf.format(now);
	
	}
	@AfterMethod
	public void afterMethod() throws ATUTestRecorderException {		
		/*endTestcase();
		endResult();
		record.stop();
		closeBrowsers();*/
	}

}
