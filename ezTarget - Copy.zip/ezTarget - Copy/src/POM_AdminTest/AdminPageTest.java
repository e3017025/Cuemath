package POM_AdminTest;

public class AdminPageTest {

}
