import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject

import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile

import internal.GlobalVariable as GlobalVariable

import com.kms.katalon.core.annotation.BeforeTestCase
import com.kms.katalon.core.annotation.BeforeTestSuite
import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.annotation.AfterTestSuite
import com.kms.katalon.core.context.TestCaseContext
import com.kms.katalon.core.context.TestSuiteContext

import org.json.simple.JSONObject

import com.kms.katalon.core.annotation.AfterTestCase
import com.kms.katalon.core.context.TestCaseContext
import com.testrail.connection.APIClient


/* Refer this page to understand that how to use this class
* http://docs.gurock.com/testrail-api2/bindings-java
*/
class NewTestListener {

        public static updateResults(String testCaseId, String Status){
                        APIClient client = new APIClient("https://testrail.fnis.com")
                        client.setUser("e3017025")
                        client.setPassword("Yatheeshafeb30w")            
                        def statusCode;
                        if(Status.equalsIgnoreCase("PASSED")){
                                        statusCode = "1"
                        }
                        else if(Status.equalsIgnoreCase("FAILED")){
                                        statusCode = "5"
                        }
                        else if(Status.equalsIgnoreCase("Blocked")){
                                        statusCode = "2"
                        }
                        else if(Status.equalsIgnoreCase("Untested")){
                                        statusCode = "3"
                        }
                        else if(Status.equalsIgnoreCase("Retest")){
                                        statusCode = "4"
                        }
                        else if(Status.equalsIgnoreCase("In Progress")){
                                        statusCode = "6"
                        }
                        Map data = new HashMap();
                        data.put("status_id", statusCode);
                        data.put("comment", "This test worked fine. Tested By katalon!");
                        JSONObject r = (JSONObject) client.sendPost("add_result/"+testCaseId+"", data);
        }

        /**
        * Executes after every test case ends.
        * @param testCaseContext related information of the executed test case.
        */
        //@AfterTestCase
        def sampleAfterTestCase(TestCaseContext testCaseContext) {
                        String[] testCasesplit= testCaseContext.getTestCaseId().split("/")
                        String testCaseName = testCasesplit[testCasesplit.size()-1]
                        String[] id=testCaseName.split("-")
                        String testrailId = id[0].substring(1, id[0].length())
                        println testrailId
                        String testCaseStatus = testCaseContext.getTestCaseStatus()
                        if(testCaseName.startsWith("T")){
                                        NewTestListener.updateResults(testrailId, testCaseStatus)
                        }
                }
}
