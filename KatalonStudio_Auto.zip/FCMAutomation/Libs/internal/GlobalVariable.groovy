package internal

import com.kms.katalon.core.configuration.RunConfiguration
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase

/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */
public class GlobalVariable {
     
    /**
     * <p>Profile default : FCM Application URL</p>
     */
    public static Object g_environmenturl
     
    /**
     * <p>Profile default : GlobalWaitTimeForEachStep</p>
     */
    public static Object g_timeout
     

    static {
        def allVariables = [:]        
        allVariables.put('default', ['g_environmenturl' : 'https://lab-rduraisamy1.memento-inc.com:442/#/Login', 'g_timeout' : 60])
        
        String profileName = RunConfiguration.getExecutionProfile()
        
        def selectedVariables = allVariables[profileName]
        g_environmenturl = selectedVariables['g_environmenturl']
        g_timeout = selectedVariables['g_timeout']
        
    }
}
