
/**
 * This class is generated automatically by Katalon Studio and should not be modified or deleted.
 */

import java.lang.String

import com.kms.katalon.core.testobject.TestObject

import java.util.HashMap

import java.util.LinkedHashMap


def static "com.fcm.application.utilities.ReloadWhenObjectIsNotPresent.refreshPage"(
    	String tableName	
     , 	String type	) {
    (new com.fcm.application.utilities.ReloadWhenObjectIsNotPresent()).refreshPage(
        	tableName
         , 	type)
}

def static "com.fcm.session.utilities.CleanSession.CleanCache"() {
    (new com.fcm.session.utilities.CleanSession()).CleanCache()
}

def static "com.fcm.search.utilities.GetTableHeadersforsearch.getColumnHeaders"(
    	String searchType	) {
    (new com.fcm.search.utilities.GetTableHeadersforsearch()).getColumnHeaders(
        	searchType)
}

def static "com.fcm.application.utilities.ClearTextField.ClearText"(
    	TestObject object	) {
    (new com.fcm.application.utilities.ClearTextField()).ClearText(
        	object)
}

def static "com.fcm.alert.utilities.SelectText.selectByVisibleText"(
    	TestObject object	
     , 	String Text	) {
    (new com.fcm.alert.utilities.SelectText()).selectByVisibleText(
        	object
         , 	Text)
}

def static "com.fcm.testdata.utilities.ReadExcelData.readExcel"(
    	String SheetName	
     , 	int Rownumber	) {
    (new com.fcm.testdata.utilities.ReadExcelData()).readExcel(
        	SheetName
         , 	Rownumber)
}

def static "com.fcm.testdata.utilities.ReadExcelData.readExcelallvalues"(
    	String SheetName	) {
    (new com.fcm.testdata.utilities.ReadExcelData()).readExcelallvalues(
        	SheetName)
}

def static "com.fcm.testdata.utilities.TraverseHashmap.Traverse"(
    	HashMap map	) {
    (new com.fcm.testdata.utilities.TraverseHashmap()).Traverse(
        	map)
}

def static "com.fcm.application.utilities.LogoutSession.Logout"(
    	TestObject object	) {
    (new com.fcm.application.utilities.LogoutSession()).Logout(
        	object)
}

def static "com.fcm.testdata.utilities.DropFiles.Landingzone"(
    	String TestCasename	) {
    (new com.fcm.testdata.utilities.DropFiles()).Landingzone(
        	TestCasename)
}

def static "com.fcm.search.utilities.GetFieldType.getFieldType"(
    	String fieldName	) {
    (new com.fcm.search.utilities.GetFieldType()).getFieldType(
        	fieldName)
}

def static "com.fcm.application.utilities.GetNumberofRows.getValuefromWebTable"(
    	TestObject baseobject	) {
    (new com.fcm.application.utilities.GetNumberofRows()).getValuefromWebTable(
        	baseobject)
}

def static "com.fcm.application.utilities.LogoutUsingMouseOver.Logout"() {
    (new com.fcm.application.utilities.LogoutUsingMouseOver()).Logout()
}

def static "com.fcm.database.utilities.database.connectDB"(
    	String server	
     , 	String port	
     , 	String dbname	
     , 	String username	
     , 	String password	) {
    (new com.fcm.database.utilities.database()).connectDB(
        	server
         , 	port
         , 	dbname
         , 	username
         , 	password)
}

def static "com.fcm.database.utilities.database.executeQuery"(
    	String queryString	) {
    (new com.fcm.database.utilities.database()).executeQuery(
        	queryString)
}

def static "com.fcm.database.utilities.database.closeDatabaseConnection"() {
    (new com.fcm.database.utilities.database()).closeDatabaseConnection()
}

def static "com.fcm.search.utilities.GetTableAsKeyAndMultipleValuesforSearch.getColumnHeaders"(
    	String searchType	
     , 	int numberofRows	) {
    (new com.fcm.search.utilities.GetTableAsKeyAndMultipleValuesforSearch()).getColumnHeaders(
        	searchType
         , 	numberofRows)
}

def static "com.fcm.search.utilities.GetTableAsKeyValueforSearch.getColumnHeaders"(
    	String searchType	
     , 	String rowIndex	) {
    (new com.fcm.search.utilities.GetTableAsKeyValueforSearch()).getColumnHeaders(
        	searchType
         , 	rowIndex)
}

def static "com.fcm.alert.utilities.GetTableHeaders.getColumnHeaders"(
    	String tableName	) {
    (new com.fcm.alert.utilities.GetTableHeaders()).getColumnHeaders(
        	tableName)
}

def static "com.fcm.search.utilities.GetTableRowValuesforSearch.getColumnHeaders"(
    	String searchType	
     , 	String rowIndex	) {
    (new com.fcm.search.utilities.GetTableRowValuesforSearch()).getColumnHeaders(
        	searchType
         , 	rowIndex)
}

def static "com.fcm.application.utilities.IterateKeys.IterateKeysFromMap"(
    	java.util.LinkedHashMap<String, java.util.List<String>> map	
     , 	String Key	
     , 	String expectedValue	) {
    (new com.fcm.application.utilities.IterateKeys()).IterateKeysFromMap(
        	map
         , 	Key
         , 	expectedValue)
}

def static "com.fcm.alert.utilities.GetTableAsKeyValue.getColumnHeaders"(
    	String tableName	
     , 	String rowIndex	) {
    (new com.fcm.alert.utilities.GetTableAsKeyValue()).getColumnHeaders(
        	tableName
         , 	rowIndex)
}

def static "com.fcm.search.utilities.GetExpectedHeaders.getColumnHeaders"(
    	String searchType	) {
    (new com.fcm.search.utilities.GetExpectedHeaders()).getColumnHeaders(
        	searchType)
}

def static "com.fcm.alert.utilities.GetTableRowValues.getColumnHeaders"(
    	String tableName	
     , 	String rowIndex	) {
    (new com.fcm.alert.utilities.GetTableRowValues()).getColumnHeaders(
        	tableName
         , 	rowIndex)
}

def static "com.fcm.application.utilities.WaitForExpectedElement.explicitWait"(
    	String byObject	
     , 	String locator	) {
    (new com.fcm.application.utilities.WaitForExpectedElement()).explicitWait(
        	byObject
         , 	locator)
}

def static "com.fcm.application.utilities.POM.VerifyPage"(
    	String PageName	) {
    (new com.fcm.application.utilities.POM()).VerifyPage(
        	PageName)
}

def static "com.fcm.application.utilities.POM.getlocators"(
    	Object PageName	) {
    (new com.fcm.application.utilities.POM()).getlocators(
        	PageName)
}

def static "com.fcm.alert.utilities.GetTableAsKeyAndMultipleValues.getColumnHeaders"(
    	String tableName	
     , 	int numberofRows	) {
    (new com.fcm.alert.utilities.GetTableAsKeyAndMultipleValues()).getColumnHeaders(
        	tableName
         , 	numberofRows)
}
