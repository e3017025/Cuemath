<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>icon_exporticon</name>
   <tag></tag>
   <elementGuidId>0f5fb21e-cde6-41cc-9228-66928afa2a18</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'fa fa-download'][count(. | id(&quot;exportBtnAmwb&quot;)/i[@class=&quot;fa fa-download&quot;]) = count(id(&quot;exportBtnAmwb&quot;)/i[@class=&quot;fa fa-download&quot;])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-download</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;exportBtnAmwb&quot;)/i[@class=&quot;fa fa-download&quot;]</value>
   </webElementProperties>
</WebElementEntity>
