<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_ClaimCheckBox</name>
   <tag></tag>
   <elementGuidId>5c052ca6-adf8-4bb9-8355-1e90698b5366</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@class='jqx-checkbox-default jqx-checkbox-default-fis jqx-fill-state-normal jqx-fill-state-normal-fis jqx-rc-all jqx-rc-all-fis']
</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
