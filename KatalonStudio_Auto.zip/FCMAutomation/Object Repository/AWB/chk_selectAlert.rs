<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>chk_selectAlert</name>
   <tag></tag>
   <elementGuidId>c5110dbd-f1c8-4cb8-a646-e3d94314c1c7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@class='jqx-grid-cell jqx-grid-cell-fis jqx-item jqx-item-fis jqx-grid-cell-pinned jqx-grid-cell-pinned-fis']/div[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@class=&quot;jqx-checkbox-default jqx-checkbox-default-fis jqx-fill-state-normal jqx-fill-state-normal-fis jqx-rc-all jqx-rc-all-fis jqx-checkbox-hover jqx-checkbox-hover-fis jqx-fill-state-hover jqx-fill-state-hover-fis&quot;]/div[1]</value>
   </webElementProperties>
</WebElementEntity>
