<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_okButton</name>
   <tag></tag>
   <elementGuidId>61a65567-ff72-4cca-9d6a-9c34bbe558c6</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>body > div.dialogueBox.fcm-modal-popup.fcm-popup-width-sm.modal.fade.in > div > div > div.modal-body > div:nth-child(2) > div > div > fis-button</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>body > div.dialogueBox.fcm-modal-popup.fcm-popup-width-sm.modal.fade.in > div > div > div.modal-body > div:nth-child(2) > div > div > fis-button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[6]/div/div/div[3]/div[2]/div/div/fis-button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > div.dialogueBox.fcm-modal-popup.fcm-popup-width-sm.modal.fade.in > div > div > div.modal-body > div:nth-child(2) > div > div > fis-button</value>
   </webElementProperties>
</WebElementEntity>
