<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>btn_okButton</name>
   <tag></tag>
   <elementGuidId>3c365d37-c76e-406f-b91b-a42c4288758f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'btn btn-primary ng-binding'][count(. | //*[@ng-click = 'refreshDetails()']) = count(//*[@ng-click = 'refreshDetails()'])][count(. | //*[text() = '
                        Ok
                    ']) = count(//*[text() = '
                        Ok
                    '])]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body > div.dialogueBox.fcm-modal-popup.fcm-popup-width-md.modal.fade.in.ng-scope > div > div > div.modal-body > div:nth-child(2) > div > div > button</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary ng-binding</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-click</name>
      <type>Main</type>
      <value>refreshDetails()</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                        Ok
                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;ng-scope fcm-pad-rgt-0&quot;]/div[@class=&quot;dialogueBox fcm-modal-popup fcm-popup-width-md modal fade in ng-scope&quot;]/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;row pad-top-15 ng-scope&quot;]/div[@class=&quot;col-lg-12 text-center&quot;]/div[@class=&quot;form-group&quot;]/button[@class=&quot;btn btn-primary ng-binding&quot;]</value>
   </webElementProperties>
</WebElementEntity>
