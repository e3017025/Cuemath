<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>lnk_dashboardsettings</name>
   <tag></tag>
   <elementGuidId>dcc4e95e-209c-4105-8715-17bf55c0b9a7</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-binding</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Dashboard Settings</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;mainViewContainer&quot;)/div[@class=&quot;top-page fcm-dasboard ng-scope&quot;]/div[@class=&quot;fcm-banner&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-lg-10 col-md-10&quot;]/div[@class=&quot;form-inline pull-left col-lg-8 col-md-8  col-sm-8&quot;]/a[1]/span[@class=&quot;ng-binding&quot;]</value>
   </webElementProperties>
</WebElementEntity>
