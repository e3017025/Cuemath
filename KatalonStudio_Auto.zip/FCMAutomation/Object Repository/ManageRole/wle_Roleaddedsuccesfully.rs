<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>wle_Roleaddedsuccesfully</name>
   <tag></tag>
   <elementGuidId>b0e3b9e1-b3f4-43af-b4dc-1fd0c9480a0b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html[1]/body[@class=&quot;ng-scope fcm-pad-rgt-0 modal-open&quot;]/div[@class=&quot;dialogueBox fcm-modal-popup fcm-popup-width-sm modal fade in&quot;]/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;row pad-top-15 ng-scope&quot;]/div[@class=&quot;col-lg-12 text-center&quot;]/p[@class=&quot;ng-binding&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>css</name>
      <type>Main</type>
      <value>body > div.dialogueBox.fcm-modal-popup.fcm-popup-width-sm.modal.fade.in > div > div > div.modal-body > div > div:nth-child(1) > p</value>
   </webElementProperties>
</WebElementEntity>
