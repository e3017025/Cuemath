<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ddl_searchField</name>
   <tag></tag>
   <elementGuidId>9409bf4d-104c-4521-b080-65afe68bff68</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control  fis-ach-dropdown ng-pristine ng-valid ng-empty ng-touched</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-model</name>
      <type>Main</type>
      <value>query.value</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-options</name>
      <type>Main</type>
      <value>d.id as d.description for d in actypes</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>ACHACH/OriginationDepositDeposit/Deposit NewDeposit/DepositDeposit/KitingDeposit/BlacklistDeposit/DuplicateDeposit/Deposit To DormantOn-UsOn-Us/On-Us BehaviorOn-Us/On-Us BlacklistOn-Us/On-Us DormantOn-Us/On-Us DuplicateOn-Us/On-Us Out of PatternWLRWLR/Ad Hoc SingleWLR/WLR</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pageSlide&quot;)/div[@class=&quot;container-fluid&quot;]/fis-fcm-search[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[1]/form[@class=&quot;ng-valid ng-dirty ng-valid-parse ng-valid-required&quot;]/fieldset[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;panel panel-default&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;row ng-scope&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;ng-scope&quot;]/select</value>
   </webElementProperties>
</WebElementEntity>
