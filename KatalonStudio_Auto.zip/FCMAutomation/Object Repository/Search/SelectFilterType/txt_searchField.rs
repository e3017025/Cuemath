<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>txt_searchField</name>
   <tag></tag>
   <elementGuidId>89d0682a-a3a7-4792-86da-273fae85d14c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
      <value>query.field.operatorClass == 'DatabaseIdentifier' || query.field.operatorClass == 'Key' || query.field.operatorClass == 'EqualsOrContains' || query.field.operatorClass == 'Text'</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-model</name>
      <type>Main</type>
      <value>query.value</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control ng-pristine ng-untouched ng-valid ng-scope ng-empty</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pageSlide&quot;)/div[@class=&quot;container-fluid&quot;]/fis-fcm-search[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[1]/form[@class=&quot;ng-valid ng-dirty ng-valid-parse ng-valid-required&quot;]/fieldset[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;panel panel-default&quot;]/div[@class=&quot;panel-body&quot;]/div[@class=&quot;row ng-scope&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;ng-scope&quot;]/input[@class=&quot;form-control ng-pristine ng-untouched ng-valid ng-scope ng-empty&quot;]</value>
   </webElementProperties>
</WebElementEntity>
