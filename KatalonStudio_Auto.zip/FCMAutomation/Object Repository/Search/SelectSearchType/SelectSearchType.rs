<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>SelectSearchType</name>
   <tag></tag>
   <elementGuidId>ee929b02-8177-4f7a-a030-a9396a06d56e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//div[@class='ui-select-choices-row ng-scope'] / a / span[text() = '${text}']</value>
   </webElementProperties>
</WebElementEntity>
