<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Search Type</name>
   <tag></tag>
   <elementGuidId>3b6bd81c-70ba-4259-83cd-387f573132ba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[count(. | //*[@ng-show = '$select.isEmpty()']) = count(//*[@ng-show = '$select.isEmpty()'])][count(. | //*[@class = 'ui-select-placeholder text-muted ng-binding']) = count(//*[@class = 'ui-select-placeholder text-muted ng-binding'])][count(. | //*[text() = 'Search Type']) = count(//*[text() = 'Search Type'])][count(. | id(&quot;pageSlide&quot;)/div[@class=&quot;container-fluid&quot;]/fis-fcm-search[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[1]/form[@class=&quot;ng-pristine ng-valid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-4&quot;]/div[@class=&quot;ui-select-container ui-select-bootstrap dropdown ng-pristine ng-valid ng-scope ng-empty ng-touched&quot;]/div[@class=&quot;ui-select-match ng-scope&quot;]/span[@class=&quot;btn btn-default form-control ui-select-toggle&quot;]/span[@class=&quot;ui-select-placeholder text-muted ng-binding&quot;]) = count(id(&quot;pageSlide&quot;)/div[@class=&quot;container-fluid&quot;]/fis-fcm-search[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[1]/form[@class=&quot;ng-pristine ng-valid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-4&quot;]/div[@class=&quot;ui-select-container ui-select-bootstrap dropdown ng-pristine ng-valid ng-scope ng-empty ng-touched&quot;]/div[@class=&quot;ui-select-match ng-scope&quot;]/span[@class=&quot;btn btn-default form-control ui-select-toggle&quot;]/span[@class=&quot;ui-select-placeholder text-muted ng-binding&quot;])]</value>
      </entry>
      <entry>
         <key>CSS</key>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-show</name>
      <type>Main</type>
      <value>$select.isEmpty()</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ui-select-placeholder text-muted ng-binding</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Search Type</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pageSlide&quot;)/div[@class=&quot;container-fluid&quot;]/fis-fcm-search[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[1]/form[@class=&quot;ng-pristine ng-valid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-4&quot;]/div[@class=&quot;ui-select-container ui-select-bootstrap dropdown ng-pristine ng-valid ng-scope ng-empty ng-touched&quot;]/div[@class=&quot;ui-select-match ng-scope&quot;]/span[@class=&quot;btn btn-default form-control ui-select-toggle&quot;]/span[@class=&quot;ui-select-placeholder text-muted ng-binding&quot;]</value>
   </webElementProperties>
</WebElementEntity>
