<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_caret pull-right</name>
   <tag></tag>
   <elementGuidId>42054a42-86c0-4fc2-a75c-368b7e148363</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//i[count(. | //*[@class = 'caret pull-right']) = count(//*[@class = 'caret pull-right'])][count(. | id(&quot;pageSlide&quot;)/div[@class=&quot;container-fluid&quot;]/fis-fcm-search[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[1]/form[@class=&quot;ng-pristine ng-valid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-4&quot;]/div[@class=&quot;ui-select-container ui-select-bootstrap dropdown ng-pristine ng-valid ng-scope ng-empty ng-touched&quot;]/div[@class=&quot;ui-select-match ng-scope&quot;]/span[@class=&quot;btn btn-default form-control ui-select-toggle&quot;]/i[@class=&quot;caret pull-right&quot;]) = count(id(&quot;pageSlide&quot;)/div[@class=&quot;container-fluid&quot;]/fis-fcm-search[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[1]/form[@class=&quot;ng-pristine ng-valid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-4&quot;]/div[@class=&quot;ui-select-container ui-select-bootstrap dropdown ng-pristine ng-valid ng-scope ng-empty ng-touched&quot;]/div[@class=&quot;ui-select-match ng-scope&quot;]/span[@class=&quot;btn btn-default form-control ui-select-toggle&quot;]/i[@class=&quot;caret pull-right&quot;])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>caret pull-right</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-click</name>
      <type>Main</type>
      <value>$select.toggle($event)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;pageSlide&quot;)/div[@class=&quot;container-fluid&quot;]/fis-fcm-search[@class=&quot;ng-scope ng-isolate-scope&quot;]/div[1]/form[@class=&quot;ng-pristine ng-valid&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-4&quot;]/div[@class=&quot;ui-select-container ui-select-bootstrap dropdown ng-pristine ng-valid ng-scope ng-empty ng-touched&quot;]/div[@class=&quot;ui-select-match ng-scope&quot;]/span[@class=&quot;btn btn-default form-control ui-select-toggle&quot;]/i[@class=&quot;caret pull-right&quot;]</value>
   </webElementProperties>
</WebElementEntity>
