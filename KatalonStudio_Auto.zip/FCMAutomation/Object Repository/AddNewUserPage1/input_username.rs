<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_username</name>
   <tag></tag>
   <elementGuidId>b4184e12-7746-44d0-90e4-344971e9432c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//input[count(. | //*[@type = 'text']) = count(//*[@type = 'text'])][count(. | //*[@class = 'form-control ng-pristine ng-valid ng-empty ng-valid-maxlength ng-touched']) = count(//*[@class = 'form-control ng-pristine ng-valid ng-empty ng-valid-maxlength ng-touched'])][count(. | //*[@ng-show = 'initTextField('username')']) = count(//*[@ng-show = 'initTextField('username')'])][count(. | //*[@ng-model = 'userData.name']) = count(//*[@ng-model = 'userData.name'])][count(. | //*[@id = 'username']) = count(//*[@id = 'username'])][count(. | //*[@ng-disabled = 'false']) = count(//*[@ng-disabled = 'false'])][count(. | //*[@maxlength = '50']) = count(//*[@maxlength = '50'])][count(. | id(&quot;username&quot;)) = count(id(&quot;username&quot;))]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>//*[@id=&quot;username&quot;]</value>
   </webElementProperties>
</WebElementEntity>
