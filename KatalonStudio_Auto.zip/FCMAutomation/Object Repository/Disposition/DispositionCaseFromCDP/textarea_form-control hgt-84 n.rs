<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>textarea_form-control hgt-84 n</name>
   <tag></tag>
   <elementGuidId>f957f338-b74d-43c5-9ea0-fd726e7fe353</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>textarea</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control hgt-84 ng-pristine ng-untouched ng-valid ng-empty</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-model</name>
      <type>Main</type>
      <value>dispositionActionText.Note</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;ng-scope modal-open fcm-pad-rgt-0&quot;]/div[@class=&quot;dialogueBox fcm-popup-width-md-lg modal fade in ng-scope&quot;]/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;ng-scope printSection&quot;]/form[@class=&quot;fis-ach ng-pristine ng-valid ng-valid-required&quot;]/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-sm-10&quot;]/textarea[@class=&quot;form-control hgt-84 ng-pristine ng-untouched ng-valid ng-empty&quot;]</value>
   </webElementProperties>
</WebElementEntity>
