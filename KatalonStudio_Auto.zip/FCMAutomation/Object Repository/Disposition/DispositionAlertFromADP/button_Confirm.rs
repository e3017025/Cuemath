<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Confirm</name>
   <tag></tag>
   <elementGuidId>6f2991b0-12de-4846-88a5-26f63d6a3f0d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html/body/div[4]/div/div/div[3]/div[3]/div[7]/div/div/button[1]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>body > div.dialogueBox.fcm-popup-width-md-lg.modal.fade.in.ng-scope > div > div > div.modal-body > div.fis-ach.ng-scope > div:nth-child(7) > div > div > button.btn.btn-primary.ng-binding</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[4]/div/div/div[3]/div[3]/div[7]/div/div/button[1]</value>
   </webElementProperties>
</WebElementEntity>
