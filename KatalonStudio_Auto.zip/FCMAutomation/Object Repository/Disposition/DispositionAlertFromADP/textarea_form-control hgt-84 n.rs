<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>textarea_form-control hgt-84 n</name>
   <tag></tag>
   <elementGuidId>739fc75e-a027-4f20-a539-fac7c52be402</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@c</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html/body/div[8]/div/div/div[3]/div[3]/div[5]/div/div/textarea</value>
   </webElementProperties>
</WebElementEntity>
