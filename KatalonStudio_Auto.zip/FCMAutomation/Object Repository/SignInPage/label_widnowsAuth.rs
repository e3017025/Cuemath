<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>label_widnowsAuth</name>
   <tag></tag>
   <elementGuidId>60ae39a0-3c88-4fe7-8bbc-6ad6facc0965</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@id = 'labelForWindowsAuth']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>labelForWindowsAuth</value>
   </webElementProperties>
</WebElementEntity>
