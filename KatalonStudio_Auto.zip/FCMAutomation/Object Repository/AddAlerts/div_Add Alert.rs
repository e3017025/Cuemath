<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Add Alert</name>
   <tag></tag>
   <elementGuidId>453d6498-c88b-491d-a657-8513056dcb5b</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>large-modal modal fade in</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-backdrop</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-keyboard</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>pagetitle</name>
      <type>Main</type>
      <value>Add Alert</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>visible</name>
      <type>Main</type>
      <value>associateModel.showAssociateAlerts</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>close-modal-override</name>
      <type>Main</type>
      <value>closeSummaryModals()</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
        
            
                

                    
                    Add Alert

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
        
        
            

    
        
            
                Select Type to Search
                Search Type 
                        Alert records
                      
            

        
        
        
            
                
                    
                        Search Query
                        
                            
                                
                                    Field
                                
                                
                                    Operator
                                
                                
                                    Value to Search
                                
                                
                                    Remove Row
                                

                            
                            
                                
                                    Alert NumberAlert TypeAlert DescriptionAssigned ToAccount IDClose ReasonCreatedCustomer IDCustomer NamePhone NumberUpdatedStatusCompany IDCompany Name
                                
                                
                                    EqualsNotEquals
                                
                                
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                        
                                        
                                        
                                    
                                    
                                    
                                        
                                                0 Status selected, please select 1 or more...

                                        
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    
                                    

                                    

                                    
                                    
                                    
                                    
                                    
                                    
                                

                                
                                    
                                
                            
                            
                                
                                    
                                
                            
                        
                    
                
            
        
        
            
                
                    
                        
                            Run Search
                        
                        
                            
                        
                        
                            
                        
                        
                            Cancel
                        
                    
                    
                
            
        
    
    
        
            Searching... 
        
    

    

    

    

    
    
    

    

    
    
    



    
        
            
                

                    
                    Reason Details

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
    
        Close
    

        
    




    
        
            
                

                    
                    Excess Presentment

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    



    

    
        Close
    


        
    
 


    
        
            
                

                    
                    Duplicate

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    



    

    
        Close
    

        
    



    
        
            
                

                    
                    Blank Serial

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    



    

    
        Close
    


        
    



    
        
            
                

                    
                    Suspected Fraud

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    



            
                
                    
                        Reported Amounts by Fraud Alert Date
                    
                
            

            
                
                
    
        
            
            
            
        
    

            
            
                Close
            

    
        
    




    
        
            
                

                    
                    Dormant Account

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    



    

    
        Close
    


        
    






    
        
            
                

                    
                    Blacklist

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    



    

    
        Close
    


        
    




    
        
            
                

                    
                    Serial Number Variance

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    

    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                

            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Group: 
                

                
                    Serial Number
                
                
                    Amount
                

                
                    Item Routing
                              
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
             
            
        
    



    
        
            
                Serial Number by Posted Date
            
        
    
    

    
        Close
    


        
    



    
        
            
                

                    
                    Dollar Amount Variance

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    



    
        
            
                Risk by Dollar Amount
            
        
    

    
        
        
    
        
            
            
            
        
    

    

    

    
        Close
    


        
    



    
        
            
                

                    
                    Velocity

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    


    
        
            
            
                
                    Anticipated Check Count
                
                
                    Posted Check Count
                
            
            
                
                    0
                
                
                    0
                
            
        
    
    
        
            
                Number of Presented Checks by Posting Date
            
        
    
    

    

    
        Close
    

        
    




    
        
            
                

                    
                    Timing Amount

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    


    
        
            
            
                
                    Anticipated Debit Amount
                
                
                    Posted Debit Amount
                
            
            
                
                    
                
                
                    $0.00
                
            
        
    
    
        
            
                Amount by Posting Date
            
        
    
    
        
        
    
        
            
            
            
        
    

    

    

    
        Close
    

        
    




    
        
            
                

                    
                    Timing Periodic

                    
                        
                        
                    
                    
                        
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            

    
    
        
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Risk
                
                
                    Exposure
                
                
                    Group: 
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    

    
        
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Item Account
                
                
                    Item Routing
                
                
                    Sequence
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    


        
    
        
            
                
                    
                
            
            
            
                Day of Week
                
                
                
                
                
                
            
            
                
                    
                

                
                    
                        
                    
                

                
                
                
                

                


                
                

                

                

                
                    
                    ImagesData
                    
                        
                        
                                        
                
                
                    
                        
                    
                    
                        
                        
                             Print
                        
                        
                    
                

            
        

    

    
    
            
            
        
    
        
    
    
        
            
            
            
        
    

    

    


        
    
        
            
                
                    
                
            
            
            
                Day of Month
                
                
                
                
                
                
            
            
                
                    
                

                
                    
                        
                    
                

                
                
                
                

                


                
                

                

                

                
                    
                    ImagesData
                    
                        
                        
                                        
                
                
                    
                        
                    
                    
                        
                        
                             Print
                        
                        
                    
                

            
        

    

    
    
            
            
        
    
        
    
    
        
            
            
            
        
    

    

    


    
        Close
    

        
    





    
        
            
                

                    
                    Indicator Summary

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
        
            
            
            
                
                    Account
                
                
                    Open Date
                
                
                    Posted Date
                
                
                    Score
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    



    
        
            
            
            
                
                    Serial Number
                
                
                    Amount
                
                
                    Sequence
                
                
                    Item Score
                
                
                    Description
                
            
            
                
                    
                
                
                    
                
                
                    
                
                
                    
                
                
                    
                
            
        
    
    
    
        
            
                
                
                    
                        Indicator Overview: Indicator, Significance and Exposure
                    
                
            
            
                
                    
                        
                    
                
            
        
    

    
        Close
    

        
    





    
        
            
                

                    
                    

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
        
            
        
        
        

        

        

        
        

        
            Close
        
    

        
    



    
        
            
                

                    
                    Audit Details

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
        Created: 
    
    
        Full Name: 
    
    
        User Name: 
    
    
        Audit Group: 
    
    
        Audit Event: 
    
    
        Event Details:
        
            
                Key
                Value
            
            
        
    
    
        Close
    

        
    



    
        
            
                

                    
                    Log Details

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
        Created: 
    
    
        Severity: 
    
    
        Domain: 
    
    
        Process: 
    
    
        Thread: 
    
    
        Server: 
    
    
        Message: 
    

    
        Entry Details:
        
            
                Key
                Value
            
            
        
    
    
        Close
    

        
    



    
        
            
                

                    
                    Deposit

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
        
        
    
    
        Close
    

        
    



    
        
            
                

                    
                    Search Page Reports

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
        Your search query is finding too many records to return results in a reasonable amount of time. Please specify additional field filters in your query to reduce the number of results.
    
    
        Close
    

        
    




    
    
        
            
                

                    
                    Claim Alert

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
        
            
                 
                Proceeding with claiming the selected alert(s) will clear the existing Disposition decision.
                
                    
                
            
            
                
                    
                
            
                
                    
                        
                            
                                Confirm
                                Cancel
                            
                        
                    
                
            
    
        
    




    
        
            
                

                    
                    External Account Details

                    
                        
                        
                    
                    

                    
                
            
            
                
                    
                        
                        
                    
                
            
            
    
        
            Account
            
            
        
        
            Number
            
        
        
            Routing
            
        
    
    
    
        
        Set as Primary Number/Routing
    
    
    
    
    Close

        
    


        
    
        
    
</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;ng-scope fcm-pad-rgt-0&quot;]/div[@class=&quot;large-modal modal fade in&quot;]</value>
   </webElementProperties>
</WebElementEntity>
