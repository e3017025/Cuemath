<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>li_Add to new case</name>
   <tag></tag>
   <elementGuidId>9992a343-3ec1-4e6c-a72a-995baa139c58</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>li</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>allowUnassignedDisposition ng-binding</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-show</name>
      <type>Main</type>
      <value>authService.authentication.permissions.Cases_Create</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-click</name>
      <type>Main</type>
      <value>addToNewCase()</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    Add to new case
                                </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;alertDetailsPage&quot;)/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-alert-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 topdiv&quot;]/div[@class=&quot;col-lg-1 col-md-1 printHide&quot;]/div[@class=&quot;pull-right pad-rgt-4&quot;]/div[@class=&quot;dropdown open&quot;]/div[@class=&quot;dropdown-menu fcm-arrow_box fcm-alert-filter fcm-dd-menu&quot;]/ul[@class=&quot;actiondropdown&quot;]/li[@class=&quot;allowUnassignedDisposition ng-binding&quot;]</value>
   </webElementProperties>
</WebElementEntity>
