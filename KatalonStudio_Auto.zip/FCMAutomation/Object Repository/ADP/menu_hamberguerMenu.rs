<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>menu_hamberguerMenu</name>
   <tag></tag>
   <elementGuidId>4039892a-0aef-4fd9-9680-389d5f8b528d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>icon-Menu fcm-ellipsis</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;alertDetailsPage&quot;)/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-alert-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-xs-12 topdiv&quot;]/div[@class=&quot;col-lg-1 col-md-1 printHide&quot;]/div[@class=&quot;pull-right pad-rgt-4&quot;]/div[@class=&quot;dropdown&quot;]/span[@class=&quot;dropdown-toggle&quot;]/span[@class=&quot;icon-Menu fcm-ellipsis&quot;]</value>
   </webElementProperties>
</WebElementEntity>
