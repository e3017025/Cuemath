<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_CLOSED</name>
   <tag></tag>
   <elementGuidId>016c1ac2-994a-4082-b2bf-2f5ebb77371e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//span[count(. | id(&quot;alertDetailsPage&quot;)/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-alert-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;col-xs-12 paddingwrapper thirdrowdiv printSection&quot;]/div[@class=&quot;col-xs-6 paddingwrapper&quot;]/div[@class=&quot;frauddiv&quot;]/span[@class=&quot;fcm-gray-status pad-rgt-10 ng-binding ng-scope&quot;]) = count(id(&quot;alertDetailsPage&quot;)/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-alert-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;col-xs-12 paddingwrapper thirdrowdiv printSection&quot;]/div[@class=&quot;col-xs-6 paddingwrapper&quot;]/div[@class=&quot;frauddiv&quot;]/span[@class=&quot;fcm-gray-status pad-rgt-10 ng-binding ng-scope&quot;])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fcm-gray-status pad-rgt-10 ng-binding ng-scope</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
      <value>currentDispStatus !== translate_open</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>CLOSED</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;alertDetailsPage&quot;)/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-alert-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;col-xs-12 paddingwrapper thirdrowdiv printSection&quot;]/div[@class=&quot;col-xs-6 paddingwrapper&quot;]/div[@class=&quot;frauddiv&quot;]/span[@class=&quot;fcm-gray-status pad-rgt-10 ng-binding ng-scope&quot;]</value>
   </webElementProperties>
</WebElementEntity>
