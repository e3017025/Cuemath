<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_Not Fraud</name>
   <tag></tag>
   <elementGuidId>a67ba1a9-cefb-4f32-8ba5-1789d38bb357</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@class = 'fcm-teal-reason ng-binding'][count(. | id(&quot;alertDetailsPage&quot;)/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-alert-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;col-xs-12 paddingwrapper thirdrowdiv printSection&quot;]/div[@class=&quot;col-xs-6 paddingwrapper&quot;]/div[@class=&quot;frauddiv&quot;]/span[@class=&quot;fcm-teal-reason ng-binding&quot;]) = count(id(&quot;alertDetailsPage&quot;)/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-alert-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;col-xs-12 paddingwrapper thirdrowdiv printSection&quot;]/div[@class=&quot;col-xs-6 paddingwrapper&quot;]/div[@class=&quot;frauddiv&quot;]/span[@class=&quot;fcm-teal-reason ng-binding&quot;])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fcm-teal-reason ng-binding</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Not Fraud : </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;alertDetailsPage&quot;)/div[1]/div[@class=&quot;ng-scope&quot;]/div[1]/div[@class=&quot;ng-scope&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-alert-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;col-xs-12 paddingwrapper thirdrowdiv printSection&quot;]/div[@class=&quot;col-xs-6 paddingwrapper&quot;]/div[@class=&quot;frauddiv&quot;]/span[@class=&quot;fcm-teal-reason ng-binding&quot;]</value>
   </webElementProperties>
</WebElementEntity>
