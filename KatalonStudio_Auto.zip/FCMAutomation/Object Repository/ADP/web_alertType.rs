<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>web_alertType</name>
   <tag></tag>
   <elementGuidId>120c24bc-8109-4592-b734-fff78117dc15</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>#alertDetailsPage > div:nth-child(1) > div.ng-scope > div > div > div > div > div:nth-child(1) > fis-fcm-alert-summary-card > div.col-xs-12.dw-content-shaded.alertsummarydiv.printSection > div.row.col-xs-12.secondrowdiv.printSection > div.col-xs-9.readOnly-normal > div.secondrowbolddata > span.ng-binding.ng-scope</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
