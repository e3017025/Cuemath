<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Cancel</name>
   <tag></tag>
   <elementGuidId>9548c2de-d1a6-4942-bf43-253da03bb97e</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html[1]/body/div[@class=&quot;dialogueBox fcm-modal-popup fcm-popup-width-sm modal fade in&quot;]/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;row pad-top-15 ng-scope&quot;]/div[@class=&quot;col-lg-12 text-center&quot;]/div[@class=&quot;form-group&quot;]/button[@class=&quot;btn-default ng-binding&quot;][count(. | //button[@type = 'button' and (text() = '
                    Cancel
                ' or . = '
                    Cancel
                ')]) = count(//button[@type = 'button' and (text() = '
                    Cancel
                ' or . = '
                    Cancel
                ')])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn-default ng-binding</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-click</name>
      <type>Main</type>
      <value>closeDeleteUserModel()</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    Cancel
                </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body/div[@class=&quot;dialogueBox fcm-modal-popup fcm-popup-width-sm modal fade in&quot;]/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;row pad-top-15 ng-scope&quot;]/div[@class=&quot;col-lg-12 text-center&quot;]/div[@class=&quot;form-group&quot;]/button[@class=&quot;btn-default ng-binding&quot;]</value>
   </webElementProperties>
</WebElementEntity>
