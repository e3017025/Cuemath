<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>p_Do you want to inactivate th</name>
   <tag></tag>
   <elementGuidId>de4c9c36-b171-4656-9f1e-acdb9ccf55df</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>/html[1]/body/div[@class=&quot;dialogueBox fcm-modal-popup fcm-popup-width-sm modal fade in&quot;]/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;row pad-top-15 ng-scope&quot;]/div[@class=&quot;col-lg-12 text-center&quot;]/p[@class=&quot;ng-binding&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>p</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>ng-binding</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Do you want to inactivate the user?</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body/div[@class=&quot;dialogueBox fcm-modal-popup fcm-popup-width-sm modal fade in&quot;]/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body&quot;]/div[@class=&quot;row pad-top-15 ng-scope&quot;]/div[@class=&quot;col-lg-12 text-center&quot;]/p[@class=&quot;ng-binding&quot;]</value>
   </webElementProperties>
</WebElementEntity>
