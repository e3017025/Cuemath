<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>web_caseStatus</name>
   <tag></tag>
   <elementGuidId>7b140b41-e96e-4731-b527-4e8a964b8c9c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fcm-gray-status pad-rgt-10 ng-binding ng-scope</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>ng-if</name>
      <type>Main</type>
      <value>(caseDetail.status==='Assigned' || caseDetail.status==='Unassigned')</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                    OPEN
                </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;caseDetailsPage&quot;)/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-case-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;col-xs-12 paddingwrapper thirdrowdiv printSection&quot;]/div[@class=&quot;col-xs-5 paddingwrapper mrg-top-5 mrg-btm-5&quot;]/div[@class=&quot;mrg-rgt-10 pad-top-5 pull-left&quot;]/span[@class=&quot;fcm-gray-status pad-rgt-10 ng-binding ng-scope&quot;]</value>
   </webElementProperties>
</WebElementEntity>
