<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>web_casePriority</name>
   <tag></tag>
   <elementGuidId>87169e18-8e40-4ec3-a14c-6b99149609b4</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>priority ng-binding</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>

                High

            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;caseDetailsPage&quot;)/div[1]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;row ng-scope&quot;]/fis-fcm-case-summary-card[1]/div[@class=&quot;col-xs-12 dw-content-shaded alertsummarydiv printSection&quot;]/div[@class=&quot;row col-xs-12 secondrowdiv printSection&quot;]/div[@class=&quot;col-xs-3&quot;]/div[@class=&quot;priority ng-binding&quot;]</value>
   </webElementProperties>
</WebElementEntity>
