import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import org.junit.After as After
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.internal.WebUIAbstractKeyword as WebUIAbstractKeyword
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

CustomKeywords.'com.fcm.session.utilities.CleanSession.CleanCache'()

WebUI.openBrowser('')

WebUI.navigateToUrl(GlobalVariable.g_environmenturl)

WebUI.maximizeWindow()

/* ArrayList<String> list = new ArrayList<String>()

list.add(findTestObject('SignInPage/txt_username'))

list.add(findTestObject('SignInPage/txt_password'))*/
/* CustomKeywords.'com.fcm.application.utilities.POM.PassingMultipleObject'(findTestObject('SignInPage/txt_username'), 
    findTestObject('SignInPage/txt_password'))*/
//String[] objects = ['txt_username', 'txt_password', 'btn_signinButton', 'label_widnowsAuth']
CustomKeywords.'com.fcm.application.utilities.POM.VerifyPage'('SignInPage')

WebUI.setText(findTestObject('SignInPage/txt_username'), 'username')

CustomKeywords.'com.fcm.application.utilities.ClearTextField.ClearText'(findTestObject('SignInPage/txt_password'))

WebUI.setText(findTestObject('SignInPage/txt_password'), 'password')

