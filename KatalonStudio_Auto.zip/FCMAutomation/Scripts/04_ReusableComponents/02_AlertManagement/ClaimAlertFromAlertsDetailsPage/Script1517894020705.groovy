import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.waitForElementPresent(findTestObject('ClaimAlert/ClaimAlertFromADP/button_Claim'), GlobalVariable.g_timeout)

WebUI.delay(5)

WebUI.click(findTestObject('ClaimAlert/ClaimAlertFromADP/button_Claim'))

WebUI.verifyElementPresent(findTestObject('ClaimAlert/ClaimAlertFromADP/h4_Claim Alert'), 0)

WebUI.click(findTestObject('ClaimAlert/ClaimAlertFromADP/button_Confirm'))

WebUI.verifyElementPresent(findTestObject('ClaimAlert/ClaimAlertFromADP/h4_Success'), 0)

WebUI.getText(findTestObject('ClaimAlert/ClaimAlertFromADP/p_Alert(s) claimed successfull'))

WebUI.click(findTestObject('ClaimAlert/ClaimAlertFromADP/button_Ok'))

dealtalertId = WebUI.getText(findTestObject('ADP/web_alertId'))

assignedTo = WebUI.getText(findTestObject('ADP/web_assignedTo'))

alertType = WebUI.getText(findTestObject('ADP/web_alertType'))

def returnalertid = dealtalertId.replace('#', '')

HashMap<String,String> map = new HashMap<String, String>()

map.put('returnalertid', returnalertid)

map.put('alertType', alertType)

map.put('assignedTo', assignedTo)

return map

