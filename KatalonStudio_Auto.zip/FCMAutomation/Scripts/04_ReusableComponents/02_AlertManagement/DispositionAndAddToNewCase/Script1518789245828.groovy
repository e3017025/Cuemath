import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.delay(10)

WebUI.click(findTestObject('Disposition/DispositionAlertFromADP/ddl_dispositionReasonsDropDown'))

WebUI.selectOptionByLabel(findTestObject('Disposition/DispositionAlertFromADP/ddl_dispositionReasonsDropDown'), dispositionReason, 
    false)

WebUI.click(findTestObject('Disposition/DispositionAlertFromADP/radio_addtoNewCase'))

WebUI.setText(findTestObject('Disposition/AddToNewCAse/input_title'), 'Test')

WebUI.setText(findTestObject('Disposition/AddToNewCAse/textarea_description'), 'Case Description')

WebUI.selectOptionByLabel(findTestObject('Disposition/AddToNewCAse/select_ACH'), 'Deposit', false)

WebUI.click(findTestObject('Disposition/AddToNewCAse/button_Submit'))

WebUI.click(findTestObject('Disposition/AddToNewCAse/button_Confirm'))

successLabelText = WebUI.getText(findTestObject('Disposition/DispositionAlertFromADP/lbl_successlabel'), FailureHandling.STOP_ON_FAILURE)

assert successLabelText == dispositionSuccessLabelText

try {
    WebUI.click(findTestObject('Disposition/AddToNewCAse/button_Ok'))
}
catch (Exception ex) {
    WebUI.click(findTestObject('Disposition/DispositionAlertFromADP/btn_ok'))
} 

try {
    WebUI.waitForElementPresent(findTestObject('ADP/span_CLOSED'), GlobalVariable.g_timeout)

    status = WebUI.getText(findTestObject('ADP/span_CLOSED'))

    assert status == alertStatus

    fraud = WebUI.getText(findTestObject('ADP/span_Not Fraud'))

    assert fraud == 'Not Fraud :'

    reason = WebUI.getText(findTestObject('ADP/span_Approve Customer Approved'))

    assert reason == 'Approve: Account Manager Approval'
}
catch (Exception e) {
    CustomKeywords.'com.fcm.database.utilities.database.connectDB'('10.16.206.154', '1433', 'FCM', 'cganapathy', 'Sundar89$')

    query = (('Select * from [Alert] where ID = \'' + alertId) + '\'')

    HashMap<String, String> ListofAlerts = CustomKeywords.'com.fcm.database.utilities.database.executeQuery'(query)

    ListofAlerts.get('Status') == '3'
} 

