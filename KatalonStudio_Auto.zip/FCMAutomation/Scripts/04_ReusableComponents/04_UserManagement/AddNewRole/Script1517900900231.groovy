import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser(GlobalVariable.g_environmenturl)

WebUI.maximizeWindow()

WebUI.click(findTestObject('SignInPage/chk_windowsAuth'))

WebUI.click(findTestObject('SignInPage/btn_signinButton'))

WebUI.delay(5)

WebUI.click(findTestObject('ManageRole/lnk_Manage Role'))

WebUI.delay(5, FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('ManageRole/btn_AddRole'))

WebUI.click(findTestObject('ManageRole/ddl_rolecategory'))

WebUI.delay(3)

WebUI.selectOptionByLabel(findTestObject('ManageRole/ddl_rolecategory'), roleCategory, true)

WebUI.setText(findTestObject('ManageRole/txt_input_searchrole'), roleCategory)

WebUI.delay(3)

WebUI.click(findTestObject('ManageRole/span_copyrole'))

WebUI.setText(findTestObject('ManageRole/txt_rolename'), System.currentTimeMillis() + roleCategory)

WebUI.setText(findTestObject('ManageRole/txt_roleDesc'), roleDescription)

WebUI.verifyElementVisible(findTestObject('ManageRole/btn_Add'))

WebUI.click(findTestObject('ManageRole/btn_Add'))

WebUI.verifyElementPresent(findTestObject('ManageRole/wle_Roleaddedsuccesfully'), 5)

Successmessage = WebUI.getText(findTestObject('ManageRole/wle_Roleaddedsuccesfully'))

assert Successmessage == 'Role added succesfully'

WebUI.click(findTestObject('ManageRole/wle_fis-button_Ok'), FailureHandling.STOP_ON_FAILURE)

