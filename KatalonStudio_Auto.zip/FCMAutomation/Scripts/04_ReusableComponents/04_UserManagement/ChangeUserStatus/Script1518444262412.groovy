import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import java.util.Date as Date
import java.text.SimpleDateFormat as SimpleDateFormat
import java.text.DateFormat as DateFormat

            
if (changeuserstatus == 'active') 
{
   WebUI.callTestCase(findTestCase('04_ReusableComponents/04_UserManagement/ResetPassword'), [('newPassword') : newPassword
                        , ('expectedresetpasswordsuccessMessage') : expectedresetpasswordsuccessMessage], FailureHandling.STOP_ON_FAILURE)

   return newPassword
}
            
WebUI.waitForElementPresent(findTestObject('ManageUsers/Active_InactiveUser/h4_Warning'), 5)

warningText = WebUI.getText(findTestObject('ManageUsers/Active_InactiveUser/p_Do you want to inactivate th'))

assert warningText == expectedWarningText

WebUI.click(findTestObject('ManageUsers/Active_InactiveUser/button_Yes'))

Thread.sleep(5000)

successModalText = WebUI.getText(findTestObject('ManageUsers/Active_InactiveUser/p_User inactivated successfull'))

assert inactivesuccessMessage == successModalText

WebUI.click(findTestObject('ManageUsers/Active_InactiveUser/button_Ok'))

return newPassword
  
        


