import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import java.util.Date as Date
import java.text.SimpleDateFormat as SimpleDateFormat
import java.text.DateFormat as DateFormat

WebUI.openBrowser(GlobalVariable.g_environmenturl)

WebUI.maximizeWindow()

WebUI.click(findTestObject('SignInPage/chk_windowsAuth'))

WebUI.click(findTestObject('SignInPage/btn_signinButton'))

WebUI.waitForElementPresent(findTestObject('AddNewUserPage1/button_Add User'), 10)

WebUI.click(findTestObject('AddNewUserPage1/button_Add User'))

dynamicuserID = ('CreateUser' + System.currentTimeMillis())

currentpassword = 'Test12345'

confirmpassword = 'Test1234'

WebUI.setText(findTestObject('AddNewUserPage1/input_username'), dynamicuserID)

WebUI.setText(findTestObject('AddNewUserPage1/input_fullName'), dynamicuserID + roleName)

WebUI.setText(findTestObject('AddNewUserPage1/input_userpassword'), currentpassword)

WebUI.setText(findTestObject('AddNewUserPage1/input_confirmuserpassword'), currentpassword)

'Page 1 - Next'
WebUI.click(findTestObject('AddNewUserPage1/button_Next'))

WebUI.delay(10)

WebUI.waitForElementPresent(findTestObject('AddNewUserPage2/select_roleCategory'), 30)

WebUI.click(findTestObject('AddNewUserPage2/select_roleCategory'))

WebUI.selectOptionByLabel(findTestObject('AddNewUserPage2/select_roleCategory'), roleCategory, true)

WebUI.delay(10)

WebUI.waitForElementPresent(findTestObject('AddNewUserPage2/select_roles'), 30)

WebUI.click(findTestObject('AddNewUserPage2/select_roles'))

WebUI.selectOptionByLabel(findTestObject('AddNewUserPage2/select_roles'), roleName, true)

WebUI.click(findTestObject('AddNewUserPage2/button_Add'))

WebUI.waitForElementPresent(findTestObject('AddNewUserPage2/button_Next'), 10)

'Page 2  - Next '
WebUI.click(findTestObject('AddNewUserPage2/button_Next'))

WebUI.delay(2)

'Page 3 - Next'
WebUI.click(findTestObject('AddNewUserPage3/button_Next'))

WebUI.delay(2)

WebUI.click(findTestObject('AddNewUserPage4/chk_ACH'))

WebUI.click(findTestObject('AddNewUserPage4/chk_Deposit'))

WebUI.click(findTestObject('AddNewUserPage4/chk_OnUs'))

WebUI.waitForElementPresent(findTestObject('AddNewUserPage4/chk_subtypeOrigination'), 10)

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeOrigination'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeBlacklist'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeDeposit'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeDepositNew'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeDepositToDormant'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeDuplicate'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeKiting'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeOnUsBehaviour'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeOnUsBlacklist'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeOnUsDormant'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeOnUsDuplicate'))

WebUI.click(findTestObject('AddNewUserPage4/chk_subtypeOnUsOutOfPattern'))

if (secondApprovalRequired.equals(true)) {
	WebUI.click(findTestObject('AddNewUserPage4/chk_2ndApprovalAch'))
	WebUI.click(findTestObject('AddNewUserPage4/chk_2ndApprovalDeposit'))
	WebUI.click(findTestObject('AddNewUserPage4/chk_2ndApprovalOnus'))
	WebUI.click(findTestObject('AddNewUserPage4/chk_dispositionAllReason'))
	WebUI.click(findTestObject('AddNewUserPage4/chk_UnCheckFraud_ReferToSercurityInvestigator'))
}

WebUI.click(findTestObject('AddNewUserPage4/button_finalAddUser'))

WebUI.waitForElementPresent(findTestObject('AddNewUserPage4/button_okButton'), 10)

Successmessage = WebUI.getText(findTestObject('AddNewUserPage4/ttl_successMessage'))

assert Successmessage == 'User added succesfully.'

WebUI.click(findTestObject('AddNewUserPage4/button_okButton'))

HashMap<String, String> map = new HashMap<String, String>()

map.put('UserName', dynamicuserID)

map.put('CurrentPassword', currentpassword)

map.put('ConfirmPassword', confirmpassword)

return map

