import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys
import java.util.Date;
import java.text.SimpleDateFormat

WebUI.waitForElementClickable(findTestObject('HomePage/icon_Search'), GlobalVariable.g_timeout)

WebUI.click(findTestObject('HomePage/icon_Search'))

WebUI.click(findTestObject('Search/SelectSearchType/span_btn btn-default form-cont'))

WebUI.setText(findTestObject('Search/SelectSearchType/input_form-control ui-select-s'), searchType)

WebUI.click(findTestObject('Search/SelectSearchType/a_ui-select-choices-row-inner'))

WebUI.verifyElementPresent(findTestObject('Search/SelectFilterType/banner_SearchQuery'), 1)

WebUI.verifyElementPresent(findTestObject('Search/SelectFilterType/lbl_Field'), 1)

WebUI.verifyElementPresent(findTestObject('Search/SelectFilterType/lbl_Operator'), 1)

WebUI.verifyElementPresent(findTestObject('Search/SelectFilterType/lbl_ValueToSearch'), 1)

WebUI.verifyElementPresent(findTestObject('Search/SelectFilterType/lbl_RemoveRow'), 1)

WebUI.verifyElementPresent(findTestObject('Search/SelectFilterType/input_addButton'), 1)

WebUI.click(findTestObject('Search/SelectFilterType/input_addButton'))

WebUI.selectOptionByLabel(findTestObject('Search/SelectFilterType/ddl_Field'), searchField, false)

WebUI.selectOptionByLabel(findTestObject('Search/SelectFilterType/ddl_Operator'), operator, false)

fieldType = CustomKeywords.'com.fcm.search.utilities.GetFieldType.getFieldType'(searchField)

switch (fieldType) {
    case 'TextBox':
        WebUI.setText(findTestObject('Search/SelectFilterType/txt_searchField'), searchInput)

        break
    case 'DropDown':
        WebUI.click(findTestObject('Search/SelectFilterType/ddl_searchField'))

        WebUI.selectOptionByValue(findTestObject('Search/SelectFilterType/ddl_searchField'), searchInput, false)

        break
    case 'DateRange':
        WebUI.setText(findTestObject('Search/SelectFilterType/input_daterange'), searchInput)

        break
    case 'CheckBox':
        WebUI.click(findTestObject('Search/SelectFilterType/ddl_statusfield'), FailureHandling.STOP_ON_FAILURE)

        WebUI.click(findTestObject('Search/SelectFilterType/select_Open', [('Status') : searchInput]))

        break
    default:
        break
}

WebUI.click(findTestObject('Search/SelectSearchType/btn_runSearch'))

WebUI.delay(5)

WebUI.verifyElementPresent(findTestObject('Search/SelectFilterType/lbl_Results'), 0)

String[] actualheaders = CustomKeywords.'com.fcm.search.utilities.GetTableHeadersforsearch.getColumnHeaders'(searchType)

String[] expectedheaders = CustomKeywords.'com.fcm.search.utilities.GetExpectedHeaders.getColumnHeaders'(searchType)

assert actualheaders == expectedheaders

HashMap<String, String> searchResults = CustomKeywords.'com.fcm.search.utilities.GetTableAsKeyValueforSearch.getColumnHeaders'(
    searchType, '0')

println(searchResults.get(searchField))

if(operator == "Equals"){
assert searchResults.get(searchField) == searchInput
}
else if(operator == "Contains"){
	assert searchResults.get(searchField).contains(searchInput)
	}
else if(operator == "Between"){
	/*dataRange = searchInput.split("-");
	Date startRange = dataRange[0]
	Date endRange= dataRange[1].trim()
	/*SimpleDateFormat sdf = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
	Date startRange = sdf.parse(startValue)
	Date endRange = sdf.parse(endValue)
	println "Start Range:***"+endRange
	println "End Range:**** "+startRange
	assert searchResults.get(searchField) >= startRange && searchResults.get(searchField) <= endRange */

	}
