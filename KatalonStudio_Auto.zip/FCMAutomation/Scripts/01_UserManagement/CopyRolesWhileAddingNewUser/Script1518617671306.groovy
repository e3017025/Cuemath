import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import java.util.Date as Date
import java.text.SimpleDateFormat as SimpleDateFormat
import java.text.DateFormat as DateFormat

WebUI.openBrowser(GlobalVariable.g_environmenturl)

WebUI.maximizeWindow()

WebUI.click(findTestObject('SignInPage/chk_windowsAuth'))

WebUI.click(findTestObject('SignInPage/btn_signinButton'))

WebUI.waitForElementPresent(findTestObject('AddNewUserPage1/button_Add User'), 10)

WebUI.click(findTestObject('AddNewUserPage1/button_Add User'))

dynamicuserID = ('CreateUser' + System.currentTimeMillis())

currentpassword = 'Test12345'

confirmpassword = 'Test1234'

WebUI.setText(findTestObject('AddNewUserPage1/input_username'), dynamicuserID)

WebUI.setText(findTestObject('AddNewUserPage1/input_fullName'), dynamicuserID + roleName)

WebUI.setText(findTestObject('AddNewUserPage1/input_userpassword'), currentpassword)

WebUI.setText(findTestObject('AddNewUserPage1/input_confirmuserpassword'), currentpassword)

'Page 1 - Next'
WebUI.click(findTestObject('AddNewUserPage1/button_Next'))

WebUI.delay(10)

WebUI.setText(findTestObject('AddNewUserPage2/txt_copyrolesFrom'), 'Analyst')

WebUI.click(findTestObject('AddNewUserPage2/lnk_selectRole'))

numberofrows = CustomKeywords.'com.fcm.application.utilities.GetNumberofRows.getValuefromWebTable'(findTestObject('AddNewUserPage2/web_NumberofRowElement'))

println(numberofrows)

assert numberofrows == 1

