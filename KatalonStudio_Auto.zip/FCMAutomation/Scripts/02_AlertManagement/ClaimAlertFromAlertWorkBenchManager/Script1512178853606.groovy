import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.WebDriver as WebDriver
import com.kms.katalon.core.webui.common.WebUiCommonHelper as WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory as DriverFactory
import org.openqa.selenium.By as By

not_run: CustomKeywords.'com.fcm.testdata.utilities.DropFiles.Landingzone'('ClaimAlert')

WebUI.callTestCase(findTestCase('04_ReusableComponents/05_Login/Login'), [('username') : 'Anna', ('password') : 'Analyst_2017'], 
    FailureHandling.STOP_ON_FAILURE)

WebUI.waitForElementPresent(findTestObject('Logout/Icon_UserInformationIcon'), GlobalVariable.g_timeout)

WebUI.callTestCase(findTestCase('04_ReusableComponents/03_NavigationTabs/NavigateToUnAssignedAlertsTab'), [:], FailureHandling.STOP_ON_FAILURE)

def ClaimedAlertId = WebUI.callTestCase(findTestCase('04_ReusableComponents/02_AlertManagement/ClaimAlertFromAlertWorkBenchManager'), 
    [('index') : '0', ('tableName') : 'Unassigned', ('columnIndex') : '4', ('claimedAlertId') : ''], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('04_ReusableComponents/03_NavigationTabs/NavigateToMyAssignedAlerts'), [:], FailureHandling.STOP_ON_FAILURE)

for (int numberofPages : (0..10)) {
    int numberofrows = CustomKeywords.'com.fcm.application.utilities.GetNumberofRows.getValuefromWebTable'(findTestObject(
            'AWB/NumberofRowElement', [('tableName') : 'AssignedToMe']))

    for (int index : (0..numberofrows - 1)) {
        def alertId = WebUI.getText(findTestObject('AWB/Tbl_alertId', [('index') : index, ('tableName') : myAlertsTableName
                    , ('columnIndex') : columnIndex]))

        if (alertId == ClaimedAlertId) {
            WebUI.click(findTestObject('AWB/Tbl_alertId', [('index') : index, ('tableName') : myAlertsTableName, ('columnIndex') : columnIndex]))

            assignedTo = WebUI.getText(findTestObject('ADP/web_assignedTo'))

            assert assignedTo == 'Analyst'

            WebUI.callTestCase(findTestCase('04_ReusableComponents/05_Login/Logout'), [:], FailureHandling.STOP_ON_FAILURE)

            return null
        }
        
        if (index == 24) {
            WebUI.click(findTestObject('AWB/btn_NextPage'))

            Thread.sleep(10000)
        }
    }
}

