import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import java.util.Date as Date
import java.text.SimpleDateFormat as SimpleDateFormat
import java.text.DateFormat as DateFormat

HashMap<String, String> userDetails = WebUI.callTestCase(findTestCase('04_ReusableComponents/04_UserManagement/AddUser'), 
    [('Successmessage') : 'User added succesfully.', ('roleCategory') : roleCategory, ('roleName') : roleName, ('secondApprovalRequired') : secondApprovalRequired
        , ('map') : 'map'], FailureHandling.STOP_ON_FAILURE)

userName = userDetails.get('UserName')

currentPassword = userDetails.get('CurrentPassword')

confirmPassword = userDetails.get('ConfirmPassword')

WebUI.callTestCase(findTestCase('04_ReusableComponents/05_Login/Logout'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.delay(3)

WebUI.callTestCase(findTestCase('04_ReusableComponents/04_UserManagement/ChangePassword'), [('UserName') : userName, ('CurrentPassword') : currentPassword
        , ('ConfirmPassword') : confirmPassword], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('04_ReusableComponents/05_Login/Login'), [('username') : userName, ('password') : confirmPassword], 
    FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('04_ReusableComponents/01_CaseManagement/CreateCase'), [('caseTitle') : 'caseTitle', ('casePriority') : 'High'
        , ('caseDescription') : 'caseDescription', ('caseType') : 'Deposit'], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('04_ReusableComponents/01_CaseManagement/DispositionOpenCase'), [('dispositionReason') : dispositionReason
        , ('caseStatus') : caseStatus, ('dispositionSuccessLabelText') : dispositionSuccessLabelText], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('04_ReusableComponents/05_Login/Logout'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('04_ReusableComponents/05_Login/Login'), [('username') : 'sam', ('password') : 'Supervisor_2017'], 
    FailureHandling.STOP_ON_FAILURE)

WebUI.callTestCase(findTestCase('04_ReusableComponents/03_NavigationTabs/NavigateToAwaitingApprovalCases'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.delay(30)

WebUI.click(findTestObject('CaseWorkBench/Tbl_CaseId', [('index') : '0', ('tableName') : 'AwaitingApproval', ('columnIndex') : '1']))

WebUI.delay(5)

WebUI.click(findTestObject('CaseDetailsPage/button_Approve Case'))

WebUI.callTestCase(findTestCase('04_ReusableComponents/02_AlertManagement/ApproveAlert_Case'), [('approveSuccessLabelText') : approveSuccessLabelText
        , ('alertStatusafterApproval') : alertStatusafterApproval], FailureHandling.STOP_ON_FAILURE)

