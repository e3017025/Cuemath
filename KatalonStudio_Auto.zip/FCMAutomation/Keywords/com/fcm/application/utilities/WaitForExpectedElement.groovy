package com.fcm.application.utilities

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable
import org.openqa.selenium.WebElement
import org.openqa.selenium.By.ByCssSelector
import org.openqa.selenium.support.ui.ExpectedConditions
import org.openqa.selenium.support.ui.WebDriverWait

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebElement
import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory


public class WaitForExpectedElement {
	@Keyword
	/* This is conditional implicit wait  we have give the element By and Locator
	 * Eg., 
	 * id: navSearch
	 * xpath: //*[@id='navSearch']
	 */
	public void explicitWait(String byObject, String locator) {
		WebDriver driver = DriverFactory.getWebDriver()
		WebDriverWait wait = new WebDriverWait(driver, 30)

		switch(byObject) {
			case "Id":
				println("entering in id case")
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.id(""""""+locator+"""""")));
				break;
			case "cssSelector":
				println("entering in css case")
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector(""""""+locator+"""""")));
				break;
			case "xpath":
				println("entering in xpath case")
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath(""""""+locator+"""""")));
				break;
			case "LinkText":
				println("entering in linkText case")
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText(""""""+locator+"""""")));
				break;
			case "PartialLinkText":
				println("entering in partialLinkText case")
				wait.until(ExpectedConditions.visibilityOfElementLocated(By.partialLinkText(""""""+locator+"""""")));
				break;
		}
	}
}




