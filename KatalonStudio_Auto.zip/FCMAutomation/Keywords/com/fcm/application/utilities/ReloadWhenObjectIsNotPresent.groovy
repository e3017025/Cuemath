package com.fcm.application.utilities

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.driver.DriverFactory
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable
import org.openqa.selenium.WebDriver
import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.By

public class ReloadWhenObjectIsNotPresent {
	@Keyword
	public String refreshPage(String tableName, String type) {
		WebDriver driver = DriverFactory.getWebDriver();

		switch (type){

			case "Alert":
				try {
					WebUI.delay(15);
					driver.findElement(By.cssSelector("#columntablegridAlerts_"+tableName+" > div:nth-child(2) > div > div:nth-child(1) > span"))
				}
				catch(Exception e) {
					driver.findElement(By.cssSelector("#navAlert")).click()
					WebUI.delay(5);
					driver.findElement(By.cssSelector("#Alerts_"+tableName+"Id > a")).click();
					WebUI.delay(30);
				}
				break;
			case "Case":
				try {
					WebUI.delay(15);
					driver.findElement(By.cssSelector("#columntablegridCases_Open"))
				}
				catch(Exception e) {
					driver.findElement(By.cssSelector("#navCases"))
					WebUI.delay(5);
					driver.findElement(By.cssSelector("#Cases_"+tableName+"Id > a")).click();
					WebUI.delay(30);
				}
				break;
		}
	}
}