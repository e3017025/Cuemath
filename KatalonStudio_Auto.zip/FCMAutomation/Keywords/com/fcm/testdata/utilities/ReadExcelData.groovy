package com.fcm.testdata.utilities
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Row.MissingCellPolicy;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI

public class ReadExcelData {
	@Keyword
	public static ArrayList<HashMap> readExcel(String SheetName,int Rownumber) throws IOException {
		//Define the File Folder
		//XSSFWorkbook sourceBook= new XSSFWorkbook("/Prime/Keywords.xlsx");
		///Prime/TestDataforWS.xlsx
		XSSFWorkbook sourceBook= new XSSFWorkbook("./TestData.xlsx");
		//XSSFWorkbook sourceBook= new XSSFWorkbook("/Prime/TestDataforWS.xlsx");
		println(SheetName);
		XSSFSheet sourceSheet=sourceBook.getSheet(SheetName);
		int lastRowNumber=sourceSheet.getLastRowNum();
		println(lastRowNumber);
		int lastColumnNumber=sourceSheet.getRow(0).getLastCellNum();
		XSSFRow headerRow = sourceSheet.getRow(0);
		//System.out.println(lastColumnNumber);
		//MissingCellPolicy policy = Row.RETURN_NULL_AND_BLANK;
		//int policy1=Cell.CELL_TYPE_BLANK;
		ArrayList<HashMap> columnArray= new ArrayList<HashMap>();
		//for (int j = 1; j <= lastRowNumber; j++)
		//{
		HashMap<String, String> ValuesMap = new HashMap<String, String>();
		for (int i = 0; i < lastColumnNumber; i++)
		{
			ValuesMap.put(headerRow.getCell(i).toString(),
					sourceSheet.getRow(Rownumber).getCell(i).toString());
		}
		columnArray.add(ValuesMap);
		//}
		println(columnArray);
		return columnArray;

	}

	@Keyword
	public static ArrayList<HashMap> readExcelallvalues(String SheetName) throws IOException
	{
		//Define the File Folder
		//XSSFWorkbook sourceBook= new XSSFWorkbook("/Prime/Keywords.xlsx");
		///Prime/TestDataforWS.xlsx
		XSSFWorkbook workbook= new XSSFWorkbook("./TestData.xlsx");
		//XSSFWorkbook sourceBook= new XSSFWorkbook("/Prime/TestDataforWS.xlsx");
		println(SheetName);
		XSSFSheet worksheet=workbook.getSheet(SheetName);
		int lastRowNumber=worksheet.getLastRowNum();
		println(lastRowNumber);
		int lastColumnNumber=worksheet.getRow(0).getLastCellNum();
		XSSFRow headerRow = worksheet.getRow(0);
		//System.out.println(lastColumnNumber);
		//MissingCellPolicy policy = Row.RETURN_NULL_AND_BLANK;
		//int policy1=Cell.CELL_TYPE_BLANK;
		ArrayList<HashMap> columnArray= new ArrayList<HashMap>();
		for (int j = 1; j <= lastRowNumber; j++) {
			HashMap<String, String> ValuesMap = new HashMap<String, String>();
			for (int i = 0; i < lastColumnNumber; i++) {
				ValuesMap.put(headerRow.getCell(i).toString(),
						worksheet.getRow(j).getCell(i).toString());
			}
			columnArray.add(ValuesMap);
		}
		//println (columnArray);
		return columnArray;

	}
}

