package com.fcm.search.utilities

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable
import org.openqa.selenium.WebElement
import org.openqa.selenium.By.ByCssSelector

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebElement
import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory


public class GetTableHeadersforsearch {
	@Keyword
	public static String[] getColumnHeaders(String searchType) {
		WebDriver driver = DriverFactory.getWebDriver()
		String[] elementIndex = GetTableHeadersforsearch.getElementIndexforsearch(searchType)
		String[] columnHeaders = new String[elementIndex.size()]

		for(int index=0;index<elementIndex.size();index++) {
			try {
				columnHeaders[index] = driver.findElement(By.cssSelector("#columntablegridjqxSearchGrid > div:nth-child("+elementIndex[index]+") > div > div:nth-child(1) > span")).getText();
			}
			catch (Exception e) {
				columnHeaders[index] = driver.findElement(By.cssSelector("#columntablegridjqxSearchGrid > div:nth-child("+elementIndex[index]+") > div > div:nth-child(1)")).getText();
			}
		}
		println columnHeaders
		return columnHeaders
	}

	public static String[] getElementIndexforsearch(String searchType) {
		String[] elementIndexMapping;
		switch(searchType) {
			case "Customer records":
				elementIndexMapping = ["1", "2", "3", "4"];
				break;
			case "AccountCustomerRelationshipRecords":
				elementIndexMapping = ["1", "2", "3", "4", "5", "6", "7", "8", "9"];
				break;
			case "Account":
				elementIndexMapping =["2", "3"];
				break;
			case "AccountToNumberRoutingRelationShipRecords":
				elementIndexMapping = ["1", "2", "3", "4", "5", "6"];
				break;
			case "ACHAnalyticsRecords":
				elementIndexMapping = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"];
				break;
			case "ACHDetailRecords":
				elementIndexMapping = [
					"1",
					"2",
					"3",
					"4",
					"5",
					"6",
					"7",
					"8",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"9",
					"10",
					"11"
				];
				break;
			default:
				println ("No Such Tables for this searchType");
		}
		return elementIndexMapping;
	}
}