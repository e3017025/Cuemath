package com.fcm.search.utilities

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable
import org.openqa.selenium.WebElement
import org.openqa.selenium.By.ByCssSelector

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebElement
import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory


public class GetTableAsKeyAndMultipleValuesforSearch {
	@Keyword
	public LinkedHashMap<String, List<String>> getColumnHeaders(String searchType, int numberofRows) {
		String[] elementIndex = GetTableHeadersforsearch.getElementIndexforsearch(searchType)
		LinkedHashMap<String, List<String>> columnHeadersAndValue = new LinkedHashMap<String, List<String>>();

		for(int index=0;index<elementIndex.size();index++) {
			String columnName =GetTableAsKeyAndMultipleValuesforSearch.getColumnHeader(searchType,elementIndex[index])
			List<String> rowValue = GetTableAsKeyAndMultipleValuesforSearch.getColumnValue(searchType, elementIndex[index],numberofRows)
			println "rowValue:"+ rowValue;
			columnHeadersAndValue.put(columnName,rowValue);
		}
		println columnHeadersAndValue
		return columnHeadersAndValue
	}

	public static String getColumnHeader(String searchType, String childNode) {
		WebDriver driver = DriverFactory.getWebDriver()
		String columnName
		try {
			columnName = driver.findElement(By.cssSelector("#columntablegridjqxSearchGrid > div:nth-child("+childNode+") > div > div:nth-child(1) > span")).getText();
		}
		catch (Exception e) {
			columnName = driver.findElement(By.cssSelector("#columntablegridjqxSearchGrid > div:nth-child("+childNode+") > div > div:nth-child(1)")).getText();
		}
		return columnName
	}

	public static List<String> getColumnValue(String searchType, String childNode, int numberofrows) {
		WebDriver driver = DriverFactory.getWebDriver()
		List<String> rowValues = new ArrayList<String>();
		for(int i=0;i<numberofrows;i++) {
			try {
				String value = driver.findElement(By.cssSelector("#row"+i+"gridjqxSearchGrid > div:nth-child("+childNode+") > div")).getText();
				rowValues.add(value);
			}
			catch (Exception e) {
				try {
					String value = driver.findElement(By.cssSelector("#row"+i+"gridjqxSearchGrid > div:nth-child("+childNode+") > a")).getText();
					rowValues.add(value);
				}
				catch (Exception e1) {
					String value = driver.findElement(By.cssSelector("#row"+i+"gridjqxSearchGrid > div:nth-child("+childNode+")")).getText();
					rowValues.add(value);
				}
			}
			println rowValues
		}
		return rowValues
	}
}
