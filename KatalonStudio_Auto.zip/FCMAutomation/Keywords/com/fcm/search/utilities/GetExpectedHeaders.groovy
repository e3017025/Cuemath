package com.fcm.search.utilities

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable
import org.openqa.selenium.WebElement
import org.openqa.selenium.By.ByCssSelector

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebElement
import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory


public class GetExpectedHeaders {
	@Keyword
	public String[] getColumnHeaders(String searchType) {
		WebDriver driver = DriverFactory.getWebDriver()
		String[] expectedHeaders = GetExpectedHeaders.getExpectedHeadersForSearch(searchType)
		println expectedHeaders
		return expectedHeaders
	}

	public static String[] getExpectedHeadersForSearch(String searchType) {
		String[] expectedheaders;
		switch(searchType) {
			case "Customer records":
				expectedheaders = ["Customer", "Created", "Updated", "Name"];
				break;
			case "notes":
				expectedheaders = ["Date", "User", "Note"];
				break;
			case "Account":
				expectedheaders =["2", "3"];
				break;
			case "AccountToNumberRoutingRelationShipRecords":
				expectedheaders = ["1", "2", "3", "4", "5", "6"];
				break;
			case "ACHAnalyticsRecords":
				expectedheaders = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "10"];
				break;
			case "ACHDetailRecords":
				expectedheaders = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "9", "9", "9", "9", "9", "9", "9", "9", "9", "9", "9", "9", "9", "9", "10", "11"];
				break;
			default:
				println ("No Such Tables for this searchType");
		}
		return expectedheaders;
	}
}