package com.fcm.alert.utilities

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint

import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords
import com.kms.katalon.core.webui.common.WebUiCommonHelper
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords

import internal.GlobalVariable
import org.openqa.selenium.WebElement
import org.openqa.selenium.By.ByCssSelector

import MobileBuiltInKeywords as Mobile
import WSBuiltInKeywords as WS
import WebUiBuiltInKeywords as WebUI
import org.openqa.selenium.WebElement
import org.openqa.selenium.By
import org.openqa.selenium.WebDriver
import com.kms.katalon.core.webui.driver.DriverFactory


public class GetTableAsKeyAndMultipleValues {
	@Keyword
	/******************** This will be mainly useful for Search Results ********************/    
	/******************** Eg., All Alert's Type is ACH or Status is OPEN *****************/
	public LinkedHashMap<String, List<String>> getColumnHeaders(String tableName, int numberofRows) {
		String[] elementIndex = GetTableHeaders.getElementIndex(tableName)
		LinkedHashMap<String, List<String>> columnHeadersAndValue = new LinkedHashMap<String, List<String>>();

		for(int index=0;index<elementIndex.size();index++) {
			//Get Column Name
			String columnName =GetTableAsKeyAndMultipleValues.getColumnHeader(tableName, elementIndex[index])
			//Get Values of all Column
			List<String> rowValue = GetTableAsKeyAndMultipleValues.getColumnValue(tableName, elementIndex[index],numberofRows)
			//Add Headers and All Values in the Hashmap
			columnHeadersAndValue.put(columnName,rowValue);
		}
		println columnHeadersAndValue
		return columnHeadersAndValue
	}

	public static String getColumnHeader(String tableName, String childNode) {
		WebDriver driver = DriverFactory.getWebDriver()
		String columnName
		if(tableName!= "notes" && tableName!= "alertHistory" ){
			try {
				columnName = driver.findElement(By.cssSelector("#columntablegridAlerts_"+tableName+" > div:nth-child("+childNode+") > div > div:nth-child(1) > span")).getText();
			}
			catch (Exception e) {
				columnName = driver.findElement(By.cssSelector("#columntablegridAlerts_"+tableName+" > div:nth-child("+childNode+") > div > div:nth-child(1)")).getText();
			}
		}
		else{
			columnName = driver.findElement(By.cssSelector("#columntablegrid"+tableName+"Grid > div:nth-child("+childNode+")")).getText();
		}
		return columnName
	}

	public static List<String> getColumnValue(String tableName, String childNode, int numberofrows) {
		WebDriver driver = DriverFactory.getWebDriver()
		List<String> rowValues = new ArrayList<String>();
		for(int i=0;i<numberofrows;i++) {
			try {
				String value = driver.findElement(By.cssSelector("#row"+i+"gridAlerts_"+tableName+" > div:nth-child("+childNode+") > div")).getText();
				rowValues.add(value);
			}
			catch (Exception e) {
				try {
					String value = driver.findElement(By.cssSelector("#row"+i+"gridAlerts_"+tableName+" > div:nth-child("+childNode+") > a")).getText();
					rowValues.add(value);
				}
				catch (Exception e1) {
					String value = driver.findElement(By.cssSelector("#row"+i+"gridAlerts_"+tableName+" > div:nth-child("+childNode+")")).getText();
					rowValues.add(value);
				}
			}
		}
		return rowValues
	}
}

