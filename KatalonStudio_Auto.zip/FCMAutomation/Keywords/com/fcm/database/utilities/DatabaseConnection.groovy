package com.fcm.database.utilities
import java.sql.DriverManager
import java.sql.ResultSet
import java.sql.ResultSetMetaData
import java.sql.Statement
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Driver;
import com.kms.katalon.core.annotation.Keyword

public class database {
	private static Connection connection = null;


	/******** Database Connection ********/
	@Keyword
	def connectDB(String server, String port, String dbname, String username, String password){
		String url = "jdbc:sqlserver://" +  server+ ":" + port + ";databaseName=" + dbname + ";user=" + username + ";password=" + password

		if(connection != null && !connection.isClosed()){
			connection.close()
		}
		connection = DriverManager.getConnection(url)
		return connection
	}


	/******** Database Query for the given Statement ********/
	@Keyword
	def executeQuery(String queryString) {
		Statement stm = connection.createStatement()
		ResultSet rs = stm.executeQuery(queryString)
		ResultSetMetaData metadata = rs.getMetaData();
		int columnCount = metadata.getColumnCount();
		println columnCount;
		HashMap<String,LinkedList<String>> columnNameToValuesMap=new HashMap<String, LinkedList<String>>();
		for (int i = 1; i <= columnCount; i++) {
			columnNameToValuesMap.put(metadata.getColumnName(i),new LinkedList<String>());
		}


		while (rs.next()) {
			for (String columnName : columnNameToValuesMap.keySet()) {
				String val = rs.getString(columnName);
				//println val
				println (columnNameToValuesMap.get(columnName).add(val));
			}
		}

		println columnNameToValuesMap
		return columnNameToValuesMap
	}

	/******** Close Database Connection ********/
	@Keyword
	def closeDatabaseConnection() {
		if(connection != null && !connection.isClosed()){
			connection.close()
		}
		connection = null
	}
}
